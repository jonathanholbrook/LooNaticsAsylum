import xbmc


if __name__ == '__main__':
	plugin = 'plugin://plugin.video.lu/'
	path = 'RunPlugin(%s?action=contextLUSettings&opensettings=false)' % plugin
	xbmc.executebuiltin(path)
	xbmc.executebuiltin('RunPlugin(%s?action=widgetRefresh)' % plugin)