# -*- coding: utf-8 -*-
#      __    ____  ____  _   _____  _____________________
#     / /   / __ \/ __ \/ | / /   |/_  __/  _/ ____/ ___/
#    / /   / / / / / / /  |/ / /| | / /  / // /    \__ \ 
#   / /___/ /_/ / /_/ / /|  / ___ |/ / _/ // /___ ___/ / 
#  /_____/\____/\____/_/ |_/_/  |_/_/ /___/\____//____/  
# 

import threading


class Thread(threading.Thread):
    def __init__(self, target, *args):
        self._target = target
        self._args = args
        threading.Thread.__init__(self)

    def run(self):
        self._target(*self._args)
