# -*- coding: utf-8 -*-
#      __    ____  ____  _   _____  _____________________
#     / /   / __ \/ __ \/ | / /   |/_  __/  _/ ____/ ___/
#    / /   / / / / / / /  |/ / /| | / /  / // /    \__ \
#   / /___/ /_/ / /_/ / /|  / ___ |/ / _/ // /___ ___/ /
#  /_____/\____/\____/_/ |_/_/  |_/_/ /___/\____//____/
#

import os
import xbmc
import xbmcaddon
import xbmcgui
import base64

try:
    from urllib.request import urlopen, Request

except ImportError:
    from urllib2 import urlopen, Request

ADDON_ID = xbmcaddon.Addon().getAddonInfo('id')
HOMEPATH = xbmc.translatePath('special://home/')
ADDONSPATH = os.path.join(HOMEPATH, 'addons')
THISADDONPATH = os.path.join(ADDONSPATH, ADDON_ID)
NEWSFILE      = base64.b64decode(b'aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL3RlY2hlY295b3RlL0xvb05hdGljc0FzeWx1bS9tYXN0ZXIvdGV4dC9sdS9uZXdzLnR4dA==')
LOCALNEWS     = os.path.join(THISADDONPATH, 'news.txt')


def news():
    message = open_news_url(NEWSFILE)
    r = open(LOCALNEWS)
    compfile = r.read()

    if len(message) > 1:
        if compfile == message: pass
        else:
            text_file = open(LOCALNEWS, "w")
            text_file.write(message)
            text_file.close()
            compfile = message

    showText('[B][COLOR springgreen]News and Info[/COLOR][/B]', compfile)


def open_news_url(url):
    req = Request(url)
    req.add_header('User-Agent', 'klopp')
    response = urlopen(req)
    link = response.read()
    response.close()
    return link


def news_local():
    r = open(LOCALNEWS)
    compfile = r.read()
    showText('[B]Updates and Information[/B]', compfile)


def showText(heading, text):
    id = 10147
    xbmc.executebuiltin('ActivateWindow(%d)' % id)
    xbmc.sleep(500)
    win = xbmcgui.Window(id)
    retry = 50

    while (retry > 0):
        try:
            xbmc.sleep(10)
            retry -= 1
            win.getControl(1).setLabel(heading)
            win.getControl(5).setText(text)
            quit()
            return
        except:
            pass