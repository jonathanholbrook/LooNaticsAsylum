# -*- coding: utf-8 -*-
"""
	LE Add-on
"""

from resources.lib.modules import control

le_path = control.addonPath(control.addonId())
le_version = control.addonVersion(control.addonId())

def get(file):
	helpFile = control.joinPath(le_path, 'resources', 'help', file + '.txt')
	r = open(helpFile)
	text = r.read()
	r.close()
	control.dialog.textviewer('[COLOR deepskyblue]LE[/COLOR] -  v%s - %s' % (le_version, file), text)