try :
    from urllib import quote_plus 
except ImportError :
    from urllib .parse import quote_plus 
from resources .lib .modules import control 
def router (OOO0OO0OO0OO00O0O ):
    OO00O00OO0O000O0O =OOO0OO0OO0OO00O0O .get ('action')
    OOO0000O0O0OO0OOO =OOO0OO0OO0OO00O0O .get ('id')
    O00O000O00000OOO0 =OOO0OO0OO0OO00O0O .get ('name')
    OO0O0O0OO00O00O00 =OOO0OO0OO0OO00O0O .get ('title')
    O00O00O00O0OOO000 =OOO0OO0OO0OO00O0O .get ('year')
    OO000OOOOOO00O000 =OOO0OO0OO0OO00O0O .get ('imdb')
    O0OO0O000OOO000O0 =OOO0OO0OO0OO00O0O .get ('tmdb')
    OO00OOO0O00O000O0 =OOO0OO0OO0OO00O0O .get ('tvdb')
    OOOOOOOO00OO00000 =OOO0OO0OO0OO00O0O .get ('season')
    O000000000000OO00 =OOO0OO0OO0OO00O0O .get ('episode')
    OOO000OOOOOO00000 =OOO0OO0OO0OO00O0O .get ('tvshowtitle')
    OOOO00O000OOO0000 =OOO0OO0OO0OO00O0O .get ('type')
    O0OOO000OOO0O0O00 =OOO0OO0OO0OO00O0O .get ('url')
    O00OO0O0000O0OO0O =OOO0OO0OO0OO00O0O .get ('query')
    O0OO0OO0OO0O000OO =OOO0OO0OO0OO00O0O .get ('source')
    O0O00O00OOOO0OOO0 =OOO0OO0OO0OO00O0O .get ('content')
    if OO00O00OO0O000O0O is None :
        from resources .lib .menus import navigator 
        OOO0O0O0O0O0O0OO0 =control .homeWindow .getProperty ('le.updated')
        if OOO0O0O0O0O0O0OO0 =='true':
            control .execute ('RunPlugin(plugin://plugin.video.le/?action=tools_cleanSettings)')
            control .homeWindow .clearProperty ('le.updated')
            from resources .lib .modules import changelog 
            changelog .get ()
        navigator .Navigator ().root ()
    elif OO00O00OO0O000O0O =='imdbnavigator':
        from resources .lib .menus import navigator 
        navigator .Navigator ().imdbnavigator ()
    elif OO00O00OO0O000O0O =='imdbmovies':
        from resources .lib .menus import navigator 
        navigator .Navigator ().imdbmovies ()
    elif OO00O00OO0O000O0O =='imdbtvshows':
        from resources .lib .menus import navigator 
        navigator .Navigator ().imdbtvshows ()
    elif OO00O00OO0O000O0O =='movieMosts':
        from resources .lib .menus import navigator 
        navigator .Navigator ().movieMosts ()
    elif OO00O00OO0O000O0O =='showMosts':
        from resources .lib .menus import navigator 
        navigator .Navigator ().showMosts ()
    elif OO00O00OO0O000O0O =='musicNavigator':
        from resources .lib .menus import music 
        music .music ().root ()
    elif OO00O00OO0O000O0O =='musicPlay':
        from resources .lib .menus import music 
        music .music ().play (O0OOO000OOO0O0O00 )
    elif OO00O00OO0O000O0O =='porn':
        from resources .lib .menus import gfy 
        gfy .indexer ().root_porn ()
    elif OO00O00OO0O000O0O =='userlists':
        from resources .lib .menus import gfy 
        gfy .indexer ().root_userlists ()
    elif OO00O00OO0O000O0O =='directory':
        from resources .lib .menus import gfy 
        gfy .indexer ().get (O0OOO000OOO0O0O00 )
    elif OO00O00OO0O000O0O =='qdirectory':
        from resources .lib .menus import gfy 
        gfy .indexer ().getq (O0OOO000OOO0O0O00 )
    elif OO00O00OO0O000O0O =='xdirectory':
        from resources .lib .menus import gfy 
        gfy .indexer ().getx (O0OOO000OOO0O0O00 )
    elif OO00O00OO0O000O0O =='developer':
        from resources .lib .menus import gfy 
        gfy .indexer ().developer ()
    elif OO00O00OO0O000O0O =='tvtuner':
        from resources .lib .menus import gfy 
        gfy .indexer ().tvtuner (O0OOO000OOO0O0O00 )
    elif OO00O00OO0O000O0O =='gfy_play':
        from resources .lib .menus import gfy 
        if not O0O00O00OOOO0OOO0 ==None :
            gfy .player ().play (O0OOO000OOO0O0O00 ,O0O00O00OOOO0OOO0 )
        else :
            from resources .lib .modules import sources 
            sources .Sources ().play (OO0O0O0OO00O00O00 ,O00O00O00O0OOO000 ,OO000OOOOOO00O000 ,OO00OOO0O00O000O0 ,OOOOOOOO00OO00000 ,O000000000000OO00 ,OOO000OOOOOO00000 ,O00O0OOO00O0000OO ,OO00OO00OOO00O0OO ,O0O00OOO00000O000 )
    elif OO00O00OO0O000O0O =='browser':
        from resources .lib .menus import gfy 
        gfy .resolver ().browser (O0OOO000OOO0O0O00 )
    elif OO00O00OO0O000O0O =='iptvListsNavigator':
        from resources .lib .menus import navigator 
        navigator .Navigator ().iptv ()
    elif OO00O00OO0O000O0O =='listsListsNavigator':
        from resources .lib .menus import navigator 
        navigator .Navigator ().lists ()
    elif OO00O00OO0O000O0O =='madhouseListsNavigator':
        from resources .lib .menus import navigator 
        navigator .Navigator ().madhouse ()
    elif OO00O00OO0O000O0O =='wolfgirl':
        from resources .lib .menus import navigator 
        navigator .Navigator ().wolfgirl ()
    elif OO00O00OO0O000O0O =='cable':
        from resources .lib .menus import navigator 
        navigator .Navigator ().cable ()
    elif OO00O00OO0O000O0O =='shadowhawk':
        from resources .lib .menus import navigator 
        navigator .Navigator ().shadowhawk ()
    elif OO00O00OO0O000O0O =='burninu':
        from resources .lib .menus import navigator 
        navigator .Navigator ().burninu ()
    elif OO00O00OO0O000O0O =='sublime':
        from resources .lib .menus import navigator 
        navigator .Navigator ().sublime ()
    elif OO00O00OO0O000O0O =='dococtyl':
        from resources .lib .menus import navigator 
        navigator .Navigator ().dococtyl ()
    elif OO00O00OO0O000O0O =='diamondbuild':
        from resources .lib .menus import gfy 
        gfy .indexer ().root_diamondbuild ()
    elif OO00O00OO0O000O0O =='dcmarvelbuild':
        from resources .lib .menus import navigator 
        navigator .Navigator ().dcmarvelbuild ()
    elif OO00O00OO0O000O0O =='oneclick':
        from resources .lib .menus import gfy 
        gfy .indexer ().root_oneclick ()
    elif OO00O00OO0O000O0O =='test':
        from resources .lib .menus import gfy 
        gfy .indexer ().root_test ()
    elif OO00O00OO0O000O0O =='world':
        from resources .lib .menus import gfy 
        gfy .indexer ().root_world ()
    elif OO00O00OO0O000O0O =='m3u':
        from resources .lib .menus import gfy 
        gfy .indexer ().root ()
    elif OO00O00OO0O000O0O =='tvnsports':
        from resources .lib .menus import gfy 
        gfy .indexer ().root_tvnsports ()
    elif OO00O00OO0O000O0O =='swift':
        from resources .lib .menus import gfy 
        gfy .indexer ().root_swift ()
    elif OO00O00OO0O000O0O =='tvtap':
        from resources .lib .menus import gfy 
        gfy .indexer ().root_tvtap ()
    elif OO00O00OO0O000O0O =='livenet':
        from resources .lib .menus import gfy 
        gfy .indexer ().root_livenet ()
    elif OO00O00OO0O000O0O =='livenetsports':
        from resources .lib .menus import gfy 
        gfy .indexer ().root_livenetsports ()
    elif OO00O00OO0O000O0O =='youtube':
        from resources .lib .menus import youtube 
        if OOO0000O0O0OO0OOO is None :
            youtube .yt_index ().root (OO00O00OO0O000O0O )
        else :
            youtube .yt_index ().get (OO00O00OO0O000O0O ,OOO0000O0O0OO0OOO )
    elif OO00O00OO0O000O0O =='musicvids':
        from resources .lib .menus import youtube 
        if OOO0000O0O0OO0OOO ==None :
            youtube .yt_index ().root (OO00O00OO0O000O0O )
        else :
            youtube .yt_index ().get (OO00O00OO0O000O0O ,OOO0000O0O0OO0OOO )
    elif OO00O00OO0O000O0O =='sectionItem':
        pass 
    elif OO00O00OO0O000O0O =='movieReviews':
        from resources .lib .menus import youtube 
        if OOO0000O0O0OO0OOO ==None :
            youtube .yt_index ().root (OO00O00OO0O000O0O )
        else :
            youtube .yt_index ().get (OO00O00OO0O000O0O ,OOO0000O0O0OO0OOO )
    elif OO00O00OO0O000O0O =='tvReviews':
        from resources .lib .menus import youtube 
        if OOO0000O0O0OO0OOO ==None :
            youtube .yt_index ().root (OO00O00OO0O000O0O )
        else :
            youtube .yt_index ().get (OO00O00OO0O000O0O ,OOO0000O0O0OO0OOO )
    elif OO00O00OO0O000O0O =='infoCheck':
        from resources .lib .menus import navigator 
        navigator .Navigator ().infoCheck ('')
    elif OO00O00OO0O000O0O =='ShowNews':
        from resources .lib .modules import newsinfo 
        newsinfo .news ()
    elif OO00O00OO0O000O0O =='ShowChangelog':
        from resources .lib .modules import changelog 
        changelog .get ()
    elif OO00O00OO0O000O0O =='ShowHelp':
        from resources .help import help 
        help .get (O00O000O00000OOO0 )
        control .openSettings (O00OO0O0000O0OO0O )
    elif OO00O00OO0O000O0O =='setReuseLanguageInvoker':
        control .set_reuselanguageinvoker ()
    elif OO00O00OO0O000O0O =='dcmarvelherosNavigator':
        from resources .lib .menus import navigator 
        navigator .Navigator ().dcmarvelherosNavigator ()
    elif OO00O00OO0O000O0O =='movieNavigator':
        from resources .lib .menus import navigator 
        navigator .Navigator ().movies ()
    elif OO00O00OO0O000O0O =='movieliteNavigator':
        from resources .lib .menus import navigator 
        navigator .Navigator ().movies (lite =True )
    elif OO00O00OO0O000O0O =='mymovieNavigator':
        from resources .lib .menus import navigator 
        navigator .Navigator ().mymovies ()
    elif OO00O00OO0O000O0O =='mymovieliteNavigator':
        from resources .lib .menus import navigator 
        navigator .Navigator ().mymovies (lite =True )
    elif OO00O00OO0O000O0O =='movies':
        from resources .lib .menus import movies 
        movies .Movies ().get (O0OOO000OOO0O0O00 )
    elif OO00O00OO0O000O0O =='moviePage':
        from resources .lib .menus import movies 
        movies .Movies ().get (O0OOO000OOO0O0O00 )
    elif OO00O00OO0O000O0O =='tmdbmovies':
        from resources .lib .menus import movies 
        movies .Movies ().getTMDb (O0OOO000OOO0O0O00 )
    elif OO00O00OO0O000O0O =='tmdbmoviePage':
        from resources .lib .menus import movies 
        movies .Movies ().getTMDb (O0OOO000OOO0O0O00 )
    elif OO00O00OO0O000O0O =='movieSearch':
        from resources .lib .menus import movies 
        movies .Movies ().search ()
    elif OO00O00OO0O000O0O =='movieSearchnew':
        from resources .lib .menus import movies 
        movies .Movies ().search_new ()
    elif OO00O00OO0O000O0O =='movieSearchterm':
        from resources .lib .menus import movies 
        movies .Movies ().search_term (O00O000O00000OOO0 )
    elif OO00O00OO0O000O0O =='moviePerson':
        from resources .lib .menus import movies 
        movies .Movies ().person ()
    elif OO00O00OO0O000O0O =='movieGenres':
        from resources .lib .menus import movies 
        movies .Movies ().genres ()
    elif OO00O00OO0O000O0O =='movieLanguages':
        from resources .lib .menus import movies 
        movies .Movies ().languages ()
    elif OO00O00OO0O000O0O =='movieCertificates':
        from resources .lib .menus import movies 
        movies .Movies ().certifications ()
    elif OO00O00OO0O000O0O =='movieYears':
        from resources .lib .menus import movies 
        movies .Movies ().years ()
    elif OO00O00OO0O000O0O =='moviePersons':
        from resources .lib .menus import movies 
        movies .Movies ().persons (O0OOO000OOO0O0O00 )
    elif OO00O00OO0O000O0O =='moviesUnfinished':
        from resources .lib .menus import movies 
        movies .Movies ().unfinished (O0OOO000OOO0O0O00 )
    elif OO00O00OO0O000O0O =='movieUserlists':
        from resources .lib .menus import movies 
        movies .Movies ().userlists ()
    elif OO00O00OO0O000O0O and OO00O00OO0O000O0O .startswith ('collections'):
        if OO00O00OO0O000O0O =='collections_Navigator':
            from resources .lib .menus import collections 
            collections .Collections ().collections_Navigator ()
        elif OO00O00OO0O000O0O =='collections_Boxset':
            from resources .lib .menus import collections 
            collections .Collections ().collections_Boxset ()
        elif OO00O00OO0O000O0O =='collections_Kids':
            from resources .lib .menus import collections 
            collections .Collections ().collections_Kids ()
        elif OO00O00OO0O000O0O =='collections_BoxsetKids':
            from resources .lib .menus import collections 
            collections .Collections ().collections_BoxsetKids ()
        elif OO00O00OO0O000O0O =='collections_Superhero':
            from resources .lib .menus import collections 
            collections .Collections ().collections_Superhero ()
        elif OO00O00OO0O000O0O =='collections_MartialArts':
            from resources .lib .menus import collections 
            collections .Collections ().collections_martial_arts ()
        elif OO00O00OO0O000O0O =='collections_MartialArtsActors':
            from resources .lib .menus import collections 
            collections .Collections ().collections_martial_arts_actors ()
        elif OO00O00OO0O000O0O =='collections':
            from resources .lib .menus import collections 
            collections .Collections ().get (O0OOO000OOO0O0O00 )
    elif OO00O00OO0O000O0O and OO00O00OO0O000O0O .startswith ('furk'):
        if OO00O00OO0O000O0O =="furkNavigator":
            from resources .lib .menus import navigator 
            navigator .Navigator ().furk ()
        elif OO00O00OO0O000O0O =="furkUserFiles":
            from resources .lib .menus import furk 
            furk .Furk ().user_files ()
        elif OO00O00OO0O000O0O =="furkMetaSearch":
            from resources .lib .menus import furk 
            furk .Furk ().furk_meta_search (O0OOO000OOO0O0O00 )
        elif OO00O00OO0O000O0O =="furkSearch":
            from resources .lib .menus import furk 
            furk .Furk ().search ()
        elif OO00O00OO0O000O0O =="furkSearchNew":
            from resources .lib .menus import furk 
            furk .Furk ().search_new ()
    elif OO00O00OO0O000O0O =='tvNavigator':
        from resources .lib .menus import navigator 
        navigator .Navigator ().tvshows ()
    elif OO00O00OO0O000O0O =='tvliteNavigator':
        from resources .lib .menus import navigator 
        navigator .Navigator ().tvshows (lite =True )
    elif OO00O00OO0O000O0O =='mytvNavigator':
        from resources .lib .menus import navigator 
        navigator .Navigator ().mytvshows ()
    elif OO00O00OO0O000O0O =='mytvliteNavigator':
        from resources .lib .menus import navigator 
        navigator .Navigator ().mytvshows (lite =True )
    elif OO00O00OO0O000O0O =='channels':
        from resources .lib .menus import channels 
        channels .channels ().get ()
    elif OO00O00OO0O000O0O =='tvshows':
        from resources .lib .menus import tvshows 
        tvshows .TVshows ().get (O0OOO000OOO0O0O00 )
    elif OO00O00OO0O000O0O =='tvshowPage':
        from resources .lib .menus import tvshows 
        tvshows .TVshows ().get (O0OOO000OOO0O0O00 )
    elif OO00O00OO0O000O0O =='tmdbTvshows':
        from resources .lib .menus import tvshows 
        tvshows .TVshows ().getTMDb (O0OOO000OOO0O0O00 )
    elif OO00O00OO0O000O0O =='tmdbTvshowPage':
        from resources .lib .menus import tvshows 
        tvshows .TVshows ().getTMDb (O0OOO000OOO0O0O00 )
    elif OO00O00OO0O000O0O =='tvmazeTvshows':
        from resources .lib .menus import tvshows 
        tvshows .TVshows ().getTVmaze (O0OOO000OOO0O0O00 )
    elif OO00O00OO0O000O0O =='tvmazeTvshowPage':
        from resources .lib .menus import tvshows 
        tvshows .TVshows ().getTVmaze (O0OOO000OOO0O0O00 )
    elif OO00O00OO0O000O0O =='tvSearch':
        from resources .lib .menus import tvshows 
        tvshows .TVshows ().search ()
    elif OO00O00OO0O000O0O =='tvSearchnew':
        from resources .lib .menus import tvshows 
        tvshows .TVshows ().search_new ()
    elif OO00O00OO0O000O0O =='tvSearchterm':
        from resources .lib .menus import tvshows 
        tvshows .TVshows ().search_term (O00O000O00000OOO0 )
    elif OO00O00OO0O000O0O =='tvPerson':
        from resources .lib .menus import tvshows 
        tvshows .TVshows ().person ()
    elif OO00O00OO0O000O0O =='tvGenres':
        from resources .lib .menus import tvshows 
        tvshows .TVshows ().genres ()
    elif OO00O00OO0O000O0O =='tvNetworks':
        from resources .lib .menus import tvshows 
        tvshows .TVshows ().networks ()
    elif OO00O00OO0O000O0O =='tvLanguages':
        from resources .lib .menus import tvshows 
        tvshows .TVshows ().languages ()
    elif OO00O00OO0O000O0O =='tvCertificates':
        from resources .lib .menus import tvshows 
        tvshows .TVshows ().certifications ()
    elif OO00O00OO0O000O0O =='tvPersons':
        from resources .lib .menus import tvshows 
        tvshows .TVshows ().persons (O0OOO000OOO0O0O00 )
    elif OO00O00OO0O000O0O =='tvUserlists':
        from resources .lib .menus import tvshows 
        tvshows .TVshows ().userlists ()
    elif OO00O00OO0O000O0O =='tvOriginals':
        from resources .lib .menus import tvshows 
        tvshows .TVshows ().originals ()
    if OO00O00OO0O000O0O and OO00O00OO0O000O0O .startswith ('seasons'):
        if OO00O00OO0O000O0O =='seasons':
            from resources .lib .menus import seasons 
            OOO0OOOO0O00O0O0O =OOO0OO0OO0OO00O0O .get ('art')
            seasons .Seasons ().get (OOO000OOOOOO00000 ,O00O00O00O0OOO000 ,OO000OOOOOO00O000 ,O0OO0O000OOO000O0 ,OO00OOO0O00O000O0 ,OOO0OOOO0O00O0O0O )
    elif OO00O00OO0O000O0O =='playEpisodesList':
        from json import dumps as jsdumps 
        from resources .lib .menus import episodes 
        OO00OO00OOO00O0OO =OOO0OO0OO0OO00O0O .get ('meta')
        O0OOO00OOO0000O00 =episodes .Episodes ().get (OOO000OOOOOO00000 ,O00O00O00O0OOO000 ,OO000OOOOOO00O000 ,O0OO0O000OOO000O0 ,OO00OOO0O00O000O0 ,OO00OO00OOO00O0OO ,OOOOOOOO00OO00000 ,O000000000000OO00 ,create_directory =False )
        control .playlist .clear ()
        for OOOOOO00OO00O0000 in O0OOO00OOO0000O00 :
            OO0O0O0OO00O00O00 =OOOOOO00OO00O0000 ['title']
            OOO000O0O00OO0000 =quote_plus (OO0O0O0OO00O00O00 )
            O00O00O00O0OOO000 =OOOOOO00OO00O0000 ['year']
            OO000OOOOOO00O000 =OOOOOO00OO00O0000 ['imdb']
            O0OO0O000OOO000O0 =OOOOOO00OO00O0000 ['tmdb']
            OO00OOO0O00O000O0 =OOOOOO00OO00O0000 ['tvdb']
            OOOOOOOO00OO00000 =OOOOOO00OO00O0000 ['season']
            O000000000000OO00 =OOOOOO00OO00O0000 ['episode']
            OOO000OOOOOO00000 =OOOOOO00OO00O0000 ['tvshowtitle']
            O0OOO0OO0O00OO000 =quote_plus (OOO000OOOOOO00000 )
            O00O0OOO00O0000OO =OOOOOO00OO00O0000 ['premiered']
            OOO00O0OO0O00O000 =quote_plus (jsdumps (OOOOOO00OO00O0000 ))
            O0OOO000OOO0O0O00 ='plugin://plugin.video.le/?action=play&title=%s&year=%s&imdb=%s&tmdb=%s&tvdb=%s&season=%s&episode=%s&tvshowtitle=%s&premiered=%s&meta=%s&select="2"'%(OOO000O0O00OO0000 ,O00O00O00O0OOO000 ,OO000OOOOOO00O000 ,O0OO0O000OOO000O0 ,OO00OOO0O00O000O0 ,OOOOOOOO00OO00000 ,O000000000000OO00 ,O0OOO0OO0O00OO000 ,O00O0OOO00O0000OO ,OOO00O0OO0O00O000 )
            try :O000O00O00O000O00 =control .item (label =OO0O0O0OO00O00O00 ,offscreen =True )
            except :O000O00O00O000O00 =control .item (label =OO0O0O0OO00O00O00 )
            control .playlist .add (url =O0OOO000OOO0O0O00 ,listitem =O000O00O00O000O00 )
        control .player2 ().play (control .playlist )
    elif OO00O00OO0O000O0O =='episodes':
        from resources .lib .menus import episodes 
        OO00OO00OOO00O0OO =OOO0OO0OO0OO00O0O .get ('meta')
        episodes .Episodes ().get (OOO000OOOOOO00000 ,O00O00O00O0OOO000 ,OO000OOOOOO00O000 ,O0OO0O000OOO000O0 ,OO00OOO0O00O000O0 ,OO00OO00OOO00O0OO ,OOOOOOOO00OO00000 ,O000000000000OO00 )
    elif OO00O00OO0O000O0O =='calendar':
        from resources .lib .menus import episodes 
        episodes .Episodes ().calendar (O0OOO000OOO0O0O00 )
    elif OO00O00OO0O000O0O =='upcomingProgress':
        from resources .lib .menus import episodes 
        episodes .Episodes ().upcoming_progress (O0OOO000OOO0O0O00 )
    elif OO00O00OO0O000O0O =='calendars':
        from resources .lib .menus import episodes 
        episodes .Episodes ().calendars ()
    elif OO00O00OO0O000O0O =='episodesUnfinished':
        from resources .lib .menus import episodes 
        episodes .Episodes ().unfinished (O0OOO000OOO0O0O00 )
    elif OO00O00OO0O000O0O =='episodesUserlists':
        from resources .lib .menus import episodes 
        episodes .Episodes ().userlists ()
    elif OO00O00OO0O000O0O =='premiumNavigator':
        from resources .lib .menus import navigator 
        navigator .Navigator ().premium_services ()
    elif OO00O00OO0O000O0O and OO00O00OO0O000O0O .startswith ('pm_'):
        if OO00O00OO0O000O0O =='pm_ServiceNavigator':
            from resources .lib .menus import navigator 
            navigator .Navigator ().premiumize_service ()
        elif OO00O00OO0O000O0O =='pm_AccountInfo':
            from resources .lib .debrid import premiumize 
            premiumize .Premiumize ().account_info_to_dialog ()
        elif OO00O00OO0O000O0O =='pm_MyFiles':
            from resources .lib .debrid import premiumize 
            premiumize .Premiumize ().my_files_to_listItem (OOO0000O0O0OO0OOO ,O00O000O00000OOO0 )
        elif OO00O00OO0O000O0O =='pm_Transfers':
            from resources .lib .debrid import premiumize 
            premiumize .Premiumize ().user_transfers_to_listItem ()
        elif OO00O00OO0O000O0O =='pm_Rename':
            from resources .lib .debrid import premiumize 
            premiumize .Premiumize ().rename (OOOO00O000OOO0000 ,OOO0000O0O0OO0OOO ,O00O000O00000OOO0 )
        elif OO00O00OO0O000O0O =='pm_Delete':
            from resources .lib .debrid import premiumize 
            premiumize .Premiumize ().delete (OOOO00O000OOO0000 ,OOO0000O0O0OO0OOO ,O00O000O00000OOO0 )
        elif OO00O00OO0O000O0O =='pm_DeleteTransfer':
            from resources .lib .debrid import premiumize 
            premiumize .Premiumize ().delete_transfer (OOO0000O0O0OO0OOO ,O00O000O00000OOO0 )
        elif OO00O00OO0O000O0O =='pm_ClearFinishedTransfers':
            from resources .lib .debrid import premiumize 
            premiumize .Premiumize ().clear_finished_transfers ()
    elif OO00O00OO0O000O0O and OO00O00OO0O000O0O .startswith ('rd_'):
        if OO00O00OO0O000O0O =='rd_ServiceNavigator':
            from resources .lib .menus import navigator 
            navigator .Navigator ().realdebrid_service ()
        elif OO00O00OO0O000O0O =='rd_AccountInfo':
            from resources .lib .debrid import realdebrid 
            realdebrid .RealDebrid ().account_info_to_dialog ()
        elif OO00O00OO0O000O0O =='rd_UserTorrentsToListItem':
            from resources .lib .debrid import realdebrid 
            realdebrid .RealDebrid ().user_torrents_to_listItem ()
        elif OO00O00OO0O000O0O =='rd_MyDownloads':
            from resources .lib .debrid import realdebrid 
            realdebrid .RealDebrid ().my_downloads_to_listItem (int (O00OO0O0000O0OO0O ))
        elif OO00O00OO0O000O0O =='rd_BrowseUserTorrents':
            from resources .lib .debrid import realdebrid 
            realdebrid .RealDebrid ().browse_user_torrents (OOO0000O0O0OO0OOO )
        elif OO00O00OO0O000O0O =='rd_DeleteUserTorrent':
            from resources .lib .debrid import realdebrid 
            realdebrid .RealDebrid ().delete_user_torrent (OOO0000O0O0OO0OOO ,O00O000O00000OOO0 )
        elif OO00O00OO0O000O0O =='rd_DeleteDownload':
            from resources .lib .debrid import realdebrid 
            realdebrid .RealDebrid ().delete_download (OOO0000O0O0OO0OOO ,O00O000O00000OOO0 )
    elif OO00O00OO0O000O0O and OO00O00OO0O000O0O .startswith ('ad_'):
        if OO00O00OO0O000O0O =='ad_ServiceNavigator':
            from resources .lib .menus import navigator 
            navigator .Navigator ().alldebrid_service ()
        elif OO00O00OO0O000O0O =='ad_AccountInfo':
            from resources .lib .debrid import alldebrid 
            alldebrid .AllDebrid ().account_info_to_dialog ()
        elif OO00O00OO0O000O0O =='ad_Transfers':
            from resources .lib .debrid import alldebrid 
            alldebrid .AllDebrid ().user_transfers_to_listItem ()
        elif OO00O00OO0O000O0O =='ad_CloudStorage':
            from resources .lib .debrid import alldebrid 
            alldebrid .AllDebrid ().user_cloud_to_listItem ()
        elif OO00O00OO0O000O0O =='ad_BrowseUserCloud':
            from resources .lib .debrid import alldebrid 
            alldebrid .AllDebrid ().browse_user_cloud (O0OO0OO0OO0O000OO )
        elif OO00O00OO0O000O0O =='ad_DeleteTransfer':
            from resources .lib .debrid import alldebrid 
            alldebrid .AllDebrid ().delete_transfer (OOO0000O0O0OO0OOO ,O00O000O00000OOO0 ,silent =False )
        elif OO00O00OO0O000O0O =='ad_RestartTransfer':
            from resources .lib .debrid import alldebrid 
            alldebrid .AllDebrid ().restart_transfer (OOO0000O0O0OO0OOO ,O00O000O00000OOO0 ,silent =False )
    elif OO00O00OO0O000O0O and OO00O00OO0O000O0O .startswith ('anime_'):
        if OO00O00OO0O000O0O =='anime_Navigator':
            from resources .lib .menus import navigator 
            navigator .Navigator ().anime ()
        elif OO00O00OO0O000O0O =='anime_Movies':
            from resources .lib .menus import movies 
            movies .Movies ().get (O0OOO000OOO0O0O00 )
        elif OO00O00OO0O000O0O =='anime_TVshows':
            from resources .lib .menus import tvshows 
            tvshows .TVshows ().get (O0OOO000OOO0O0O00 )
    elif OO00O00OO0O000O0O =='tmdbnavigator':
        from resources .lib .menus import navigator 
        navigator .Navigator ().tmdbnavigator ()
    elif OO00O00OO0O000O0O =='usertmdbmovies':
        from resources .lib .menus import navigator 
        navigator .Navigator ().usertmdbmovies ()
    elif OO00O00OO0O000O0O =='usertmdbtv':
        from resources .lib .menus import navigator 
        navigator .Navigator ().usertmdbtv ()
    elif OO00O00OO0O000O0O =='empiremovies':
        from resources .lib .menus import navigator 
        navigator .Navigator ().empiremovies ()
    elif OO00O00OO0O000O0O =='empiretv':
        from resources .lib .menus import navigator 
        navigator .Navigator ().empiretv ()
    elif OO00O00OO0O000O0O and OO00O00OO0O000O0O .startswith ('download'):
        if OO00O00OO0O000O0O =='downloadNavigator':
            from resources .lib .menus import navigator 
            navigator .Navigator ().downloads ()
        elif OO00O00OO0O000O0O =='download':
            O000O0OO0O0O00OOO =OOO0OO0OO0OO00O0O .get ('caller')
            OOOO00O00O000O000 =OOO0OO0OO0OO00O0O .get ('image')
            if O000O0OO0O0O00OOO =='sources':
                control .busy ()
                try :
                    from json import loads as jsloads 
                    from resources .lib .modules import sources 
                    from resources .lib .modules import downloader 
                    downloader .download (O00O000O00000OOO0 ,OOOO00O00O000O000 ,sources .Sources ().sourcesResolve (jsloads (O0OO0OO0OO0O000OO )[0 ]),OO0O0O0OO00O00O00 )
                except :
                    import traceback 
                    traceback .print_exc ()
            if O000O0OO0O0O00OOO =='premiumize':
                control .busy ()
                try :
                    from resources .lib .modules import downloader 
                    from resources .lib .debrid import premiumize 
                    downloader .download (O00O000O00000OOO0 ,OOOO00O00O000O000 ,premiumize .Premiumize ().add_headers_to_url (O0OOO000OOO0O0O00 .replace (' ','%20')))
                except :
                    import traceback 
                    traceback .print_exc ()
            if O000O0OO0O0O00OOO =='realdebrid':
                control .busy ()
                try :
                    from resources .lib .modules import downloader 
                    from resources .lib .debrid import realdebrid 
                    if OOOO00O000OOO0000 =='unrestrict':
                        downloader .download (O00O000O00000OOO0 ,OOOO00O00O000O000 ,realdebrid .RealDebrid ().unrestrict_link (O0OOO000OOO0O0O00 .replace (' ','%20')))
                    else :
                        downloader .download (O00O000O00000OOO0 ,OOOO00O00O000O000 ,O0OOO000OOO0O0O00 .replace (' ','%20'))
                except :
                    import traceback 
                    traceback .print_exc ()
            if O000O0OO0O0O00OOO =='alldebrid':
                control .busy ()
                try :
                    from resources .lib .modules import downloader 
                    from resources .lib .debrid import alldebrid 
                    downloader .download (O00O000O00000OOO0 ,OOOO00O00O000O000 ,alldebrid .AllDebrid ().unrestrict_link (O0OOO000OOO0O0O00 .replace (' ','%20')))
                except :
                    import traceback 
                    traceback .print_exc ()
    elif OO00O00OO0O000O0O and OO00O00OO0O000O0O .startswith ('tools_'):
        if OO00O00OO0O000O0O =='tools_ShowNews':
            from resources .lib .modules import newsinfo 
            newsinfo .news ()
        elif OO00O00OO0O000O0O =='tools_ShowChangelog':
            from resources .lib .modules import changelog 
            changelog .get ()
        elif OO00O00OO0O000O0O =='tools_ShowHelp':
            from resources .help import help 
            help .get (O00O000O00000OOO0 )
        elif OO00O00OO0O000O0O =='tools_LanguageInvoker':
            from resources .lib .modules import language_invoker 
            language_invoker .set_reuselanguageinvoker ()
        elif OO00O00OO0O000O0O =='tools_toolNavigator':
            from resources .lib .menus import navigator 
            navigator .Navigator ().tools ()
        elif OO00O00OO0O000O0O =='tools_searchNavigator':
            from resources .lib .menus import navigator 
            navigator .Navigator ().search ()
        elif OO00O00OO0O000O0O =='tools_viewsNavigator':
            from resources .lib .menus import navigator 
            navigator .Navigator ().views ()
        elif OO00O00OO0O000O0O =='tools_addView':
            from resources .lib .modules import views 
            O0O00O00OOOO0OOO0 =OOO0OO0OO0OO00O0O .get ('content')
            views .addView (O0O00O00OOOO0OOO0 )
        elif OO00O00OO0O000O0O =='tools_resetViewTypes':
            from resources .lib .modules import views 
            views .clearViews ()
        elif OO00O00OO0O000O0O =='tools_cleanSettings':
            from resources .lib .modules import clean_settings 
            clean_settings .clean_settings ()
        elif OO00O00OO0O000O0O =='tools_openMyAccount':
            from myaccounts import openMASettings 
            from resources .lib .modules import my_accounts 
            openMASettings (O00OO0O0000O0OO0O )
            control .sleep (500 )
            while control .condVisibility ('Window.IsVisible(addonsettings)')or control .homeWindow .getProperty ('myaccounts.active')=='true':
                control .sleep (500 )
            control .sleep (100 )
            my_accounts .syncMyAccounts ()
            control .sleep (100 )
            if OOO0OO0OO0OO00O0O .get ('opensettings')=='true':
                control .openSettings (OOO0OO0OO0OO00O0O .get ('query2'),'plugin.video.le')
        elif OO00O00OO0O000O0O =='tools_syncMyAccount':
            from resources .lib .modules import my_accounts 
            my_accounts .syncMyAccounts ()
            if OOO0OO0OO0OO00O0O .get ('opensettings')=='true':
                control .openSettings (O00OO0O0000O0OO0O ,'plugin.video.le')
        elif OO00O00OO0O000O0O =='tools_traktAcctMyAccounts':
            control .execute ('RunScript(script.module.myaccounts, action=traktAcct)')
        elif OO00O00OO0O000O0O =='tools_adAcctMyAccounts':
            control .execute ('RunScript(script.module.myaccounts, action=alldebridAcct)')
        elif OO00O00OO0O000O0O =='tools_pmAcctMyAccounts':
            control .execute ('RunScript(script.module.myaccounts, action=premiumizeAcct)')
        elif OO00O00OO0O000O0O =='tools_rdAcctMyAccounts':
            control .execute ('RunScript(script.module.myaccounts, action=realdebridAcct)')
        elif OO00O00OO0O000O0O =='tools_openSettings':
            control .openSettings (O00OO0O0000O0OO0O )
        elif OO00O00OO0O000O0O =='tools_contextLESettings':
            control .openSettings ('0.0','context.le')
            control .trigger_widget_refresh ()
        elif OO00O00OO0O000O0O =='tools_UpNextSettings':
            control .openSettings ('0.0','service.upnext')
            control .sleep (500 )
            while control .condVisibility ('Window.IsVisible(addonsettings)'):
                control .sleep (500 )
            control .sleep (100 )
            if OOO0OO0OO0OO00O0O .get ('opensettings')=='true':
                control .openSettings (O00OO0O0000O0OO0O ,'plugin.video.le')
        elif OO00O00OO0O000O0O =='tools_fenomscrapersSettings':
            control .openSettings ('0.0','script.module.fenomscrapers')
        elif OO00O00OO0O000O0O =='resolveurlSettings':
            control .openSettings (O00OO0O0000O0OO0O ,"script.module.resolveurl")
        elif OO00O00OO0O000O0O =='cache_clearResolveURLcache':
            if control .condVisibility ('System.HasAddon(script.module.resolveurl)'):
                control .execute ('RunPlugin(plugin://script.module.resolveurl/?mode=reset_cache)')
        elif OO00O00OO0O000O0O =='tools_traktManager':
            from resources .lib .modules import trakt 
            trakt .manager (O00O000O00000OOO0 ,OO000OOOOOO00O000 ,OO00OOO0O00O000O0 ,OOOOOOOO00OO00000 ,O000000000000OO00 )
        elif OO00O00OO0O000O0O =='tools_cachesyncMovies':
            from resources .lib .modules import trakt 
            trakt .cachesyncMovies (int (OOO0OO0OO0OO00O0O .get ('timeout')))
        elif OO00O00OO0O000O0O =='tools_cachesyncTVShows':
            from resources .lib .modules import trakt 
            trakt .cachesyncTVShows (int (OOO0OO0OO0OO00O0O .get ('timeout')))
        elif OO00O00OO0O000O0O =='tools_syncTraktProgress':
            from resources .lib .modules import trakt 
            trakt .sync_progress ()
        elif OO00O00OO0O000O0O =='tools_syncTraktWatched':
            from resources .lib .modules import trakt 
            trakt .sync_watched ()
    elif OO00O00OO0O000O0O =='play':
        from resources .lib .modules import sources 
        O00O0OOO00O0000OO =OOO0OO0OO0OO00O0O .get ('premiered')
        OO00OO00OOO00O0OO =OOO0OO0OO0OO00O0O .get ('meta')
        O0O00OOO00000O000 =OOO0OO0OO0OO00O0O .get ('select')
        OO00OO0000OOO0O0O =OOO0OO0OO0OO00O0O .get ('rescrape')
        sources .Sources ().play (OO0O0O0OO00O00O00 ,O00O00O00O0OOO000 ,OO000OOOOOO00O000 ,O0OO0O000OOO000O0 ,OO00OOO0O00O000O0 ,OOOOOOOO00OO00000 ,O000000000000OO00 ,OOO000OOOOOO00000 ,O00O0OOO00O0000OO ,OO00OO00OOO00O0OO ,O0O00OOO00000O000 ,OO00OO0000OOO0O0O )
    elif OO00O00OO0O000O0O =='playAll':
        control .player2 ().play (control .playlist )
    elif OO00O00OO0O000O0O =='playURL':
        O000O0OO0O0O00OOO =OOO0OO0OO0OO00O0O .get ('caller')
        if O000O0OO0O0O00OOO =='realdebrid':
            from resources .lib .debrid import realdebrid 
            if OOOO00O000OOO0000 =='unrestrict':control .player .play (realdebrid .RealDebrid ().unrestrict_link (O0OOO000OOO0O0O00 .replace (' ','%20')))
            else :control .player .play (O0OOO000OOO0O0O00 .replace (' ','%20'))
        elif O000O0OO0O0O00OOO =='alldebrid':
            from resources .lib .debrid import alldebrid 
            if OOOO00O000OOO0000 =='unrestrict':control .player .play (alldebrid .AllDebrid ().unrestrict_link (O0OOO000OOO0O0O00 .replace (' ','%20')))
            else :control .player .play (O0OOO000OOO0O0O00 .replace (' ','%20'))
        else :control .player .play (O0OOO000OOO0O0O00 .replace (' ','%20'))
    elif OO00O00OO0O000O0O =='playItem':
        from resources .lib .modules import sources 
        sources .Sources ().playItem (OO0O0O0OO00O00O00 ,O0OO0OO0OO0O000OO )
    elif OO00O00OO0O000O0O =='addItem':
        from resources .lib .modules import sources 
        sources .Sources ().addItem (OO0O0O0OO00O00O00 )
    elif OO00O00OO0O000O0O =='alterSources':
        from resources .lib .modules import sources 
        OO00OO00OOO00O0OO =OOO0OO0OO0OO00O0O .get ('meta')
        sources .Sources ().alterSources (O0OOO000OOO0O0O00 ,OO00OO00OOO00O0OO )
    elif OO00O00OO0O000O0O =='trailer':
        from resources .lib .modules import trailer 
        O0OO0OO00O0OO00O0 =OOO0OO0OO0OO00O0O .get ('windowedtrailer')
        O0OO0OO00O0OO00O0 =int (O0OO0OO00O0OO00O0 )if O0OO0OO00O0OO00O0 in ("0","1")else 0 
        trailer .Trailer ().play (OOOO00O000OOO0000 ,O00O000O00000OOO0 ,O00O00O00O0OOO000 ,O0OOO000OOO0O0O00 ,OO000OOOOOO00O000 ,O0OO0OO00O0OO00O0 )
    elif OO00O00OO0O000O0O =='showDebridPack':
        from resources .lib .modules .sources import Sources 
        O000O0OO0O0O00OOO =OOO0OO0OO0OO00O0O .get ('caller')
        Sources ().debridPackDialog (O000O0OO0O0O00OOO ,O00O000O00000OOO0 ,O0OOO000OOO0O0O00 ,O0OO0OO0OO0O000OO )
    elif OO00O00OO0O000O0O =='sourceInfo':
        from resources .lib .modules .sources import Sources 
        Sources ().sourceInfo (O0OO0OO0OO0O000OO )
    elif OO00O00OO0O000O0O =='cacheTorrent':
        O000O0OO0O0O00OOO =OOO0OO0OO0OO00O0O .get ('caller')
        O00O00OOOO00OOOO0 =True if OOOO00O000OOO0000 =='pack'else False 
        if O000O0OO0O0O00OOO =='RD':
            from resources .lib .debrid .realdebrid import RealDebrid as debrid_function 
        elif O000O0OO0O0O00OOO =='PM':
            from resources .lib .debrid .premiumize import Premiumize as debrid_function 
        elif O000O0OO0O0O00OOO =='AD':
            from resources .lib .debrid .alldebrid import AllDebrid as debrid_function 
        O00O0OOOOO00OOOO0 =debrid_function ().add_uncached_torrent (O0OOO000OOO0O0O00 ,pack =O00O00OOOO00OOOO0 )
        if O00O0OOOOO00OOOO0 :
            from resources .lib .modules import sources 
            sources .Sources ().playItem (OO0O0O0OO00O00O00 ,O0OO0OO0OO0O000OO )
    elif OO00O00OO0O000O0O =='random':
        OOO0OO00OOO00OO00 =OOO0OO0OO0OO00O0O .get ('rtype')
        if OOO0OO00OOO00OO00 =='movie':
            from resources .lib .menus import movies 
            OO0OOOO0OO00OO00O =movies .Movies ().get (O0OOO000OOO0O0O00 ,create_directory =False )
            OOO0OOOOOO0OOOOOO ='plugin://plugin.video.le/?action=play'
        elif OOO0OO00OOO00OO00 =='episode':
            from resources .lib .menus import episodes 
            OO00OO00OOO00O0OO =OOO0OO0OO0OO00O0O .get ('meta')
            OO0OOOO0OO00OO00O =episodes .Episodes ().get (OOO000OOOOOO00000 ,O00O00O00O0OOO000 ,OO000OOOOOO00O000 ,O0OO0O000OOO000O0 ,OO00OOO0O00O000O0 ,OO00OO00OOO00O0OO ,OOOOOOOO00OO00000 ,create_directory =False )
            OOO0OOOOOO0OOOOOO ='plugin://plugin.video.le/?action=play'
        elif OOO0OO00OOO00OO00 =='season':
            from resources .lib .menus import seasons 
            OOO0OOOO0O00O0O0O =OOO0OO0OO0OO00O0O .get ('art')
            OO0OOOO0OO00OO00O =seasons .Seasons ().get (OOO000OOOOOO00000 ,O00O00O00O0OOO000 ,OO000OOOOOO00O000 ,O0OO0O000OOO000O0 ,OO00OOO0O00O000O0 ,OOO0OOOO0O00O0O0O ,create_directory =False )
            OOO0OOOOOO0OOOOOO ='plugin://plugin.video.le/?action=random&rtype=episode'
        elif OOO0OO00OOO00OO00 =='show':
            from resources .lib .menus import tvshows 
            OO0OOOO0OO00OO00O =tvshows .TVshows ().get (O0OOO000OOO0O0O00 ,create_directory =False )
            OOO0OOOOOO0OOOOOO ='plugin://plugin.video.le/?action=random&rtype=season'
        from random import randint 
        from json import dumps as jsdumps 
        try :
            O0OOO0OOOOO00OO0O =randint (1 ,len (OO0OOOO0OO00OO00O ))-1 
            for OO00OO0O0OO00O0O0 in ['title','year','imdb','tmdb','tvdb','season','episode','tvshowtitle','premiered','select']:
                if OOO0OO00OOO00OO00 =="show"and OO00OO0O0OO00O0O0 =="tvshowtitle":
                    try :OOO0OOOOOO0OOOOOO +='&'+OO00OO0O0OO00O0O0 +'='+quote_plus (OO0OOOO0OO00OO00O [O0OOO0OOOOO00OO0O ]['title'])
                    except :pass 
                else :
                    try :OOO0OOOOOO0OOOOOO +='&'+OO00OO0O0OO00O0O0 +'='+quote_plus (str (OO0OOOO0OO00OO00O [O0OOO0OOOOO00OO0O ][OO00OO0O0OO00O0O0 ]))
                    except :pass 
            try :OOO0OOOOOO0OOOOOO +='&meta='+quote_plus (jsdumps (OO0OOOO0OO00OO00O [O0OOO0OOOOO00OO0O ]))
            except :OOO0OOOOOO0OOOOOO +='&meta='+quote_plus ("{}")
            if OOO0OO00OOO00OO00 =="movie":
                try :control .notification (title =32536 ,message ='%s (%s)'%(OO0OOOO0OO00OO00O [O0OOO0OOOOO00OO0O ]['title'],OO0OOOO0OO00OO00O [O0OOO0OOOOO00OO0O ]['year']))
                except :pass 
            elif OOO0OO00OOO00OO00 =="episode":
                try :control .notification (title =32536 ,message ='%s - %01dx%02d - %s'%(OO0OOOO0OO00OO00O [O0OOO0OOOOO00OO0O ]['tvshowtitle'],int (OO0OOOO0OO00OO00O [O0OOO0OOOOO00OO0O ]['season']),int (OO0OOOO0OO00OO00O [O0OOO0OOOOO00OO0O ]['episode']),OO0OOOO0OO00OO00O [O0OOO0OOOOO00OO0O ]['title']))
                except :pass 
            control .execute ('RunPlugin(%s)'%OOO0OOOOOO0OOOOOO )
        except :
            control .notification (message =32537 )
    elif OO00O00OO0O000O0O and OO00O00OO0O000O0O .startswith ('playlist_'):
        if OO00O00OO0O000O0O =='playlist_Manager':
            from resources .lib .modules import playlist 
            OOO0OOOO0O00O0O0O =OOO0OO0OO0OO00O0O .get ('art')
            OO00OO00OOO00O0OO =OOO0OO0OO0OO00O0O .get ('meta')
            playlist .playlistManager (O00O000O00000OOO0 ,O0OOO000OOO0O0O00 ,OO00OO00OOO00O0OO ,OOO0OOOO0O00O0O0O )
        elif OO00O00OO0O000O0O =='playlist_Show':
            from resources .lib .modules import playlist 
            playlist .playlistShow ()
        elif OO00O00OO0O000O0O =='playlist_Clear':
            from resources .lib .modules import playlist 
            playlist .playlistClear ()
        elif OO00O00OO0O000O0O =='playlist_QueueItem':
            control .queueItem ()
            if O00O000O00000OOO0 is None :
                control .notification (title =35515 ,message =35519 )
            else :
                control .notification (title =O00O000O00000OOO0 ,message =35519 )
    elif OO00O00OO0O000O0O and OO00O00OO0O000O0O .startswith ('playcount_'):
        if OO00O00OO0O000O0O =='playcount_Movie':
            from resources .lib .modules import playcount 
            playcount .movies (O00O000O00000OOO0 ,OO000OOOOOO00O000 ,O00OO0O0000O0OO0O )
        elif OO00O00OO0O000O0O =='playcount_Episode':
            from resources .lib .modules import playcount 
            playcount .episodes (O00O000O00000OOO0 ,OO000OOOOOO00O000 ,OO00OOO0O00O000O0 ,OOOOOOOO00OO00000 ,O000000000000OO00 ,O00OO0O0000O0OO0O )
        elif OO00O00OO0O000O0O =='playcount_TVShow':
            from resources .lib .modules import playcount 
            playcount .tvshows (O00O000O00000OOO0 ,OO000OOOOOO00O000 ,OO00OOO0O00O000O0 ,OOOOOOOO00OO00000 ,O00OO0O0000O0OO0O )
    elif OO00O00OO0O000O0O and OO00O00OO0O000O0O .startswith ('library_'):
        if OO00O00OO0O000O0O =='library_Navigator':
            from resources .lib .menus import navigator 
            navigator .Navigator ().library ()
        elif OO00O00OO0O000O0O =='library_movieToLibrary':
            from resources .lib .modules import library 
            library .libmovies ().add (O00O000O00000OOO0 ,OO0O0O0OO00O00O00 ,O00O00O00O0OOO000 ,OO000OOOOOO00O000 ,O0OO0O000OOO000O0 )
        elif OO00O00OO0O000O0O =='library_moviesToLibrary':
            from resources .lib .modules import library 
            library .libmovies ().range (O0OOO000OOO0O0O00 ,O00O000O00000OOO0 )
        elif OO00O00OO0O000O0O =='library_moviesListToLibrary':
            from resources .lib .menus import movies 
            movies .Movies ().moviesListToLibrary (O0OOO000OOO0O0O00 )
        elif OO00O00OO0O000O0O =='library_moviesToLibrarySilent':
            from resources .lib .modules import library 
            library .libmovies ().silent (O0OOO000OOO0O0O00 )
        elif OO00O00OO0O000O0O =='library_tvshowToLibrary':
            from resources .lib .modules import library 
            library .libtvshows ().add (OOO000OOOOOO00000 ,O00O00O00O0OOO000 ,OO000OOOOOO00O000 ,O0OO0O000OOO000O0 ,OO00OOO0O00O000O0 )
        elif OO00O00OO0O000O0O =='library_tvshowsToLibrary':
            from resources .lib .modules import library 
            library .libtvshows ().range (O0OOO000OOO0O0O00 ,O00O000O00000OOO0 )
        elif OO00O00OO0O000O0O =='library_tvshowsListToLibrary':
            from resources .lib .menus import tvshows 
            tvshows .TVshows ().tvshowsListToLibrary (O0OOO000OOO0O0O00 )
        elif OO00O00OO0O000O0O =='library_tvshowsToLibrarySilent':
            from resources .lib .modules import library 
            library .libtvshows ().silent (O0OOO000OOO0O0O00 )
        elif OO00O00OO0O000O0O =='library_update':
            control .notification (message =32085 )
            from resources .lib .modules import library 
            library .libepisodes ().update ()
            library .libmovies ().list_update ()
            library .libtvshows ().list_update ()
            while True :
                if control .condVisibility ('Library.IsScanningVideo'):
                    control .sleep (3000 )
                    continue 
                else :
                    break 
            control .sleep (1000 )
            control .notification (message =32086 )
        elif OO00O00OO0O000O0O =='library_clean':
            from resources .lib .modules import library 
            library .lib_tools ().clean ()
        elif OO00O00OO0O000O0O =='library_setup':
            from resources .lib .modules import library 
            library .lib_tools ().total_setup ()
        elif OO00O00OO0O000O0O =='library_service':
            from resources .lib .modules import library 
            library .lib_tools ().service ()
    elif OO00O00OO0O000O0O and OO00O00OO0O000O0O .startswith ('cache_'):
        if OO00O00OO0O000O0O =='cache_Navigator':
            from resources .lib .menus import navigator 
            navigator .Navigator ().cf ()
        elif OO00O00OO0O000O0O =='cache_clearAll':
            from resources .lib .menus import navigator 
            navigator .Navigator ().clearCacheAll ()
        elif OO00O00OO0O000O0O =='cache_clearSources':
            from resources .lib .menus import navigator 
            navigator .Navigator ().clearCacheProviders ()
        elif OO00O00OO0O000O0O =='cache_clearMeta':
            from resources .lib .menus import navigator 
            navigator .Navigator ().clearCacheMeta ()
        elif OO00O00OO0O000O0O =='cache_clearCache':
            from resources .lib .menus import navigator 
            navigator .Navigator ().clearCache ()
        elif OO00O00OO0O000O0O =='cache_clearSearch':
            from resources .lib .menus import navigator 
            navigator .Navigator ().clearCacheSearch ()
        elif OO00O00OO0O000O0O =='cache_clearSearchPhrase':
            from resources .lib .menus import navigator 
            navigator .Navigator ().clearCacheSearchPhrase (O0OO0OO0OO0O000OO ,O00O000O00000OOO0 )
        elif OO00O00OO0O000O0O =='cache_clearBookmarks':
            from resources .lib .menus import navigator 
            navigator .Navigator ().clearBookmarks ()
        elif OO00O00OO0O000O0O =='cache_clearBookmark':
            from resources .lib .menus import navigator 
            navigator .Navigator ().clearBookmark (O00O000O00000OOO0 ,O00O00O00O0OOO000 )
        elif OO00O00OO0O000O0O =='cache_clearKodiBookmark':
            from resources .lib .database import cache 
            cache .clear_local_bookmark (O0OOO000OOO0O0O00 )