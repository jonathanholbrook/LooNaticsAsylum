# -*- coding: utf-8 -*-
#      __    ____  ____  _   _____  _____________________
#     / /   / __ \/ __ \/ | / /   |/_  __/  _/ ____/ ___/
#    / /   / / / / / / /  |/ / /| | / /  / // /    \__ \
#   / /___/ /_/ / /_/ / /|  / ___ |/ / _/ // /___ ___/ /
#  /_____/\____/\____/_/ |_/_/  |_/_/ /___/\____//____/
#

from resources.lib.modules import control

le_path = control.addonPath(control.addonId())
le_version = control.getLEVersion()
changelogfile = control.joinPath(le_path, 'changelog.txt')


def get():
	r = open(changelogfile)
	text = r.read()
	r.close()
	control.dialog.textviewer('[COLOR deepskyblue]LE[/COLOR] -  v%s - ChangeLog' % le_version, text)