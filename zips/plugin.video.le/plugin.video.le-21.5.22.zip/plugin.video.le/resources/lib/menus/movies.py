from datetime import datetime ,timedelta 
from json import dumps as jsdumps ,loads as jsloads 
import re 
from sys import argv 
try :
    from urllib import quote_plus ,urlencode 
    from urlparse import parse_qsl ,urlparse ,urlsplit 
except ImportError :
    from urllib .parse import quote_plus ,urlencode ,parse_qsl ,urlparse ,urlsplit 
from resources .lib .database import cache ,metacache 
from resources .lib .indexers import tmdb as tmdb_indexer ,fanarttv 
from resources .lib .modules import cleangenre 
from resources .lib .modules import client 
from resources .lib .modules import control 
from resources .lib .modules import log_utils 
from resources .lib .modules import playcount 
from resources .lib .modules import py_tools 
from resources .lib .modules import tools 
from resources .lib .modules import trakt 
from resources .lib .modules import views 
from resources .lib .modules import workers 
class Movies :
    def __init__ (O000OOO0O00OOO0OO ,OO00OOO0OOO00O0O0 ='movie',OOOOO0000OO0OO00O =True ):
        O000OOO0O00OOO0OO .list =[]
        O000OOO0O00OOO0OO .count =control .setting ('page.item.limit')
        O000OOO0O00OOO0OO .type =OO00OOO0OOO00O0O0 
        O000OOO0O00OOO0OO .notifications =OOOOO0000OO0OO00O 
        O000OOO0O00OOO0OO .date_time =datetime .now ()
        O000OOO0O00OOO0OO .today_date =(O000OOO0O00OOO0OO .date_time ).strftime ('%Y-%m-%d')
        O000OOO0O00OOO0OO .hidecinema =control .setting ('hidecinema')=='true'
        O000OOO0O00OOO0OO .trakt_user =control .setting ('trakt.user').strip ()
        O000OOO0O00OOO0OO .traktCredentials =trakt .getTraktCredentialsInfo ()
        O000OOO0O00OOO0OO .lang =control .apiLanguage ()['trakt']
        O000OOO0O00OOO0OO .imdb_user =control .setting ('imdb.user').replace ('ur','')
        O000OOO0O00OOO0OO .tmdb_key =control .setting ('tmdb.api.key')
        if O000OOO0O00OOO0OO .tmdb_key ==''or O000OOO0O00OOO0OO .tmdb_key is None :
            O000OOO0O00OOO0OO .tmdb_key ='3320855e65a9758297fec4f7c9717698'
        O000OOO0O00OOO0OO .tmdb_session_id =control .setting ('tmdb.session_id')
        O000OOO0O00OOO0OO .user =str (O000OOO0O00OOO0OO .tmdb_key )
        O000OOO0O00OOO0OO .disable_fanarttv =control .setting ('disable.fanarttv')=='true'
        O000OOO0O00OOO0OO .unairedcolor =control .getColor (control .setting ('movie.unaired.identify'))
        O000OOO0O00OOO0OO .highlight_color =control .getColor (control .setting ('highlight.color'))
        O000OOO0O00OOO0OO .tmdb_link ='https://api.themoviedb.org'
        O000OOO0O00OOO0OO .tmdb_popular_link ='https://api.themoviedb.org/3/movie/popular?api_key=%s&language=en-US&region=US&page=1'
        O000OOO0O00OOO0OO .tmdb_toprated_link ='https://api.themoviedb.org/3/movie/top_rated?api_key=%s&page=1'
        O000OOO0O00OOO0OO .tmdb_upcoming_link ='https://api.themoviedb.org/3/movie/upcoming?api_key=%s&language=en-US&region=US&page=1'
        O000OOO0O00OOO0OO .tmdb_nowplaying_link ='https://api.themoviedb.org/3/movie/now_playing?api_key=%s&language=en-US&region=US&page=1'
        O000OOO0O00OOO0OO .tmdb_boxoffice_link ='https://api.themoviedb.org/3/discover/movie?api_key=%s&language=en-US&region=US&sort_by=revenue.desc&page=1'
        O000OOO0O00OOO0OO .tmdb_watchlist_link ='https://api.themoviedb.org/3/account/{account_id}/watchlist/movies?api_key=%s&session_id=%s&sort_by=created_at.asc&page=1'%('%s',O000OOO0O00OOO0OO .tmdb_session_id )
        O000OOO0O00OOO0OO .tmdb_favorites_link ='https://api.themoviedb.org/3/account/{account_id}/favorite/movies?api_key=%s&session_id=%s&sort_by=created_at.asc&page=1'%('%s',O000OOO0O00OOO0OO .tmdb_session_id )
        O000OOO0O00OOO0OO .tmdb_userlists_link ='https://api.themoviedb.org/3/account/{account_id}/lists?api_key=%s&language=en-US&session_id=%s&page=1'%('%s',O000OOO0O00OOO0OO .tmdb_session_id )
        O000OOO0O00OOO0OO .imdb_link ='https://www.imdb.com'
        O000OOO0O00OOO0OO .persons_link ='https://www.imdb.com/search/name?count=100&name='
        O000OOO0O00OOO0OO .personlist_link ='https://www.imdb.com/search/name?count=100&gender=male,female'
        O000OOO0O00OOO0OO .person_link ='https://www.imdb.com/search/title?title_type=feature,tv_movie&production_status=released&role=%s&sort=year,desc&count=%s&start=1'%('%s',O000OOO0O00OOO0OO .count )
        O000OOO0O00OOO0OO .keyword_link ='https://www.imdb.com/search/title?title_type=feature,tv_movie,documentary&num_votes=100,&keywords=%s&sort=moviemeter,asc&count=%s&start=1'%('%s',O000OOO0O00OOO0OO .count )
        O000OOO0O00OOO0OO .oscars_link ='https://www.imdb.com/search/title?title_type=feature,tv_movie&production_status=released&groups=oscar_best_picture_winners&sort=year,desc&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .oscarsnominees_link ='https://www.imdb.com/search/title?title_type=feature,tv_movie&production_status=released&groups=oscar_best_picture_nominees&sort=year,desc&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .theaters_link ='https://www.imdb.com/search/title?title_type=feature&num_votes=500,&release_date=date[90],date[0]&languages=en&sort=release_date,desc&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .year_link ='https://www.imdb.com/search/title?title_type=feature,tv_movie&num_votes=100,&production_status=released&year=%s,%s&sort=moviemeter,asc&count=%s&start=1'%('%s','%s',O000OOO0O00OOO0OO .count )
        if O000OOO0O00OOO0OO .hidecinema :
            OOO0O00OO000000OO =str (int (control .setting ('hidecinema.rollback'))*30 )
            O000OOO0O00OOO0OO .mostpopular_link ='https://www.imdb.com/search/title?title_type=feature,tv_movie&num_votes=1000,&production_status=released&groups=top_1000&release_date=,date[%s]&sort=moviemeter,asc&count=%s&start=1'%(OOO0O00OO000000OO ,O000OOO0O00OOO0OO .count )
            O000OOO0O00OOO0OO .mostvoted_link ='https://www.imdb.com/search/title?title_type=feature,tv_movie&num_votes=1000,&production_status=released&release_date=,date[%s]&sort=num_votes,desc&count=%s&start=1'%(OOO0O00OO000000OO ,O000OOO0O00OOO0OO .count )
            O000OOO0O00OOO0OO .featured_link ='https://www.imdb.com/search/title?title_type=feature,tv_movie&num_votes=1000,&production_status=released&release_date=,date[%s]&sort=moviemeter,asc&count=%s&start=1'%(OOO0O00OO000000OO ,O000OOO0O00OOO0OO .count )
            O000OOO0O00OOO0OO .genre_link ='https://www.imdb.com/search/title?title_type=feature,tv_movie,documentary&num_votes=100,&release_date=,date[%s]&genres=%s&sort=moviemeter,asc&count=%s&start=1'%(OOO0O00OO000000OO ,'%s',O000OOO0O00OOO0OO .count )
            O000OOO0O00OOO0OO .language_link ='https://www.imdb.com/search/title?title_type=feature,tv_movie&num_votes=100,&production_status=released&primary_language=%s&sort=moviemeter,asc&release_date=,date[%s]&count=%s&start=1'%('%s',OOO0O00OO000000OO ,O000OOO0O00OOO0OO .count )
            O000OOO0O00OOO0OO .certification_link ='https://www.imdb.com/search/title?title_type=feature,tv_movie&num_votes=100,&production_status=released&certificates=%s&sort=moviemeter,asc&release_date=,date[%s]&count=%s&start=1'%('%s',OOO0O00OO000000OO ,O000OOO0O00OOO0OO .count )
            O000OOO0O00OOO0OO .imdbboxoffice_link ='https://www.imdb.com/search/title?title_type=feature,tv_movie&production_status=released&sort=boxoffice_gross_us,desc&release_date=,date[%s]&count=%s&start=1'%(OOO0O00OO000000OO ,O000OOO0O00OOO0OO .count )
        else :
            O000OOO0O00OOO0OO .mostpopular_link ='https://www.imdb.com/search/title?title_type=feature,tv_movie&num_votes=1000,&production_status=released&groups=top_1000&sort=moviemeter,asc&count=%s&start=1'%O000OOO0O00OOO0OO .count 
            O000OOO0O00OOO0OO .mostvoted_link ='https://www.imdb.com/search/title?title_type=feature,tv_movie&num_votes=1000,&production_status=released&sort=num_votes,desc&count=%s&start=1'%O000OOO0O00OOO0OO .count 
            O000OOO0O00OOO0OO .featured_link ='https://www.imdb.com/search/title?title_type=feature,tv_movie&num_votes=1000,&production_status=released&sort=moviemeter,asc&count=%s&start=1'%O000OOO0O00OOO0OO .count 
            O000OOO0O00OOO0OO .genre_link ='https://www.imdb.com/search/title?title_type=feature,tv_movie,documentary&num_votes=100,&release_date=,date[0]&genres=%s&sort=moviemeter,asc&count=%s&start=1'%('%s',O000OOO0O00OOO0OO .count )
            O000OOO0O00OOO0OO .language_link ='https://www.imdb.com/search/title?title_type=feature,tv_movie&num_votes=100,&production_status=released&primary_language=%s&sort=moviemeter,asc&count=%s&start=1'%('%s',O000OOO0O00OOO0OO .count )
            O000OOO0O00OOO0OO .certification_link ='https://www.imdb.com/search/title?title_type=feature,tv_movie&num_votes=100,&production_status=released&certificates=%s&sort=moviemeter,asc&count=%s&start=1'%('%s',O000OOO0O00OOO0OO .count )
            O000OOO0O00OOO0OO .imdbboxoffice_link ='https://www.imdb.com/search/title?title_type=feature,tv_movie&production_status=released&sort=boxoffice_gross_us,desc&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .imdbwatchlist_link ='https://www.imdb.com/user/ur%s/watchlist?sort=date_added,desc'%O000OOO0O00OOO0OO .imdb_user 
        O000OOO0O00OOO0OO .imdbwatchlist2_link ='https://www.imdb.com/list/%s/?view=detail&sort=%s&title_type=movie,short,video,tvShort,tvMovie,tvSpecial&start=1'%('%s',O000OOO0O00OOO0OO .imdb_sort (type ='movies.watchlist'))
        O000OOO0O00OOO0OO .imdblists_link ='https://www.imdb.com/user/ur%s/lists?tab=all&sort=mdfd&order=desc&filter=titles'%O000OOO0O00OOO0OO .imdb_user 
        O000OOO0O00OOO0OO .imdblist_link ='https://www.imdb.com/list/%s/?view=detail&sort=%s&title_type=movie,short,video,tvShort,tvMovie,tvSpecial&start=1'%('%s',O000OOO0O00OOO0OO .imdb_sort ())
        O000OOO0O00OOO0OO .imdbratings_link ='https://www.imdb.com/user/ur%s/ratings?sort=your_rating,desc&mode=detail&start=1'%O000OOO0O00OOO0OO .imdb_user 
        O000OOO0O00OOO0OO .top100_link ='https://www.imdb.com/search/title?title_type=feature&groups=top_100&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .top250_link ='https://www.imdb.com/search/title?title_type=feature&groups=top_250&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .top1000_link ='https://www.imdb.com/search/title?title_type=feature&groups=top_1000&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .rated_g_link ='https://www.imdb.com/search/title/?certificates=US%3AG'
        O000OOO0O00OOO0OO .rated_pg13_link ='https://www.imdb.com/search/title/?certificates=US%3APG-13'
        O000OOO0O00OOO0OO .rated_pg_link ='https://www.imdb.com/search/title/?certificates=US%3APG'
        O000OOO0O00OOO0OO .rated_r_link ='https://www.imdb.com/search/title/?certificates=US%3AR'
        O000OOO0O00OOO0OO .rated_nc17_link ='https://www.imdb.com/search/title/?certificates=US%3ANC-17'
        O000OOO0O00OOO0OO .bestdirector_link ='https://www.imdb.com/search/title?title_type=feature&groups=best_director_winner&sort=user_rating,desc&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .national_film_board_link ='https://www.imdb.com/search/title?title_type=feature&groups=national_film_preservation_board_winner&sort=user_rating,desc&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .dreamworks_pictures_link ='https://www.imdb.com/search/title?title_type=feature&companies=dreamworks&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .fox_pictures_link ='https://www.imdb.com/search/title?title_type=feature&companies=fox&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .paramount_pictures_link ='https://www.imdb.com/search/title?title_type=feature&companies=paramount&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .mgm_pictures_link ='https://www.imdb.com/search/title?title_type=feature&companies=mgm&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .universal_pictures_link ='https://www.imdb.com/search/title?title_type=feature&companies=universal&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .sony_pictures_link ='https://www.imdb.com/search/title?title_type=feature&companies=sony&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .warnerbrothers_pictures ='https://www.imdb.com/search/title?title_type=feature&companies=warner&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .amazon_prime_link ='https://www.imdb.com/search/title?title_type=feature&online_availability=US%2Ftoday%2FAmazon%2Fsubs'
        O000OOO0O00OOO0OO .disney_pictures_link ='https://www.imdb.com/search/title?user_rating=1.0,10.0&companies=disney&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .family_movies_link ='https://www.imdb.com/search/title/?title_type=feature&genres=family&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .classic_movies_link ='https://www.imdb.com/search/title?title_type=feature&release_date=1900-01-01,1993-12-31&sort=alpha&countries=us&languages=en&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .classic_horror_link ='https://www.imdb.com/search/title?title_type=feature&release_date=1900-01-01,1993-12-31&genres=horror&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .classic_fantasy_link ='https://www.imdb.com/search/title?title_type=feature&release_date=1900-01-01,1993-12-31&genres=fantasy&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .classic_western_link ='https://www.imdb.com/search/title?title_type=feature&release_date=1900-01-01,1993-12-31&genres=western&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .classic_animation_link ='https://www.imdb.com/search/title?title_type=feature&release_date=1900-01-01,1993-12-31&genres=animation&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .classic_war_link ='https://www.imdb.com/search/title?title_type=feature&release_date=1900-01-01,1993-12-31&genres=war&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .classic_scifi_link ='https://www.imdb.com/search/title?title_type=feature&release_date=1900-01-01,1993-12-31&genres=sci_fi&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .eighties_link ='https://www.imdb.com/search/title?title_type=feature&release_date=1980-01-01,1989-12-31&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .nineties_link ='https://www.imdb.com/search/title?title_type=feature&release_date=1990-01-01,1999-12-31&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .twentyzeros_link ='https://www.imdb.com/search/title?title_type=feature&release_date=2000-01-01,2010-12-31&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .twentyten_link ='https://www.imdb.com/search/title?title_type=feature&release_date=2010-01-01,2019-12-31&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .twentytwenty_link ='https://www.imdb.com/search/title?title_type=feature&release_date=2020-01-01,2029-12-31&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .abbottcostello_link ='https://www.imdb.com/search/title/?title_type=feature&release_date=1900-01-01,1990-12-31&countries=us&languages=en&role=nm0007941&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .lewismartin_link ='https://www.imdb.com/search/title/?title_type=feature&release_date=1900-01-01,1980-12-31&countries=us&languages=en&role=nm0001471&role=nm0001509&role=nm0001509&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .wgpicks_link ='https://www.imdb.com/list/ls083232792/?view=detail&sort=alpha,asc&title_type=movie,tvMovie,desc&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .wgaction_link ='https://www.imdb.com/list/ls044844213/?view=detail&sort=alpha,asc&title_type=movie,tvMovie,desc&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .wgapocolypse_link ='https://www.imdb.com/list/ls044846463/?view=detail&sort=alpha,asc&title_type=movie,tvMovie,desc&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .wgxmas_link ='https://www.imdb.com/list/ls086865651/?view=detail&sort=alpha,asc&title_type=movie,tvMovie,desc&count=%sstart=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .wgcomedy_link ='https://www.imdb.com/list/ls044846446/?view=detail&sort=alpha,asc&title_type=movie,tvMovie,desc&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .wgdocs_link ='https://www.imdb.com/list/ls093271498/?view=detail&sort=alpha,asc&title_type=movie,tvMovie,desc&count=%sstart=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .wgsleepy_link ='https://www.imdb.com/list/ls086468369/?view=detail&sort=alpha,asc&title_type=movie,tvMovie,desc&count=%sstart=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .wgmonster_link ='https://www.imdb.com/list/ls044849542/?view=detail&sort=alpha,asc&title_type=movie,tvMovie,desc&count=%sstart=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .wgparanormal_link ='https://www.imdb.com/list/ls095238183/?view=detail&sort=alpha,asc&title_type=movie,tvMovie,desc&count=%sstart=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .wgtoons_link ='https://www.imdb.com/list/ls087391412/?view=detail&sort=alpha,asc&title_type=movie,tvMovie,desc&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .wgvault_link ='https://www.imdb.com/list/ls090769563/?view=detail&sort=alpha,asc&title_type=movie,tvMovie,desc&count=%sstart=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .cablemovie_link ='https://www.imdb.com/list/ls094498894/?view=detail&sort=alpha,asc&title_type=movie,tvMovie&keywords=female-nudity&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .shjaysilentbob_link ='https://www.imdb.com/list/ls093291118/?view=detail&sort=alpha,asc&title_type=movie,tvMovie,desc&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .shstonermovies_link ='https://www.imdb.com/list/ls093291705/?view=detail&sort=alpha,asc&title_type=movie,tvMovie,desc&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .shmontypython_link ='https://www.imdb.com/list/ls093293549/?view=detail&sort=alpha,asc&title_type=movie,tvMovie,desc&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .shchechchong_link ='https://www.imdb.com/list/ls093297505/?view=detail&sort=alpha,asc&title_type=movie,tvMovie,desc&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .dosyfy_link ='https://www.imdb.com/list/ls096704404/?view=detail&sort=alpha,asc&title_type=movie,tvMovie,desc&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .dodrivein_link ='https://www.imdb.com/list/ls096764156/?view=detail&sort=alpha,asc&title_type=movie,tvMovie,desc&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .douniverse_link ='https://www.imdb.com/list/ls096764530/?view=detail&sort=alpha,asc&title_type=movie,tvMovie,desc&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .dopota_link ='https://www.imdb.com/list/ls096704370/?view=detail&sort=alpha,asc&title_type=movie,tvMovie,desc&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .dotimetravel_link ='https://www.imdb.com/list/ls096762438/?view=detail&sort=alpha,asc&title_type=movie,tvMovie,desc&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .slcreep_link ='https://www.imdb.com/list/ls500371586/?view=detail&sort=alpha,asc&title_type=movie,tvMovie,desc&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .slpicks_link ='https://www.imdb.com/list/ls500375959/?view=detail&sort=alpha,asc&title_type=movie,tvMovie,desc&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .slspace_link ='https://www.imdb.com/list/ls500348581/?view=detail&sort=alpha,asc&title_type=movie,tvMovie,desc&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .bumovies_link ='https://www.imdb.com/list/ls043815558/?view=detail&sort=alpha,asc&title_type=movie,tvMovie,desc&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .dcmarvelbuild_link ='https://www.imdb.com/list/ls083241114/?view=detail&sort=alpha,asc&title_type=movie,tvMovie,desc&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .dcmovies_link ='https://www.imdb.com/list/ls083349485/?view=detail&sort=alpha,asc&title_type=movie,tvMovie,desc&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .marvelmovies_link ='https://www.imdb.com/list/ls083349442/?view=detail&sort=alpha,asc&title_type=movie,tvMovie,desc&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .superhero_link ='https://www.imdb.com/list/ls083349908/?view=detail&sort=alpha,asc&title_type=movie,tvMovie,desc&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .docs_link ='https://www.imdb.com/search/title/?title_type=feature,tv_movie,short&genres=documentary&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .anime_link ='https://www.imdb.com/search/keyword?keywords=anime&title_type=movie,tvMovie&sort=moviemeter,asc&count=%s&start=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .trakt_link ='https://api.trakt.tv'
        O000OOO0O00OOO0OO .search_link ='https://api.trakt.tv/search/movie?limit=%s&page=1&query='%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .traktlistsearch_link ='https://api.trakt.tv/search/list?limit=%s&page=1&query='%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .traktlist_link ='https://api.trakt.tv/users/%s/lists/%s/items/movies'
        O000OOO0O00OOO0OO .traktlikedlists_link ='https://api.trakt.tv/users/likes/lists?limit=1000000'
        O000OOO0O00OOO0OO .traktlists_link ='https://api.trakt.tv/users/me/lists'
        O000OOO0O00OOO0OO .traktwatchlist_link ='https://api.trakt.tv/users/me/watchlist/movies'
        O000OOO0O00OOO0OO .traktcollection_link ='https://api.trakt.tv/users/me/collection/movies'
        O000OOO0O00OOO0OO .trakthistory_link ='https://api.trakt.tv/users/me/history/movies?limit=%s&page=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .traktunfinished_link ='https://api.trakt.tv/sync/playback/movies?limit=40'
        O000OOO0O00OOO0OO .traktanticipated_link ='https://api.trakt.tv/movies/anticipated?limit=%s&page=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .trakttrending_link ='https://api.trakt.tv/movies/trending?limit=%s&page=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .traktboxoffice_link ='https://api.trakt.tv/movies/boxoffice'
        O000OOO0O00OOO0OO .traktpopular_link ='https://api.trakt.tv/movies/popular?limit=%s&page=1'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .traktrecommendations_link ='https://api.trakt.tv/recommendations/movies?limit=40'
        O000OOO0O00OOO0OO .played1_link ='https://api.trakt.tv/movies/played/weekly?page=1&limit=%s'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .played2_link ='https://api.trakt.tv/movies/played/monthly?page=1&limit=%s'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .played3_link ='https://api.trakt.tv/movies/played/yearly?page=1&limit=%s'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .played4_link ='https://api.trakt.tv/movies/played/all?page=1&limit=%s'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .collected1_link ='https://api.trakt.tv/movies/collected/weekly?page=1&limit=%s'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .collected2_link ='https://api.trakt.tv/movies/collected/monthly?page=1&limit=%s'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .collected3_link ='https://api.trakt.tv/movies/collected/yearly?page=1&limit=%s'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .collected4_link ='https://api.trakt.tv/movies/collected/all?page=1&limit=%s'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .watched1_link ='https://api.trakt.tv/movies/watched/weekly?page=1&limit=%s'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .watched2_link ='https://api.trakt.tv/movies/watched/monthly?page=1&limit=%s'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .watched3_link ='https://api.trakt.tv/movies/watched/yearly?page=1&limit=%s'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .watched4_link ='https://api.trakt.tv/movies/watched/all?page=1&limit=%s'%O000OOO0O00OOO0OO .count 
        O000OOO0O00OOO0OO .tmdbmovielist1_link =control .setting ('tmdb.movielist_id1')
        O000OOO0O00OOO0OO .tmdbmovielist2_link =control .setting ('tmdb.movielist_id2')
        O000OOO0O00OOO0OO .tmdbmovielist3_link =control .setting ('tmdb.movielist_id3')
        O000OOO0O00OOO0OO .tmdbmovielist4_link =control .setting ('tmdb.movielist_id4')
        O000OOO0O00OOO0OO .tmdbmovielist5_link =control .setting ('tmdb.movielist_id5')
        O000OOO0O00OOO0OO .tmdbmovielist6_link =control .setting ('tmdb.movielist_id6')
        O000OOO0O00OOO0OO .tmdbmovielist7_link =control .setting ('tmdb.movielist_id7')
        O000OOO0O00OOO0OO .tmdbmovielist8_link =control .setting ('tmdb.movielist_id8')
        O000OOO0O00OOO0OO .tmdbmovielist9_link =control .setting ('tmdb.movielist_id9')
        O000OOO0O00OOO0OO .tmdbmovielist10_link =control .setting ('tmdb.movielist_id10')
        O000OOO0O00OOO0OO .mycustomlist1_link ='https://api.themoviedb.org/3/list/%s?api_key=%s'%(O000OOO0O00OOO0OO .tmdbmovielist1_link ,O000OOO0O00OOO0OO .tmdb_key )
        O000OOO0O00OOO0OO .mycustomlist2_link ='https://api.themoviedb.org/3/list/%s?api_key=%s'%(O000OOO0O00OOO0OO .tmdbmovielist2_link ,O000OOO0O00OOO0OO .tmdb_key )
        O000OOO0O00OOO0OO .mycustomlist3_link ='https://api.themoviedb.org/3/list/%s?api_key=%s'%(O000OOO0O00OOO0OO .tmdbmovielist3_link ,O000OOO0O00OOO0OO .tmdb_key )
        O000OOO0O00OOO0OO .mycustomlist4_link ='https://api.themoviedb.org/3/list/%s?api_key=%s'%(O000OOO0O00OOO0OO .tmdbmovielist4_link ,O000OOO0O00OOO0OO .tmdb_key )
        O000OOO0O00OOO0OO .mycustomlist5_link ='https://api.themoviedb.org/3/list/%s?api_key=%s'%(O000OOO0O00OOO0OO .tmdbmovielist5_link ,O000OOO0O00OOO0OO .tmdb_key )
        O000OOO0O00OOO0OO .mycustomlist6_link ='https://api.themoviedb.org/3/list/%s?api_key=%s'%(O000OOO0O00OOO0OO .tmdbmovielist6_link ,O000OOO0O00OOO0OO .tmdb_key )
        O000OOO0O00OOO0OO .mycustomlist7_link ='https://api.themoviedb.org/3/list/%s?api_key=%s'%(O000OOO0O00OOO0OO .tmdbmovielist7_link ,O000OOO0O00OOO0OO .tmdb_key )
        O000OOO0O00OOO0OO .mycustomlist8_link ='https://api.themoviedb.org/3/list/%s?api_key=%s'%(O000OOO0O00OOO0OO .tmdbmovielist8_link ,O000OOO0O00OOO0OO .tmdb_key )
        O000OOO0O00OOO0OO .mycustomlist9_link ='https://api.themoviedb.org/3/list/%s?api_key=%s'%(O000OOO0O00OOO0OO .tmdbmovielist9_link ,O000OOO0O00OOO0OO .tmdb_key )
        O000OOO0O00OOO0OO .mycustomlist10_link ='https://api.themoviedb.org/3/list/%s?api_key=%s'%(O000OOO0O00OOO0OO .tmdbmovielist10_link ,O000OOO0O00OOO0OO .tmdb_key )
        O000OOO0O00OOO0OO .tmdbmymovlist1_link =control .setting ('tmdb.mymovlist_id1')
        O000OOO0O00OOO0OO .tmdbmymovlist2_link =control .setting ('tmdb.mymovlist_id2')
        O000OOO0O00OOO0OO .tmdbmymovlist3_link =control .setting ('tmdb.mymovlist_id3')
        O000OOO0O00OOO0OO .tmdbmymovlist4_link =control .setting ('tmdb.mymovlist_id4')
        O000OOO0O00OOO0OO .tmdbmymovlist5_link =control .setting ('tmdb.mymovlist_id5')
        O000OOO0O00OOO0OO .tmdbmymovlist6_link =control .setting ('tmdb.mymovlist_id6')
        O000OOO0O00OOO0OO .tmdbmymovlist7_link =control .setting ('tmdb.mymovlist_id7')
        O000OOO0O00OOO0OO .tmdbmymovlist8_link =control .setting ('tmdb.mymovlist_id8')
        O000OOO0O00OOO0OO .tmdbmymovlist9_link =control .setting ('tmdb.mymovlist_id9')
        O000OOO0O00OOO0OO .tmdbmymovlist10_link =control .setting ('tmdb.mymovlist_id10')
        O000OOO0O00OOO0OO .mycustommovlist1_link ='https://api.themoviedb.org/3/list/%s?api_key=%s'%(O000OOO0O00OOO0OO .tmdbmymovlist1_link ,O000OOO0O00OOO0OO .tmdb_key )
        O000OOO0O00OOO0OO .mycustommovlist2_link ='https://api.themoviedb.org/3/list/%s?api_key=%s'%(O000OOO0O00OOO0OO .tmdbmymovlist2_link ,O000OOO0O00OOO0OO .tmdb_key )
        O000OOO0O00OOO0OO .mycustommovlist3_link ='https://api.themoviedb.org/3/list/%s?api_key=%s'%(O000OOO0O00OOO0OO .tmdbmymovlist3_link ,O000OOO0O00OOO0OO .tmdb_key )
        O000OOO0O00OOO0OO .mycustommovlist4_link ='https://api.themoviedb.org/3/list/%s?api_key=%s'%(O000OOO0O00OOO0OO .tmdbmymovlist4_link ,O000OOO0O00OOO0OO .tmdb_key )
        O000OOO0O00OOO0OO .mycustommovlist5_link ='https://api.themoviedb.org/3/list/%s?api_key=%s'%(O000OOO0O00OOO0OO .tmdbmymovlist5_link ,O000OOO0O00OOO0OO .tmdb_key )
        O000OOO0O00OOO0OO .mycustommovlist6_link ='https://api.themoviedb.org/3/list/%s?api_key=%s'%(O000OOO0O00OOO0OO .tmdbmymovlist6_link ,O000OOO0O00OOO0OO .tmdb_key )
        O000OOO0O00OOO0OO .mycustommovlist7_link ='https://api.themoviedb.org/3/list/%s?api_key=%s'%(O000OOO0O00OOO0OO .tmdbmymovlist7_link ,O000OOO0O00OOO0OO .tmdb_key )
        O000OOO0O00OOO0OO .mycustommovlist8_link ='https://api.themoviedb.org/3/list/%s?api_key=%s'%(O000OOO0O00OOO0OO .tmdbmymovlist8_link ,O000OOO0O00OOO0OO .tmdb_key )
        O000OOO0O00OOO0OO .mycustommovlist9_link ='https://api.themoviedb.org/3/list/%s?api_key=%s'%(O000OOO0O00OOO0OO .tmdbmymovlist9_link ,O000OOO0O00OOO0OO .tmdb_key )
        O000OOO0O00OOO0OO .mycustommovlist10_link ='https://api.themoviedb.org/3/list/%s?api_key=%s'%(O000OOO0O00OOO0OO .tmdbmymovlist10_link ,O000OOO0O00OOO0OO .tmdb_key )
    def get (O00O00OO00OOO0OO0 ,O0000OOO0O00O0OO0 ,O0O000OO0OOO0O00O =True ,OOO000O0OOOOOOO00 =True ):
        O00O00OO00OOO0OO0 .list =[]
        try :
            try :O0000OOO0O00O0OO0 =getattr (O00O00OO00OOO0OO0 ,O0000OOO0O00O0OO0 +'_link')
            except :pass 
            try :O00OO0O0OO00OO0O0 =urlparse (O0000OOO0O00O0OO0 ).netloc .lower ()
            except :pass 
            if O00OO0O0OO00OO0O0 in O00O00OO00OOO0OO0 .trakt_link and '/users/'in O0000OOO0O00O0OO0 :
                try :
                    OOO0O00O0O00000OO =(O0000OOO0O00O0OO0 .split ('&page=')[0 ]in O00O00OO00OOO0OO0 .trakthistory_link )
                    if '/users/me/'not in O0000OOO0O00O0OO0 :raise Exception ()
                    if trakt .getActivity ()>cache .timeout (O00O00OO00OOO0OO0 .trakt_list ,O0000OOO0O00O0OO0 ,O00O00OO00OOO0OO0 .trakt_user ):raise Exception ()
                    O00O00OO00OOO0OO0 .list =cache .get (O00O00OO00OOO0OO0 .trakt_list ,720 ,O0000OOO0O00O0OO0 ,O00O00OO00OOO0OO0 .trakt_user )
                    if OOO0O00O0O00000OO :
                        for O00O000OOOO0O000O in range (len (O00O00OO00OOO0OO0 .list )):O00O00OO00OOO0OO0 .list [O00O000OOOO0O000O ]['traktHistory']=True 
                except :
                    O00O00OO00OOO0OO0 .list =cache .get (O00O00OO00OOO0OO0 .trakt_list ,0 ,O0000OOO0O00O0OO0 ,O00O00OO00OOO0OO0 .trakt_user )
                    if OOO0O00O0O00000OO :
                        for O00O000OOOO0O000O in range (len (O00O00OO00OOO0OO0 .list )):O00O00OO00OOO0OO0 .list [O00O000OOOO0O000O ]['traktHistory']=True 
                if O0O000OO0OOO0O00O :O00O00OO00OOO0OO0 .worker ()
                if O0000OOO0O00O0OO0 ==O00O00OO00OOO0OO0 .traktwatchlist_link :O00O00OO00OOO0OO0 .sort (type ='movies.watchlist')
                else :
                    if not OOO0O00O0O00000OO :O00O00OO00OOO0OO0 .sort ()
            elif O00OO0O0OO00OO0O0 in O00O00OO00OOO0OO0 .trakt_link and O00O00OO00OOO0OO0 .search_link in O0000OOO0O00O0OO0 :
                O00O00OO00OOO0OO0 .list =cache .get (O00O00OO00OOO0OO0 .trakt_list ,6 ,O0000OOO0O00O0OO0 ,O00O00OO00OOO0OO0 .trakt_user )
                if O0O000OO0OOO0O00O :O00O00OO00OOO0OO0 .worker (level =0 )
            elif O00OO0O0OO00OO0O0 in O00O00OO00OOO0OO0 .trakt_link :
                O00O00OO00OOO0OO0 .list =cache .get (O00O00OO00OOO0OO0 .trakt_list ,24 ,O0000OOO0O00O0OO0 ,O00O00OO00OOO0OO0 .trakt_user )
                if O0O000OO0OOO0O00O :O00O00OO00OOO0OO0 .worker ()
            elif O00OO0O0OO00OO0O0 in O00O00OO00OOO0OO0 .imdb_link and ('/user/'in O0000OOO0O00O0OO0 or '/list/'in O0000OOO0O00O0OO0 ):
                OOO0O0000O0OOO00O =True if O00O00OO00OOO0OO0 .imdbratings_link in O0000OOO0O00O0OO0 else False 
                O00O00OO00OOO0OO0 .list =cache .get (O00O00OO00OOO0OO0 .imdb_list ,0 ,O0000OOO0O00O0OO0 ,OOO0O0000O0OOO00O )
                if O0O000OO0OOO0O00O :O00O00OO00OOO0OO0 .worker ()
            elif O00OO0O0OO00OO0O0 in O00O00OO00OOO0OO0 .imdb_link :
                O00O00OO00OOO0OO0 .list =cache .get (O00O00OO00OOO0OO0 .imdb_list ,96 ,O0000OOO0O00O0OO0 )
                if O0O000OO0OOO0O00O :O00O00OO00OOO0OO0 .worker ()
            if O00O00OO00OOO0OO0 .list is None :O00O00OO00OOO0OO0 .list =[]
            if O0O000OO0OOO0O00O and OOO000O0OOOOOOO00 :O00O00OO00OOO0OO0 .movieDirectory (O00O00OO00OOO0OO0 .list )
            return O00O00OO00OOO0OO0 .list 
        except :
            log_utils .error ()
            if not O00O00OO00OOO0OO0 .list :
                control .hide ()
                if O00O00OO00OOO0OO0 .notifications :control .notification (title =32001 ,message =33049 )
    def getTMDb (OO000000O00O000OO ,OOO000O00O00O00OO ,OOO0000O0O0O00O0O =True ,OO0OOO000OOOO0000 =True ):
        OO000000O00O000OO .list =[]
        try :
            try :OOO000O00O00O00OO =getattr (OO000000O00O000OO ,OOO000O00O00O00OO +'_link')
            except :pass 
            try :O0O00000OOOOO000O =urlparse (OOO000O00O00O00OO ).netloc .lower ()
            except :pass 
            if O0O00000OOOOO000O in OO000000O00O000OO .tmdb_link and '/list/'in OOO000O00O00O00OO :
                OO000000O00O000OO .list =cache .get (tmdb_indexer .Movies ().tmdb_collections_list ,0 ,OOO000O00O00O00OO )
                OO000000O00O000OO .sort ()
            elif O0O00000OOOOO000O in OO000000O00O000OO .tmdb_link and not '/list/'in OOO000O00O00O00OO :
                O00000O000OOOOOOO =168 if OO0OOO000OOOO0000 else 0 
                OO000000O00O000OO .list =cache .get (tmdb_indexer .Movies ().tmdb_list ,O00000O000OOOOOOO ,OOO000O00O00O00OO )
            if OO000000O00O000OO .list is None :OO000000O00O000OO .list =[]
            if OOO0000O0O0O00O0O :OO000000O00O000OO .movieDirectory (OO000000O00O000OO .list )
            return OO000000O00O000OO .list 
        except :
            log_utils .error ()
            if not OO000000O00O000OO .list :
                control .hide ()
                if OO000000O00O000OO .notifications :control .notification (title =32001 ,message =33049 )
    def unfinished (O000OO00O000OOO0O ,OOOOO0O0O0OO00O0O ,OO0O00OOO00OO0O00 =True ):
        O000OO00O000OOO0O .list =[]
        try :
            try :OOOOO0O0O0OO00O0O =getattr (O000OO00O000OOO0O ,OOOOO0O0O0OO00O0O +'_link')
            except :pass 
            O0O0O0O0000OO000O =trakt .getPausedActivity ()
            if OOOOO0O0O0OO00O0O ==O000OO00O000OOO0O .traktunfinished_link :
                try :
                    if O0O0O0O0000OO000O >cache .timeout (O000OO00O000OOO0O .trakt_list ,O000OO00O000OOO0O .traktunfinished_link ,O000OO00O000OOO0O .trakt_user ):
                        raise Exception ()
                    O000OO00O000OOO0O .list =cache .get (O000OO00O000OOO0O .trakt_list ,720 ,O000OO00O000OOO0O .traktunfinished_link ,O000OO00O000OOO0O .trakt_user )
                except :
                    O000OO00O000OOO0O .list =cache .get (O000OO00O000OOO0O .trakt_list ,0 ,O000OO00O000OOO0O .traktunfinished_link ,O000OO00O000OOO0O .trakt_user )
                if OO0O00OOO00OO0O00 :O000OO00O000OOO0O .worker ()
            if OO0O00OOO00OO0O00 :
                O000OO00O000OOO0O .list =sorted (O000OO00O000OOO0O .list ,key =lambda OO0000OO00OO0OOOO :OO0000OO00OO0OOOO ['paused_at'],reverse =True )
                O000OO00O000OOO0O .movieDirectory (O000OO00O000OOO0O .list ,unfinished =True ,next =False )
            return O000OO00O000OOO0O .list 
        except :
            log_utils .error ()
            if not O000OO00O000OOO0O .list :
                control .hide ()
                if O000OO00O000OOO0O .notifications :control .notification (title =32001 ,message =33049 )
    def sort (O0O00OO0O00O000O0 ,OO0OO0OOOOO0OO00O ='movies'):
        try :
            if not O0O00OO0O00O000O0 .list :return 
            OOOOOO000O0OO0000 =int (control .setting ('sort.%s.type'%OO0OO0OOOOO0OO00O ))
            O0OOOOOOO0OOOO00O =int (control .setting ('sort.%s.order'%OO0OO0OOOOO0OO00O ))==1 
            if OOOOOO000O0OO0000 ==0 :O0OOOOOOO0OOOO00O =False 
            if OOOOOO000O0OO0000 >0 :
                if OOOOOO000O0OO0000 ==1 :
                    try :O0O00OO0O00O000O0 .list =sorted (O0O00OO0O00O000O0 .list ,key =lambda OO0OOO0000O0000OO :re .sub (r'(^the |^a |^an )','',OO0OOO0000O0000OO ['title'].lower ()),reverse =O0OOOOOOO0OOOO00O )
                    except :O0O00OO0O00O000O0 .list =sorted (O0O00OO0O00O000O0 .list ,key =lambda OO0OO0OO00OOO0OOO :OO0OO0OO00OOO0OOO ['title'].lower (),reverse =O0OOOOOOO0OOOO00O )
                elif OOOOOO000O0OO0000 ==2 :O0O00OO0O00O000O0 .list =sorted (O0O00OO0O00O000O0 .list ,key =lambda OO00000OOOOOO0OO0 :float (OO00000OOOOOO0OO0 ['rating']),reverse =O0OOOOOOO0OOOO00O )
                elif OOOOOO000O0OO0000 ==3 :O0O00OO0O00O000O0 .list =sorted (O0O00OO0O00O000O0 .list ,key =lambda O0OO00O0OOO0O0OOO :int (O0OO00O0OOO0O0OOO ['votes'].replace (',','')),reverse =O0OOOOOOO0OOOO00O )
                elif OOOOOO000O0OO0000 ==4 :
                    for OOO0O0OOOO00O0O00 in range (len (O0O00OO0O00O000O0 .list )):
                        if 'premiered'not in O0O00OO0O00O000O0 .list [OOO0O0OOOO00O0O00 ]:O0O00OO0O00O000O0 .list [OOO0O0OOOO00O0O00 ]['premiered']=''
                    O0O00OO0O00O000O0 .list =sorted (O0O00OO0O00O000O0 .list ,key =lambda O0OO00O0OO0O0O0O0 :O0OO00O0OO0O0O0O0 ['premiered'],reverse =O0OOOOOOO0OOOO00O )
                elif OOOOOO000O0OO0000 ==5 :
                    for OOO0O0OOOO00O0O00 in range (len (O0O00OO0O00O000O0 .list )):
                        if 'added'not in O0O00OO0O00O000O0 .list [OOO0O0OOOO00O0O00 ]:O0O00OO0O00O000O0 .list [OOO0O0OOOO00O0O00 ]['added']=''
                    O0O00OO0O00O000O0 .list =sorted (O0O00OO0O00O000O0 .list ,key =lambda O0O0OO0000O0OOOO0 :O0O0OO0000O0OOOO0 ['added'],reverse =O0OOOOOOO0OOOO00O )
                elif OOOOOO000O0OO0000 ==6 :
                    for OOO0O0OOOO00O0O00 in range (len (O0O00OO0O00O000O0 .list )):
                        if 'lastplayed'not in O0O00OO0O00O000O0 .list [OOO0O0OOOO00O0O00 ]:O0O00OO0O00O000O0 .list [OOO0O0OOOO00O0O00 ]['lastplayed']=''
                    O0O00OO0O00O000O0 .list =sorted (O0O00OO0O00O000O0 .list ,key =lambda OO000OO0OOO00OOOO :OO000OO0OOO00OOOO ['lastplayed'],reverse =O0OOOOOOO0OOOO00O )
            elif O0OOOOOOO0OOOO00O :
                O0O00OO0O00O000O0 .list =list (reversed (O0O00OO0O00O000O0 .list ))
        except :
            log_utils .error ()
    def imdb_sort (OOOOOOO00OOO00O0O ,OO000OO0000O0OOO0 ='movies'):
        O0000O0O00OO0OOO0 =int (control .setting ('sort.%s.type'%OO000OO0000O0OOO0 ))
        O0O0OO00O0000OOO0 ='list_order'
        if O0000O0O00OO0OOO0 ==1 :O0O0OO00O0000OOO0 ='alpha'
        if O0000O0O00OO0OOO0 in [2 ,3 ]:O0O0OO00O0000OOO0 ='user_rating'
        if O0000O0O00OO0OOO0 ==4 :O0O0OO00O0000OOO0 ='release_date'
        if O0000O0O00OO0OOO0 in [5 ,6 ]:O0O0OO00O0000OOO0 ='date_added'
        O0O0O0OOOOOO0O000 =',asc'if int (control .setting ('sort.%s.order'%OO000OO0000O0OOO0 ))==0 else ',desc'
        OO00OO00OOO0OOOOO =O0O0OO00O0000OOO0 +O0O0O0OOOOOO0O000 
        return OO00OO00OOO0OOOOO 
    def tmdb_sort (OO0000OO0OOO0000O ):
        O000OO0O00000OOOO =int (control .setting ('sort.movies.type'))
        O000O00OOO0O0OO00 ='original_order'
        if O000OO0O00000OOOO ==1 :O000O00OOO0O0OO00 ='title'
        if O000OO0O00000OOOO in [2 ,3 ]:O000O00OOO0O0OO00 ='vote_average'
        if O000OO0O00000OOOO in [4 ,5 ,6 ]:O000O00OOO0O0OO00 ='release_date'
        OOO00000OOO00000O ='.asc'if int (control .setting ('sort.movies.order'))==0 else '.desc'
        OO0O0OO00O00O0OO0 =O000O00OOO0O0OO00 +OOO00000OOO00000O 
        return OO0O0OO00O00O0OO0 
    def search (OO0O0OOOOO0OO00OO ):
        from resources .lib .menus import navigator 
        navigator .Navigator ().addDirectoryItem (32603 ,'movieSearchnew','search.png','DefaultAddonsSearch.png')
        try :from sqlite3 import dbapi2 as database 
        except ImportError :from pysqlite2 import dbapi2 as database 
        try :
            if not control .existsPath (control .dataPath ):control .makeFile (control .dataPath )
            OOOO0O0O00O000O0O =database .connect (control .searchFile )
            OO0000OOOO0O00O0O =OOOO0O0O00O000O0O .cursor ()
            OO0000OOOO0O00O0O .executescript ('''CREATE TABLE IF NOT EXISTS movies (ID Integer PRIMARY KEY AUTOINCREMENT, term);''')
            OO0000OOOO0O00O0O .execute ('''SELECT * FROM movies ORDER BY ID DESC''')
            OO0000OOOO0O00O0O .connection .commit ()
            OO000000OO0O0OO0O =[]
            OOOOO00O00O00O00O =False 
            for (OOOO00000OOOO000O ,OO0OO0000OO000O00 )in OO0000OOOO0O00O0O .fetchall ():
                OO0OO0000OO000O00 =py_tools .ensure_str (OO0OO0000OO000O00 )
                if OO0OO0000OO000O00 not in str (OO000000OO0O0OO0O ):
                    OOOOO00O00O00O00O =True 
                    navigator .Navigator ().addDirectoryItem (OO0OO0000OO000O00 ,'movieSearchterm&name=%s'%OO0OO0000OO000O00 ,'search.png','DefaultAddonsSearch.png',isSearch =True ,table ='movies')
                    OO000000OO0O0OO0O +=[(OO0OO0000OO000O00 )]
        except :
            log_utils .error ()
        finally :
            OO0000OOOO0O00O0O .close ();OOOO0O0O00O000O0O .close ()
        if OOOOO00O00O00O00O :
            navigator .Navigator ().addDirectoryItem (32605 ,'cache_clearSearch','tools.png','DefaultAddonService.png',isFolder =False )
        navigator .Navigator ().endDirectory ()
    def search_new (O0000000O0OO000OO ):
        OOO00O00O0O0000OO =control .lang (32010 )
        O00O00000OO00O0OO =control .keyboard ('',OOO00O00O0O0000OO )
        O00O00000OO00O0OO .doModal ()
        O00OOOOOOO0OOOO0O =O00O00000OO00O0OO .getText ()if O00O00000OO00O0OO .isConfirmed ()else None 
        if not O00OOOOOOO0OOOO0O :return 
        try :from sqlite3 import dbapi2 as database 
        except ImportError :from pysqlite2 import dbapi2 as database 
        try :
            OO00000OOOO00O00O =database .connect (control .searchFile )
            O00OOO00000OOOOO0 =OO00000OOOO00O00O .cursor ()
            O00OOO00000OOOOO0 .execute ('''INSERT INTO movies VALUES (?,?)''',(None ,O00OOOOOOO0OOOO0O ))
            O00OOO00000OOOOO0 .connection .commit ()
        except :
            log_utils .error ()
        finally :
            O00OOO00000OOOOO0 .close ();OO00000OOOO00O00O .close ()
        O00000000OOO0OO0O =O0000000O0OO000OO .search_link +quote_plus (O00OOOOOOO0OOOO0O )
        if control .getKodiVersion ()>=18 :
            O0000000O0OO000OO .get (O00000000OOO0OO0O )
        else :
            O00000000OOO0OO0O ='%s?action=moviePage&url=%s'%(argv [0 ],quote_plus (O00000000OOO0OO0O ))
            control .execute ('Container.Update(%s)'%O00000000OOO0OO0O )
    def search_term (OOOO0OO0O00O0OOOO ,O0O0O00OOOO000OO0 ):
        OOOOOO00O0O0OO0OO =OOOO0OO0O00O0OOOO .search_link +quote_plus (O0O0O00OOOO000OO0 )
        OOOO0OO0O00O0OOOO .get (OOOOOO00O0O0OO0OO )
    def person (OO0OOO0OOO0O00000 ):
        O0O0OOOO0OOOO00O0 =control .lang (32010 )
        O0OO0000OO00OO00O =control .keyboard ('',O0O0OOOO0OOOO00O0 )
        O0OO0000OO00OO00O .doModal ()
        OO0O0OOOOO00O0O00 =O0OO0000OO00OO00O .getText ().strip ()if O0OO0000OO00OO00O .isConfirmed ()else None 
        if not OO0O0OOOOO00O0O00 :return 
        O0O0O0O0O000O00O0 =OO0OOO0OOO0O00000 .persons_link +quote_plus (OO0O0OOOOO00O0O00 )
        OO0OOO0OOO0O00000 .persons (O0O0O0O0O000O00O0 )
    def genres (O0O0OOOO0OOOOOOO0 ):
        OOO000O000OOOOOOO =[('Action','action',True ),('Adventure','adventure',True ),('Animation','animation',True ),('Biography','biography',True ),('Comedy','comedy',True ),('Crime','crime',True ),('Documentary','documentary',True ),('Drama','drama',True ),('Family','family',True ),('Fantasy','fantasy',True ),('Film-Noir','film-noir',True ),('History','history',True ),('Horror','horror',True ),('Music ','music',True ),('Musical','musical',True ),('Mystery','mystery',True ),('Romance','romance',True ),('Science Fiction','sci-fi',True ),('Sport','sport',True ),('Thriller','thriller',True ),('War','war',True ),('Western','western',True )]
        for O000O00000OOOOO00 in OOO000O000OOOOOOO :
            O0O0OOOO0OOOOOOO0 .list .append ({'name':cleangenre .lang (O000O00000OOOOO00 [0 ],O0O0OOOO0OOOOOOO0 .lang ),'url':O0O0OOOO0OOOOOOO0 .genre_link %O000O00000OOOOO00 [1 ]if O000O00000OOOOO00 [2 ]else O0O0OOOO0OOOOOOO0 .keyword_link %O000O00000OOOOO00 [1 ],'image':'genres.png','icon':'DefaultGenre.png','action':'movies'})
        O0O0OOOO0OOOOOOO0 .addDirectory (O0O0OOOO0OOOOOOO0 .list )
        return O0O0OOOO0OOOOOOO0 .list 
    def languages (OO0O00000O000OOOO ):
        OO0O0000O0000OOOO =[('Arabic','ar'),('Bosnian','bs'),('Bulgarian','bg'),('Chinese','zh'),('Croatian','hr'),('Dutch','nl'),('English','en'),('Finnish','fi'),('French','fr'),('German','de'),('Greek','el'),('Hebrew','he'),('Hindi ','hi'),('Hungarian','hu'),('Icelandic','is'),('Italian','it'),('Japanese','ja'),('Korean','ko'),('Macedonian','mk'),('Norwegian','no'),('Persian','fa'),('Polish','pl'),('Portuguese','pt'),('Punjabi','pa'),('Romanian','ro'),('Russian','ru'),('Serbian','sr'),('Slovenian','sl'),('Spanish','es'),('Swedish','sv'),('Turkish','tr'),('Ukrainian','uk')]
        for OO0O00O0O0O0OOO0O in OO0O0000O0000OOOO :
            OO0O00000O000OOOO .list .append ({'name':str (OO0O00O0O0O0OOO0O [0 ]),'url':OO0O00000O000OOOO .language_link %OO0O00O0O0O0OOO0O [1 ],'image':'languages.png','icon':'DefaultAddonLanguage.png','action':'movies'})
        OO0O00000O000OOOO .addDirectory (OO0O00000O000OOOO .list )
        return OO0O00000O000OOOO .list 
    def certifications (OO0OO00O00O0O00OO ):
        OO000O0OO0OO0OOOO =[('General Audience (G)','G'),('Parental Guidance (PG)','PG'),('Parental Caution (PG-13)','PG-13'),('Parental Restriction (R)','R'),('Mature Audience (NC-17)','NC-17')]
        for OO0OO000O0000000O in OO000O0OO0OO0OOOO :
            OO0OO00O00O0O00OO .list .append ({'name':str (OO0OO000O0000000O [0 ]),'url':OO0OO00O00O0O00OO .certification_link %OO0OO00O00O0O00OO .certificatesFormat (OO0OO000O0000000O [1 ]),'image':'certificates.png','icon':'DefaultMovies.png','action':'movies'})
        OO0OO00O00O0O00OO .addDirectory (OO0OO00O00O0O00OO .list )
        return OO0OO00O00O0O00OO .list 
    def certificatesFormat (O000O0O00O00OO000 ,O000O0O00OOOO0O0O ):
        OO000O0O0O00O00OO ='US%3A'
        if not isinstance (O000O0O00OOOO0O0O ,(tuple ,list )):
            O000O0O00OOOO0O0O =[O000O0O00OOOO0O0O ]
        return ','.join ([OO000O0O0O00O00OO +OOOO000O00OO0OO00 .upper ()for OOOO000O00OO0OO00 in O000O0O00OOOO0O0O ])
    def years (OO00O000OO0O0000O ):
        O0OO0OO0OO0O00O00 =(OO00O000OO0O0000O .date_time .strftime ('%Y'))
        for OO0O0OO0000OOOOOO in range (int (O0OO0OO0OO0O00O00 )-0 ,1900 ,-1 ):
            OO00O000OO0O0000O .list .append ({'name':str (OO0O0OO0000OOOOOO ),'url':OO00O000OO0O0000O .year_link %(str (OO0O0OO0000OOOOOO ),str (OO0O0OO0000OOOOOO )),'image':'years.png','icon':'DefaultYear.png','action':'movies'})
        OO00O000OO0O0000O .addDirectory (OO00O000OO0O0000O .list )
        return OO00O000OO0O0000O .list 
    def persons (O0OO00000O00OOO00 ,O0OO0OOO00O0O0O0O ):
        if O0OO0OOO00O0O0O0O is None :O0OO00000O00OOO00 .list =cache .get (O0OO00000O00OOO00 .imdb_person_list ,24 ,O0OO00000O00OOO00 .personlist_link )
        else :O0OO00000O00OOO00 .list =cache .get (O0OO00000O00OOO00 .imdb_person_list ,1 ,O0OO0OOO00O0O0O0O )
        if len (O0OO00000O00OOO00 .list )==0 :
            control .hide ()
            control .notification (title =32010 ,message =33049 )
        for OO0000O0OO00O00O0 in range (0 ,len (O0OO00000O00OOO00 .list )):
            O0OO00000O00OOO00 .list [OO0000O0OO00O00O0 ].update ({'icon':'DefaultActor.png','action':'movies'})
        O0OO00000O00OOO00 .addDirectory (O0OO00000O00OOO00 .list )
        return O0OO00000O00OOO00 .list 
    def moviesListToLibrary (O0OO00000OO0000O0 ,O00OO0O0000OO0O00 ):
        O00OO0O0000OO0O00 =getattr (O0OO00000OO0000O0 ,O00OO0O0000OO0O00 +'_link')
        OO0OO0000OOO0O0OO =urlparse (O00OO0O0000OO0O00 ).netloc .lower ()
        try :
            control .hide ()
            if OO0OO0000OOO0O0OO in O0OO00000OO0000O0 .tmdb_link :O0O0OO0O0O0O0OOO0 =tmdb_indexer .userlists (O00OO0O0000OO0O00 )
            elif OO0OO0000OOO0O0OO in O0OO00000OO0000O0 .trakt_link :O0O0OO0O0O0O0OOO0 =O0OO00000OO0000O0 .trakt_user_list (O00OO0O0000OO0O00 ,O0OO00000OO0000O0 .trakt_user )
            O0O0OO0O0O0O0OOO0 =[(O00O000O0OO000000 ['name'],O00O000O0OO000000 ['url'])for O00O000O0OO000000 in O0O0OO0O0O0O0OOO0 ]
            OO00OO00O0OOO0OO0 =32663 
            if 'themoviedb'in O00OO0O0000OO0O00 :OO00OO00O0OOO0OO0 =32681 
            OO00OO0OOOO0OOOOO =control .selectDialog ([OOO00O0000000OOO0 [0 ]for OOO00O0000000OOO0 in O0O0OO0O0O0O0OOO0 ],control .lang (OO00OO00O0OOO0OO0 ))
            O0O0O00OO0O0OOO00 =O0O0OO0O0O0O0OOO0 [OO00OO0OOOO0OOOOO ][0 ]
            if OO00OO0OOOO0OOOOO ==-1 :return 
            O0O000O00O00OOOO0 =O0O0OO0O0O0O0OOO0 [OO00OO0OOOO0OOOOO ][1 ]
            O0O000O00O00OOOO0 =O0O000O00O00OOOO0 .split ('&sort_by')[0 ]
            from resources .lib .modules import library 
            library .libmovies ().range (O0O000O00O00OOOO0 ,O0O0O00OO0O0OOO00 )
        except :
            log_utils .error ()
            return 
    def userlists (O00OOOO00O0OO0OOO ):
        O0O000000000OO0OO =[]
        try :
            if not O00OOOO00O0OO0OOO .traktCredentials :raise Exception ()
            O0O0000OOOO00O0OO =trakt .getActivity ()
            O00OOOO00O0OO0OOO .list =[];OO00OO00OO0OOO00O =[]
            try :
                if O0O0000OOOO00O0OO >cache .timeout (O00OOOO00O0OO0OOO .trakt_user_list ,O00OOOO00O0OO0OOO .traktlists_link ,O00OOOO00O0OO0OOO .trakt_user ):raise Exception ()
                OO00OO00OO0OOO00O +=cache .get (O00OOOO00O0OO0OOO .trakt_user_list ,720 ,O00OOOO00O0OO0OOO .traktlists_link ,O00OOOO00O0OO0OOO .trakt_user )
            except :
                OO00OO00OO0OOO00O +=cache .get (O00OOOO00O0OO0OOO .trakt_user_list ,0 ,O00OOOO00O0OO0OOO .traktlists_link ,O00OOOO00O0OO0OOO .trakt_user )
            for O0OOOO000OOO00000 in range (len (OO00OO00OO0OOO00O )):OO00OO00OO0OOO00O [O0OOOO000OOO00000 ].update ({'image':'trakt.png','icon':'DefaultVideoPlaylists.png','action':'movies'})
            O0O000000000OO0OO +=OO00OO00OO0OOO00O 
        except :pass 
        try :
            if not O00OOOO00O0OO0OOO .traktCredentials :raise Exception ()
            O00OOOO00O0OO0OOO .list =[];OO00OO00OO0OOO00O =[]
            try :
                if O0O0000OOOO00O0OO >cache .timeout (O00OOOO00O0OO0OOO .trakt_user_list ,O00OOOO00O0OO0OOO .traktlikedlists_link ,O00OOOO00O0OO0OOO .trakt_user ):raise Exception ()
                OO00OO00OO0OOO00O +=cache .get (O00OOOO00O0OO0OOO .trakt_user_list ,3 ,O00OOOO00O0OO0OOO .traktlikedlists_link ,O00OOOO00O0OO0OOO .trakt_user )
            except :
                OO00OO00OO0OOO00O +=cache .get (O00OOOO00O0OO0OOO .trakt_user_list ,0 ,O00OOOO00O0OO0OOO .traktlikedlists_link ,O00OOOO00O0OO0OOO .trakt_user )
            for O0OOOO000OOO00000 in range (len (OO00OO00OO0OOO00O )):OO00OO00OO0OOO00O [O0OOOO000OOO00000 ].update ({'image':'trakt.png','icon':'DefaultVideoPlaylists.png','action':'movies'})
            O0O000000000OO0OO +=OO00OO00OO0OOO00O 
        except :pass 
        try :
            if not O00OOOO00O0OO0OOO .imdb_user :raise Exception ()
            O00OOOO00O0OO0OOO .list =[]
            OO00OO00OO0OOO00O =cache .get (O00OOOO00O0OO0OOO .imdb_user_list ,0 ,O00OOOO00O0OO0OOO .imdblists_link )
            for O0OOOO000OOO00000 in range (len (OO00OO00OO0OOO00O )):OO00OO00OO0OOO00O [O0OOOO000OOO00000 ].update ({'image':'imdb.png','icon':'DefaultVideoPlaylists.png','action':'movies'})
            O0O000000000OO0OO +=OO00OO00OO0OOO00O 
        except :pass 
        try :
            if O00OOOO00O0OO0OOO .tmdb_session_id =='':raise Exception ()
            O00OOOO00O0OO0OOO .list =[]
            OO00OO00OO0OOO00O =cache .get (tmdb_indexer .userlists ,0 ,O00OOOO00O0OO0OOO .tmdb_userlists_link )
            for O0OOOO000OOO00000 in range (len (OO00OO00OO0OOO00O )):OO00OO00OO0OOO00O [O0OOOO000OOO00000 ].update ({'image':'tmdb.png','icon':'DefaultVideoPlaylists.png','action':'tmdbmovies'})
            O0O000000000OO0OO +=OO00OO00OO0OOO00O 
        except :pass 
        O00OOOO00O0OO0OOO .list =[]
        for O0OOOO000OOO00000 in range (len (O0O000000000OO0OO )):
            O0000O00O0O0O0O0O =False 
            O0O0OO0O000O000OO =O0O000000000OO0OO [O0OOOO000OOO00000 ]['url'].replace ('/me/','/%s/'%O00OOOO00O0OO0OOO .trakt_user )
            for OO0O000OOOO0OOO00 in range (len (O00OOOO00O0OO0OOO .list )):
                if O0O0OO0O000O000OO ==O00OOOO00O0OO0OOO .list [OO0O000OOOO0OOO00 ]['url'].replace ('/me/','/%s/'%O00OOOO00O0OO0OOO .trakt_user ):
                    O0000O00O0O0O0O0O =True 
                    break 
            if not O0000O00O0O0O0O0O :O00OOOO00O0OO0OOO .list .append (O0O000000000OO0OO [O0OOOO000OOO00000 ])
        if O00OOOO00O0OO0OOO .tmdb_session_id !='':
            O00OOOO00O0OO0OOO .list .insert (0 ,{'name':control .lang (32026 ),'url':O00OOOO00O0OO0OOO .tmdb_favorites_link ,'image':'tmdb.png','icon':'DefaultVideoPlaylists.png','action':'tmdbmovies'})
        if O00OOOO00O0OO0OOO .tmdb_session_id !='':
            O00OOOO00O0OO0OOO .list .insert (0 ,{'name':control .lang (32033 ),'url':O00OOOO00O0OO0OOO .tmdb_watchlist_link ,'image':'tmdb.png','icon':'DefaultVideoPlaylists.png','action':'tmdbmovies'})
        if O00OOOO00O0OO0OOO .imdb_user !='':
            O00OOOO00O0OO0OOO .list .insert (0 ,{'name':control .lang (32033 ),'url':O00OOOO00O0OO0OOO .imdbwatchlist_link ,'image':'imdb.png','icon':'DefaultVideoPlaylists.png','action':'movies'})
        if O00OOOO00O0OO0OOO .imdb_user !='':
            O00OOOO00O0OO0OOO .list .insert (0 ,{'name':control .lang (32025 ),'url':O00OOOO00O0OO0OOO .imdbratings_link ,'image':'imdb.png','icon':'DefaultVideoPlaylists.png','action':'movies'})
        if O00OOOO00O0OO0OOO .traktCredentials :
            O00OOOO00O0OO0OOO .list .insert (0 ,{'name':control .lang (32033 ),'url':O00OOOO00O0OO0OOO .traktwatchlist_link ,'image':'trakt.png','icon':'DefaultVideoPlaylists.png','action':'movies'})
        O00OOOO00O0OO0OOO .addDirectory (O00OOOO00O0OO0OOO .list ,queue =True )
        return O00OOOO00O0OO0OOO .list 
    def trakt_list (O00000O0O000OOO0O ,O0OOOOOOO0O00O0O0 ,O00O00OOO0OO00O00 ):
        O00O0O0OO00OO0OOO =[]
        try :
            O00000000OO0OOO0O =dict (parse_qsl (urlsplit (O0OOOOOOO0O00O0O0 ).query ))
            O00000000OO0OOO0O .update ({'extended':'full'})
            O00000000OO0OOO0O =(urlencode (O00000000OO0OOO0O )).replace ('%2C',',')
            O00OO0000OOOO0000 =O0OOOOOOO0O00O0O0 .replace ('?'+urlparse (O0OOOOOOO0O00O0O0 ).query ,'')+'?'+O00000000OO0OOO0O 
            if '/related'in O00OO0000OOOO0000 :O00OO0000OOOO0000 =O00OO0000OOOO0000 +'&limit=20'
            O00OOOOO0OO00O0OO =trakt .getTraktAsJson (O00OO0000OOOO0000 )
            if not O00OOOOO0OO00O0OO :return O00O0O0OO00OO0OOO 
            OOO0O0OO0O0OO0OOO =[]
            for O0000OOO000OO0OO0 in O00OOOOO0OO00O0OO :
                try :
                    O0O000OOO000O0O00 =O0000OOO000OO0OO0 ['movie']
                    O0O000OOO000O0O00 ['added']=O0000OOO000OO0OO0 .get ('listed_at')
                    O0O000OOO000O0O00 ['paused_at']=O0000OOO000OO0OO0 .get ('paused_at','')
                    try :O0O000OOO000O0O00 ['progress']=max (0 ,min (1 ,O0000OOO000OO0OO0 ['progress']/100.0 ))
                    except :O0O000OOO000O0O00 ['progress']=''
                    try :O0O000OOO000O0O00 ['lastplayed']=O0000OOO000OO0OO0 .get ('watched_at','')
                    except :O0O000OOO000O0O00 ['lastplayed']=''
                    OOO0O0OO0O0OO0OOO .append (O0O000OOO000O0O00 )
                except :pass 
            if len (OOO0O0OO0O0OO0OOO )==0 :OOO0O0OO0O0OO0OOO =O00OOOOO0OO00O0OO 
        except :
            log_utils .error ()
            return 
        try :
            O00000000OO0OOO0O =dict (parse_qsl (urlsplit (O0OOOOOOO0O00O0O0 ).query ))
            if int (O00000000OO0OOO0O ['limit'])!=len (OOO0O0OO0O0OO0OOO ):raise Exception ()
            O00000000OO0OOO0O .update ({'page':str (int (O00000000OO0OOO0O ['page'])+1 )})
            O00000000OO0OOO0O =(urlencode (O00000000OO0OOO0O )).replace ('%2C',',')
            O0O0OO0000OO0OO00 =O0OOOOOOO0O00O0O0 .replace ('?'+urlparse (O0OOOOOOO0O00O0O0 ).query ,'')+'?'+O00000000OO0OOO0O 
        except :O0O0OO0000OO0OO00 =''
        def O0O0OOO0000000OOO (OOOOO0OOOOO0OO0O0 ):
            try :
                OO0O000O00OOO00O0 =OOOOO0OOOOO0OO0O0 
                OO0O000O00OOO00O0 ['next']=O0O0OO0000OO0OO00 
                OO0O000O00OOO00O0 ['title']=py_tools .ensure_str (OOOOO0OOOOO0OO0O0 .get ('title'))
                OO0O000O00OOO00O0 ['originaltitle']=OO0O000O00OOO00O0 ['title']
                try :OO0O000O00OOO00O0 ['premiered']=OOOOO0OOOOO0OO0O0 .get ('released','')[:10 ]
                except :OO0O000O00OOO00O0 ['premiered']=''
                OO0O000O00OOO00O0 ['year']=str (OOOOO0OOOOO0OO0O0 .get ('year',''))if OOOOO0OOOOO0OO0O0 .get ('year')else ''
                if not OO0O000O00OOO00O0 ['year']:
                    try :OO0O000O00OOO00O0 ['year']=str (OO0O000O00OOO00O0 ['premiered'][:4 ])
                    except :OO0O000O00OOO00O0 ['year']=''
                OOO0O0O0OO0OOOO0O =OOOOO0OOOOO0OO0O0 .get ('ids',{})
                OO0O000O00OOO00O0 ['imdb']=str (OOO0O0O0OO0OOOO0O .get ('imdb',''))if OOO0O0O0OO0OOOO0O .get ('imdb')else ''
                OO0O000O00OOO00O0 ['tmdb']=str (OOO0O0O0OO0OOOO0O .get ('tmdb',''))if OOO0O0O0OO0OOOO0O .get ('tmdb')else ''
                OO0O000O00OOO00O0 ['tvdb']=''
                OO0O000O00OOO00O0 ['genre']=[]
                for OO0O00O00O00O0O0O in OOOOO0OOOOO0OO0O0 ['genres']:OO0O000O00OOO00O0 ['genre'].append (OO0O00O00O00O0O0O .title ())
                if not OO0O000O00OOO00O0 ['genre']:OO0O000O00OOO00O0 ['genre']='NA'
                OO0O000O00OOO00O0 ['duration']=int (OOOOO0OOOOO0OO0O0 .get ('runtime')*60 )if OOOOO0OOOOO0OO0O0 .get ('runtime')else ''
                OO0O000O00OOO00O0 ['rating']=OOOOO0OOOOO0OO0O0 .get ('rating')
                OO0O000O00OOO00O0 ['votes']=OOOOO0OOOOO0OO0O0 ['votes']
                OO0O000O00OOO00O0 ['mpaa']=OOOOO0OOOOO0OO0O0 .get ('certification','')
                OO0O000O00OOO00O0 ['plot']=py_tools .ensure_str (OOOOO0OOOOO0OO0O0 .get ('overview'))
                OO0O000O00OOO00O0 ['poster']=''
                OO0O000O00OOO00O0 ['fanart']=''
                try :OO0O000O00OOO00O0 ['trailer']=control .trailer %OOOOO0OOOOO0OO0O0 ['trailer'].split ('v=')[1 ]
                except :OO0O000O00OOO00O0 ['trailer']=''
                for O0000OO0000O000O0 in ('released','ids','genres','runtime','certification','overview','comment_count','network'):OO0O000O00OOO00O0 .pop (O0000OO0000O000O0 ,None )
                O00O0O0OO00OO0OOO .append (OO0O000O00OOO00O0 )
            except :
                log_utils .error ()
        O00000000000O000O =[]
        for O00OOO000O0O0O0OO in OOO0O0OO0O0OO0OOO :O00000000000O000O .append (workers .Thread (O0O0OOO0000000OOO ,O00OOO000O0O0O0OO ))
        [OOOOOO0OO000OOO00 .start ()for OOOOOO0OO000OOO00 in O00000000000O000O ]
        [O0000OOOO00OO000O .join ()for O0000OOOO00OO000O in O00000000000O000O ]
        return O00O0O0OO00OO0OOO 
    def trakt_user_list (O0O00OOO0O0OO0000 ,OOO00000000O0000O ,OO0O0OO00OOOO0O00 ):
        try :
            O0OO0000000000O00 =trakt .getTrakt (OOO00000000O0000O )
            OO0O0000OO00OO00O =jsloads (O0OO0000000000O00 )
        except :
            log_utils .error ()
        for O000O00000O00000O in OO0O0000OO00OO00O :
            try :
                try :OOOOO000000O00000 =O000O00000O00000O ['list']['name']
                except :OOOOO000000O00000 =O000O00000O00000O ['name']
                OOOOO000000O00000 =client .replaceHTMLCodes (OOOOO000000O00000 )
                try :OOO00000000O0000O =(trakt .slug (O000O00000O00000O ['list']['user']['username']),O000O00000O00000O ['list']['ids']['slug'])
                except :OOO00000000O0000O =('me',O000O00000O00000O ['ids']['slug'])
                OOO00000000O0000O =O0O00OOO0O0OO0000 .traktlist_link %OOO00000000O0000O 
                O0O00OOO0O0OO0000 .list .append ({'name':OOOOO000000O00000 ,'url':OOO00000000O0000O ,'context':OOO00000000O0000O })
            except :
                log_utils .error ()
        O0O00OOO0O0OO0000 .list =sorted (O0O00OOO0O0OO0000 .list ,key =lambda O00OO0O0000O0OO00 :re .sub (r'(^the |^a |^an )','',O00OO0O0000O0OO00 ['name'].lower ()))
        return O0O00OOO0O0OO0000 .list 
    def imdb_list (O0O0OOOOOOOOOOO0O ,O000O000OOO0OOO0O ,OO0OOO0OOOO0OO00O =False ):
        O000O0OO0000OOO00 =[]
        try :
            for O0OO0OOO0O0O0OO00 in re .findall (r'date\[(\d+)\]',O000O000OOO0OOO0O ):
                O000O000OOO0OOO0O =O000O000OOO0OOO0O .replace ('date[%s]'%O0OO0OOO0O0O0OO00 ,(O0O0OOOOOOOOOOO0O .date_time -timedelta (days =int (O0OO0OOO0O0O0OO00 ))).strftime ('%Y-%m-%d'))
            def OOOO00O0O0O0O000O (OOO0OOOOO0O000OOO ):
                return client .parseDOM (client .request (OOO0OOOOO0O000OOO ),'meta',ret ='content',attrs ={'property':'pageId'})[0 ]
            if O000O000OOO0OOO0O ==O0O0OOOOOOOOOOO0O .imdbwatchlist_link :
                O000O000OOO0OOO0O =cache .get (OOOO00O0O0O0O000O ,8640 ,O000O000OOO0OOO0O )
                O000O000OOO0OOO0O =O0O0OOOOOOOOOOO0O .imdbwatchlist2_link %O000O000OOO0OOO0O 
            OOOO00O000OO0OOOO =client .request (O000O000OOO0OOO0O )
            OOOO00O000OO0OOOO =OOOO00O000OO0OOOO .replace ('\n',' ')
            OOOO0O0OO0OOOOO0O =client .parseDOM (OOOO00O000OO0OOOO ,'div',attrs ={'class':'.+? lister-item'})+client .parseDOM (OOOO00O000OO0OOOO ,'div',attrs ={'class':'lister-item .+?'})
            OOOO0O0OO0OOOOO0O +=client .parseDOM (OOOO00O000OO0OOOO ,'div',attrs ={'class':'list_item.+?'})
        except :
            log_utils .error ()
            return 
        OO0OO0O0O00O00OO0 =''
        try :
            OOOO00O000OO0OOOO =OOOO00O000OO0OOOO .replace ('"class="lister-page-next','" class="lister-page-next')
            OO0OO0O0O00O00OO0 =client .parseDOM (OOOO00O000OO0OOOO ,'a',ret ='href',attrs ={'class':'.*?lister-page-next.*?'})
            if len (OO0OO0O0O00O00OO0 )==0 :
                OO0OO0O0O00O00OO0 =client .parseDOM (OOOO00O000OO0OOOO ,'div',attrs ={'class':'pagination'})[0 ]
                OO0OO0O0O00O00OO0 =zip (client .parseDOM (OO0OO0O0O00O00OO0 ,'a',ret ='href'),client .parseDOM (OO0OO0O0O00O00OO0 ,'a'))
                OO0OO0O0O00O00OO0 =[O0000O000000O00O0 [0 ]for O0000O000000O00O0 in OO0OO0O0O00O00OO0 if 'Next'in O0000O000000O00O0 [1 ]]
            OO0OO0O0O00O00OO0 =O000O000OOO0OOO0O .replace (urlparse (O000O000OOO0OOO0O ).query ,urlparse (OO0OO0O0O00O00OO0 [0 ]).query )
            OO0OO0O0O00O00OO0 =client .replaceHTMLCodes (OO0OO0O0O00O00OO0 )
        except :OO0OO0O0O00O00OO0 =''
        for OO0OO0OO0O0OO0O00 in OOOO0O0OO0OOOOO0O :
            try :
                O0O00O000OO0OOO0O =client .replaceHTMLCodes (client .parseDOM (OO0OO0OO0O0OO0O00 ,'a')[1 ])
                O0O00O000OO0OOO0O =py_tools .ensure_str (O0O00O000OO0OOO0O )
                O00OO0O00O0O00OO0 =client .parseDOM (OO0OO0OO0O0OO0O00 ,'span',attrs ={'class':'lister-item-year.+?'})
                try :O00OO0O00O0O00OO0 =re .findall (r'(\d{4})',O00OO0O00O0O00OO0 [0 ])[0 ]
                except :continue 
                if int (O00OO0O00O0O00OO0 )>int ((O0O0OOOOOOOOOOO0O .date_time ).strftime ('%Y')):continue 
                O000O00OO00000OO0 =client .parseDOM (OO0OO0OO0O0OO0O00 ,'a',ret ='href')[0 ]
                O000O00OO00000OO0 =re .findall (r'(tt\d*)',O000O00OO00000OO0 )[0 ]
                try :O0O00OOOO0OO0O000 ='–'.decode ('utf-8')in str (O00OO0O00O0O00OO0 ).decode ('utf-8')or '-'.decode ('utf-8')in str (O00OO0O00O0O00OO0 ).decode ('utf-8')
                except :O0O00OOOO0OO0O000 =False 
                if O0O00OOOO0OO0O000 or 'Episode:'in OO0OO0OO0O0OO0O00 :raise Exception ()
                O000O0OO0000OOO00 .append ({'title':O0O00O000OO0OOO0O ,'originaltitle':O0O00O000OO0OOO0O ,'year':O00OO0O00O0O00OO0 ,'imdb':O000O00OO00000OO0 ,'tmdb':'','tvdb':'','next':OO0OO0O0O00O00OO0 })
            except :
                log_utils .error ()
        return O000O0OO0000OOO00 
    def imdb_person_list (OOOO0O0OOOOO00000 ,O00000OOO00OO00O0 ):
        OOOO0O0OOOOO00000 .list =[]
        try :
            O0O000000OOO0OOOO =client .request (O00000OOO00OO00O0 )
            OOO0OOO00O00O0O00 =client .parseDOM (O0O000000OOO0OOOO ,'div',attrs ={'class':'.+?etail'})
        except :return 
        for O00O00O00O000OO00 in OOO0OOO00O00O0O00 :
            try :
                OOO0O0OO000O0OO0O =client .parseDOM (O00O00O00O000OO00 ,'img',ret ='alt')[0 ]
                O00000OOO00OO00O0 =client .parseDOM (O00O00O00O000OO00 ,'a',ret ='href')[0 ]
                O00000OOO00OO00O0 =re .findall (r'(nm\d*)',O00000OOO00OO00O0 ,re .I )[0 ]
                O00000OOO00OO00O0 =OOOO0O0OOOOO00000 .person_link %O00000OOO00OO00O0 
                O00000OOO00OO00O0 =client .replaceHTMLCodes (O00000OOO00OO00O0 )
                OO00O0000OOOOO0OO =client .parseDOM (O00O00O00O000OO00 ,'img',ret ='src')[0 ]
                OO00O0000OOOOO0OO =re .sub (r'(?:_SX|_SY|_UX|_UY|_CR|_AL)(?:\d+|_).+?\.','_SX500.',OO00O0000OOOOO0OO )
                OO00O0000OOOOO0OO =client .replaceHTMLCodes (OO00O0000OOOOO0OO )
                OOOO0O0OOOOO00000 .list .append ({'name':OOO0O0OO000O0OO0O ,'url':O00000OOO00OO00O0 ,'image':OO00O0000OOOOO0OO })
            except :
                log_utils .error ()
        return OOOO0O0OOOOO00000 .list 
    def imdb_user_list (O0O00O00O0000OO0O ,OOO0OOOO0000OO000 ):
        OOO0OO0O000OOO00O =[]
        try :
            OO000OO00000O0OO0 =client .request (OOO0OOOO0000OO000 )
            O0OO0OO0OO0O00OOO =client .parseDOM (OO000OO00000O0OO0 ,'li',attrs ={'class':'ipl-zebra-list__item user-list'})
        except :
            log_utils .error ()
        for O000OO0O00OO0O0OO in O0OO0OO0OO0O00OOO :
            try :
                OO00OOOOOOO000O00 =client .parseDOM (O000OO0O00OO0O0OO ,'a')[0 ]
                OO00OOOOOOO000O00 =client .replaceHTMLCodes (OO00OOOOOOO000O00 )
                OOO0OOOO0000OO000 =client .parseDOM (O000OO0O00OO0O0OO ,'a',ret ='href')[0 ]
                OOO0OOOO0000OO000 =OOO0OOOO0000OO000 .split ('/list/',1 )[-1 ].strip ('/')
                OOO0OOOO0000OO000 =O0O00O00O0000OO0O .imdblist_link %OOO0OOOO0000OO000 
                OOO0OOOO0000OO000 =client .replaceHTMLCodes (OOO0OOOO0000OO000 )
                OOO0OO0O000OOO00O .append ({'name':OO00OOOOOOO000O00 ,'url':OOO0OOOO0000OO000 ,'context':OOO0OOOO0000OO000 })
            except :
                log_utils .error ()
        OOO0OO0O000OOO00O =sorted (OOO0OO0O000OOO00O ,key =lambda OO000OO000OO0OO0O :re .sub (r'(^the |^a |^an )','',OO000OO000OO0OO0O ['name'].lower ()))
        return OOO0OO0O000OOO00O 
    def worker (OOO0OOOO00OOOO000 ,OO0O0O0O0000OOOO0 =1 ):
        try :
            if not OOO0OOOO00OOOO000 .list :return 
            OOO0OOOO00OOOO000 .meta =[]
            O00OOOO0OO0000O0O =len (OOO0OOOO00OOOO000 .list )
            for O00OOO0O00000O0OO in range (0 ,O00OOOO0OO0000O0O ):
                OOO0OOOO00OOOO000 .list [O00OOO0O00000O0OO ].update ({'metacache':False })
            OOO0OOOO00OOOO000 .list =metacache .fetch (OOO0OOOO00OOOO000 .list ,OOO0OOOO00OOOO000 .lang ,OOO0OOOO00OOOO000 .user )
            for OO00OOO0OO0000O00 in range (0 ,O00OOOO0OO0000O0O ,40 ):
                O0000OOOO0OO0OO00 =[]
                for O00OOO0O00000O0OO in range (OO00OOO0OO0000O00 ,OO00OOO0OO0000O00 +40 ):
                    if O00OOO0O00000O0OO <O00OOOO0OO0000O0O :O0000OOOO0OO0OO00 .append (workers .Thread (OOO0OOOO00OOOO000 .super_info ,O00OOO0O00000O0OO ))
                [OOOOOOO00O00OO00O .start ()for OOOOOOO00O00OO00O in O0000OOOO0OO0OO00 ]
                [OO0000OOO00O0O000 .join ()for OO0000OOO00O0O000 in O0000OOOO0OO0OO00 ]
            if OOO0OOOO00OOOO000 .meta :
                OOO0OOOO00OOOO000 .meta =[O0OOO0O0OOO0OOO00 for O0OOO0O0OOO0OOO00 in OOO0OOOO00OOOO000 .meta if O0OOO0O0OOO0OOO00 .get ('tmdb')]
                metacache .insert (OOO0OOOO00OOOO000 .meta )
            OOO0OOOO00OOOO000 .list =[O000OO0OO0OOO0O00 for O000OO0OO0OOO0O00 in OOO0OOOO00OOOO000 .list if O000OO0OO0OOO0O00 .get ('tmdb')]
        except :
            log_utils .error ()
    def super_info (O0OO0O00OOO000OO0 ,O00OO0OOO0O00OOO0 ):
        try :
            if O0OO0O00OOO000OO0 .list [O00OO0OOO0O00OOO0 ]['metacache']:return 
            O0OO00OOO000OOO00 =O0OO0O00OOO000OO0 .list [O00OO0OOO0O00OOO0 ].get ('imdb','');O0O0O0OOO0O000OOO =O0OO0O00OOO000OO0 .list [O00OO0OOO0O00OOO0 ].get ('tmdb','')
            if not O0O0O0OOO0O000OOO and O0OO00OOO000OOO00 :
                try :
                    OO00OO0OOOOO0000O =tmdb_indexer .Movies ().IdLookup (O0OO00OOO000OOO00 )
                    O0O0O0OOO0O000OOO =str (OO00OO0OOOOO0000O .get ('id',''))if OO00OO0OOOOO0000O .get ('id')else ''
                except :O0O0O0OOO0O000OOO =''
            if not O0O0O0OOO0O000OOO and O0OO00OOO000OOO00 :
                O0OO0OOOOOOO00O00 =trakt .IdLookup ('imdb',O0OO00OOO000OOO00 ,'movie')
                if O0OO0OOOOOOO00O00 :O0O0O0OOO0O000OOO =str (O0OO0OOOOOOO00O00 .get ('tmdb',''))if O0OO0OOOOOOO00O00 .get ('tmdb')else ''
            if not O0O0O0OOO0O000OOO and not O0OO00OOO000OOO00 :
                log_utils .log ('Third fallback attempt to fetch missing ids for movie title: (%s)'%O0OO0O00OOO000OO0 .list [O00OO0OOO0O00OOO0 ]['title'],__name__ ,log_utils .LOGDEBUG )
                try :
                    O00OOOO0OOO00O00O =trakt .SearchMovie (title =quote_plus (O0OO0O00OOO000OO0 .list [O00OO0OOO0O00OOO0 ]['title']),year =O0OO0O00OOO000OO0 .list [O00OO0OOO0O00OOO0 ]['year'],fields ='title',full =False )
                    if O00OOOO0OOO00O00O [0 ]['movie']['title']!=O0OO0O00OOO000OO0 .list [O00OO0OOO0O00OOO0 ]['title']or O00OOOO0OOO00O00O [0 ]['movie']['year']!=O0OO0O00OOO000OO0 .list [O00OO0OOO0O00OOO0 ]['year']:return 
                    OOOOOOO0O0O0OOOOO =O00OOOO0OOO00O00O [0 ].get ('movie',{}).get ('ids',{})
                    if not O0O0O0OOO0O000OOO :O0O0O0OOO0O000OOO =str (OOOOOOO0O0O0OOOOO .get ('tmdb',''))if OOOOOOO0O0O0OOOOO .get ('tmdb')else ''
                    if not O0OO00OOO000OOO00 :O0OO00OOO000OOO00 =str (OOOOOOO0O0O0OOOOO .get ('imdb',''))if OOOOOOO0O0O0OOOOO .get ('imdb')else ''
                except :pass 
            if not O0O0O0OOO0O000OOO :return 
            O0OO00OOO0000000O =cache .get (tmdb_indexer .Movies ().get_movie_meta ,96 ,O0O0O0OOO0O000OOO )
            if not O0OO00OOO0000000O :return 
            O00OO00000OO0OOOO ={}
            O00OO00000OO0OOOO .update (O0OO00OOO0000000O )
            if 'rating'in O0OO0O00OOO000OO0 .list [O00OO0OOO0O00OOO0 ]and O0OO0O00OOO000OO0 .list [O00OO0OOO0O00OOO0 ]['rating']:del O00OO00000OO0OOOO ['rating']
            if 'votes'in O0OO0O00OOO000OO0 .list [O00OO0OOO0O00OOO0 ]and O0OO0O00OOO000OO0 .list [O00OO0OOO0O00OOO0 ]['votes']:del O00OO00000OO0OOOO ['votes']
            if not O0OO00OOO000OOO00 :O0OO00OOO000OOO00 =O00OO00000OO0OOOO .get ('imdb','')
            if not O00OO00000OO0OOOO .get ('imdb'):O00OO00000OO0OOOO ['imdb']=O0OO00OOO000OOO00 
            if not O00OO00000OO0OOOO .get ('tmdb'):O00OO00000OO0OOOO ['tmdb']=O0O0O0OOO0O000OOO 
            try :
                if O0OO0O00OOO000OO0 .lang =='en'or O0OO0O00OOO000OO0 .lang not in O00OO00000OO0OOOO .get ('available_translations',[O0OO0O00OOO000OO0 .lang ]):raise Exception ()
                OOOOOOO00O00000O0 =trakt .getMovieTranslation (O0OO00OOO000OOO00 ,O0OO0O00OOO000OO0 .lang ,full =True )
                OOOOO00O00OO0O0OO =OOOOOOO00O00000O0 .get ('title')or OOOOO00O00OO0O0OO 
                O000000000000OO00 =OOOOOOO00O00000O0 .get ('overview')or O000000000000OO00 
            except :
                log_utils .error ()
            if not O0OO0O00OOO000OO0 .disable_fanarttv :
                OO0000000O0O0O000 =cache .get (fanarttv .get_movie_art ,168 ,O0OO00OOO000OOO00 ,O0O0O0OOO0O000OOO )
                if OO0000000O0O0O000 :O00OO00000OO0OOOO .update (OO0000000O0O0O000 )
            O00OO00000OO0OOOO =dict ((O0O0OO0000OOO0OOO ,O0O00000O0OO00O0O )for O0O0OO0000OOO0OOO ,O0O00000O0OO00O0O in control .iteritems (O00OO00000OO0OOOO )if O0O00000O0OO00O0O is not None and O0O00000O0OO00O0O !='')
            O0OO0O00OOO000OO0 .list [O00OO0OOO0O00OOO0 ].update (O00OO00000OO0OOOO )
            OO0O0O00O0OO00000 ={'imdb':O0OO00OOO000OOO00 ,'tmdb':O0O0O0OOO0O000OOO ,'tvdb':'','lang':O0OO0O00OOO000OO0 .lang ,'user':O0OO0O00OOO000OO0 .user ,'item':O00OO00000OO0OOOO }
            O0OO0O00OOO000OO0 .meta .append (OO0O0O00O0OO00000 )
        except :
            log_utils .error ()
    def movieDirectory (OO0O000OOOOO0OOO0 ,O00OO0OO0OO0OOOOO ,OO0O0OO00OOOO000O =False ,O000OOO00OOOO000O =True ):
        if not O00OO0OO0OO0OOOOO :
            control .hide ();control .notification (title =32001 ,message =33049 )
        from resources .lib .modules .player import Bookmarks 
        O000000OOO0O0OO0O ,O000000OO00O000OO =argv [0 ],int (argv [1 ])
        OOOO00O00O00OOOO0 =control .setting ('disable.player.art')=='true'
        OO000000OO0O0OOO0 =control .setting ('hosts.mode')
        O0OO0OOOOO0OO00OO ='plugin'not in control .infoLabel ('Container.PluginName')
        OOOO00000O00O00OO =control .setting ('fanart')=='true'
        O0O000000O0OOOOOO ,O00000OOOO0O0O000 ,OOO0O0OOOOO0OO00O =control .addonPoster (),control .addonFanart (),control .addonBanner ()
        OOOOO0OOOO0O0O0O0 =playcount .getMovieIndicators (refresh =True )
        OO0O0O0000OO00OOO ='false'
        if 'plugin'not in control .infoLabel ('Container.PluginName'):OO0O0O0000OO00OOO ='true'
        elif OO000000OO0O0OOO0 !='1':OO0O0O0000OO00OOO ='true'
        if OO000000OO0O0OOO0 =='2':O0O00OO0O00OO00O0 =control .lang (32063 )
        else :O0O00OO0O00OO00O0 =control .lang (32064 )
        if trakt .getTraktIndicatorsInfo ():
            O0O0O00000O0OO00O ,O000OO0OOO0OOOO0O =control .lang (32068 ),control .lang (32069 )
        else :
            O0O0O00000O0OO00O ,O000OO0OOO0OOOO0O =control .lang (32066 ),control .lang (32067 )
        O0OOOOOOOO0O0OOOO ,OO0O0OO0O0O00OO00 =control .lang (35522 ),control .lang (32065 )
        OO0OOOOO0OO00O00O ,O000OOOOOOO0OO00O =control .lang (32070 ),control .lang (32551 )
        OO000OO00O0OOOO00 ,O0OOOOOOOOOOO0OO0 =control .lang (32053 ),control .lang (32611 )
        for OOOO0OO0O0OOO0OOO in O00OO0OO0OO0OOOOO :
            try :
                OO00OOOOO0OOO0O0O ,O00O0OO0O00000OO0 ,OOOO00000000O0000 ,O00OOO000OO00OOO0 =OOOO0OO0O0OOO0OOO .get ('imdb',''),OOOO0OO0O0OOO0OOO .get ('tmdb',''),OOOO0OO0O0OOO0OOO ['title'],OOOO0OO0O0OOO0OOO .get ('year','')
                OO00OO0OOOOOOOO00 ,OOO0OO0OO00O00000 =OOOO0OO0O0OOO0OOO .get ('trailer'),OOOO0OO0O0OOO0OOO .get ('duration')
                OO00OO000OO00OOO0 ='%s (%s)'%(OOOO00000000O0000 ,O00OOO000OO00OOO0 )
                try :OOOOOOOO000O00OO0 =OO00OO000OO00OOO0 +'[COLOR %s]  [%s][/COLOR]'%(OO0O000OOOOO0OOO0 .highlight_color ,str (round (float (OOOO0OO0O0OOO0OOO ['progress']*100 ),1 ))+'%')
                except :OOOOOOOO000O00OO0 =OO00OO000OO00OOO0 
                try :
                    if int (re .sub (r'[^0-9]','',str (OOOO0OO0O0OOO0OOO ['premiered'])))>int (re .sub (r'[^0-9]','',str (OO0O000OOOOO0OOO0 .today_date ))):
                        OOOOOOOO000O00OO0 ='[COLOR %s][I]%s[/I][/COLOR]'%(OO0O000OOOOO0OOO0 .unairedcolor ,OOOOOOOO000O00OO0 )
                except :pass 
                if OOOO0OO0O0OOO0OOO .get ('traktHistory')is True :
                    try :
                        OO00OO00O00OOO0O0 =tools .Time .convert (stringTime =OOOO0OO0O0OOO0OOO .get ('lastplayed',''),zoneFrom ='utc',zoneTo ='local',formatInput ='%Y-%m-%dT%H:%M:%S.000Z',formatOutput ='%b %d %Y %I:%M %p')
                        if OO00OO00O00OOO0O0 [12 ]=='0':OO00OO00O00OOO0O0 =OO00OO00O00OOO0O0 [:12 ]+''+OO00OO00O00OOO0O0 [13 :]
                        OOOOOOOO000O00OO0 =OOOOOOOO000O00OO0 +'[COLOR %s]  [%s][/COLOR]'%(OO0O000OOOOO0OOO0 .highlight_color ,OO00OO00O00OOO0O0 )
                    except :pass 
                OOO0O00OO00O0OO0O ,OO0OO0O000OOOO0O0 =quote_plus (OO00OO000OO00OOO0 ),quote_plus (OOOO00000000O0000 )
                O0OO0000OOO0OOO00 =dict ((OO0OO0OO0OO000OOO ,OOOO0O00O0OOOOO00 )for OO0OO0OO0OO000OOO ,OOOO0O00O0OOOOO00 in control .iteritems (OOOO0OO0O0OOO0OOO )if OOOO0O00O0OOOOO00 is not None and OOOO0O00O0OOOOO00 !='')
                O0OO0000OOO0OOO00 .update ({'code':OO00OOOOO0OOO0O0O ,'imdbnumber':OO00OOOOO0OOO0O0O ,'mediatype':'movie','tag':[OO00OOOOO0OOO0O0O ,O00O0OO0O00000OO0 ]})
                try :O0OO0000OOO0OOO00 .update ({'genre':cleangenre .lang (O0OO0000OOO0OOO00 ['genre'],OO0O000OOOOO0OOO0 .lang )})
                except :pass 
                OO0O000OOOOO00O0O =O0OO0000OOO0OOO00 .get ('poster3')or O0OO0000OOO0OOO00 .get ('poster2')or O0OO0000OOO0OOO00 .get ('poster')or O0O000000O0OOOOOO 
                OOOOO00OOOOOO00OO =''
                if OOOO00000O00O00OO :OOOOO00OOOOOO00OO =O0OO0000OOO0OOO00 .get ('fanart3')or O0OO0000OOO0OOO00 .get ('fanart2')or O0OO0000OOO0OOO00 .get ('fanart')or O00000OOOO0O0O000 
                OOOO00OO000OOO000 =O0OO0000OOO0OOO00 .get ('landscape')or OOOOO00OOOOOO00OO 
                O0000O0OOOO00O000 =O0OO0000OOO0OOO00 .get ('thumb')or OO0O000OOOOO00O0O or OOOO00OO000OOO000 
                O0O00O0O0OOO00O0O =O0OO0000OOO0OOO00 .get ('icon')or OO0O000OOOOO00O0O 
                O00OOO0O00OO0OOO0 =O0OO0000OOO0OOO00 .get ('banner3')or O0OO0000OOO0OOO00 .get ('banner2')or O0OO0000OOO0OOO00 .get ('banner')or OOO0O0OOOOO0OO00O 
                O000000000O0O00OO ={}
                if OOOO00O00O00OOOO0 and OO000000OO0O0OOO0 =='2':
                    for OOO0O0O00O00O00OO in ('clearart','clearlogo','discart'):O0OO0000OOO0OOO00 .pop (OOO0O0O00O00O00OO ,None )
                O000000000O0O00OO .update ({'icon':O0O00O0O0OOO00O0O ,'thumb':O0000O0OOOO00O000 ,'banner':O00OOO0O00OO0OOO0 ,'poster':OO0O000OOOOO00O0O ,'fanart':OOOOO00OOOOOO00OO ,'landscape':OOOO00OO000OOO000 ,'clearlogo':O0OO0000OOO0OOO00 .get ('clearlogo',''),'clearart':O0OO0000OOO0OOO00 .get ('clearart',''),'discart':O0OO0000OOO0OOO00 .get ('discart',''),'keyart':O0OO0000OOO0OOO00 .get ('keyart','')})
                for OOO0O0O00O00O00OO in ('poster2','poster3','fanart2','fanart3','banner2','banner3','trailer'):O0OO0000OOO0OOO00 .pop (OOO0O0O00O00O00OO ,None )
                O0OO0000OOO0OOO00 .update ({'poster':OO0O000OOOOO00O0O ,'fanart':OOOOO00OOOOOO00OO ,'banner':O00OOO0O00OO0OOO0 })
                O00OOO0OOOO0OO0O0 =[]
                if OO0O000OOOOO0OOO0 .traktCredentials :
                    O00OOO0OOOO0OO0O0 .append ((OO0OOOOO0OO00O00O ,'RunPlugin(%s?action=tools_traktManager&name=%s&imdb=%s)'%(O000000OOO0O0OO0O ,OOO0O00OO00O0OO0O ,OO00OOOOO0OOO0O0O )))
                try :
                    O0O0OO000OO0OO00O =int (playcount .getMovieOverlay (OOOOO0OOOO0O0O0O0 ,OO00OOOOO0OOO0O0O ))
                    OO00O00OOOO0OO000 =(O0O0OO000OO0OO00O ==5 )
                    if OO00O00OOOO0OO000 :
                        O00OOO0OOOO0OO0O0 .append ((O000OO0OOO0OOOO0O ,'RunPlugin(%s?action=playcount_Movie&name=%s&imdb=%s&query=4)'%(O000000OOO0O0OO0O ,OOO0O00OO00O0OO0O ,OO00OOOOO0OOO0O0O )))
                        O0OO0000OOO0OOO00 .update ({'playcount':1 ,'overlay':5 })
                    else :
                        O00OOO0OOOO0OO0O0 .append ((O0O0O00000O0OO00O ,'RunPlugin(%s?action=playcount_Movie&name=%s&imdb=%s&query=5)'%(O000000OOO0O0OO0O ,OOO0O00OO00O0OO0O ,OO00OOOOO0OOO0O0O )))
                        O0OO0000OOO0OOO00 .update ({'playcount':0 ,'overlay':4 })
                except :pass 
                O0OOO00000OOOOO00 ,O00O0OO0O00OOO00O =quote_plus (jsdumps (O0OO0000OOO0OOO00 )),quote_plus (jsdumps (O000000000O0O00OO ))
                OO0O0OOOOOOOOO000 ='%s?action=play&title=%s&year=%s&imdb=%s&tmdb=%s&meta=%s'%(O000000OOO0O0OO0O ,OO0OO0O000OOOO0O0 ,O00OOO000OO00OOO0 ,OO00OOOOO0OOO0O0O ,O00O0OO0O00000OO0 ,O0OOO00000OOOOO00 )
                O00O000OOO0O0O00O =quote_plus (OO0O0OOOOOOOOO000 )
                O00OOO0OOOO0OO0O0 .append ((O0OOOOOOOO0O0OOOO ,'RunPlugin(%s?action=playlist_Manager&name=%s&url=%s&meta=%s&art=%s)'%(O000000OOO0O0OO0O ,OOO0O00OO00O0OO0O ,O00O000OOO0O0O00O ,O0OOO00000OOOOO00 ,O00O0OO0O00OOO00O )))
                O00OOO0OOOO0OO0O0 .append ((OO0O0OO0O0O00OO00 ,'RunPlugin(%s?action=playlist_QueueItem&name=%s)'%(O000000OOO0O0OO0O ,OOO0O00OO00O0OO0O )))
                O00OOO0OOOO0OO0O0 .append ((O0O00OO0O00OO00O0 ,'RunPlugin(%s?action=alterSources&url=%s&meta=%s)'%(O000000OOO0O0OO0O ,O00O000OOO0O0O00O ,O0OOO00000OOOOO00 )))
                O00OOO0OOOO0OO0O0 .append (('Rescrape Item','PlayMedia(%s?action=play&title=%s&year=%s&imdb=%s&tmdb=%s&meta=%s&rescrape=true)'%(O000000OOO0O0OO0O ,OO0OO0O000OOOO0O0 ,O00OOO000OO00OOO0 ,OO00OOOOO0OOO0O0O ,O00O0OO0O00000OO0 ,O0OOO00000OOOOO00 )))
                O00OOO0OOOO0OO0O0 .append ((O000OOOOOOO0OO00O ,'RunPlugin(%s?action=library_movieToLibrary&name=%s&title=%s&year=%s&imdb=%s&tmdb=%s)'%(O000000OOO0O0OO0O ,OOO0O00OO00O0OO0O ,OO0OO0O000OOOO0O0 ,O00OOO000OO00OOO0 ,OO00OOOOO0OOO0O0O ,O00O0OO0O00000OO0 )))
                O00OOO0OOOO0OO0O0 .append (('Find similar','ActivateWindow(10025,%s?action=movies&url=https://api.trakt.tv/movies/%s/related,return)'%(O000000OOO0O0OO0O ,OO00OOOOO0OOO0O0O )))
                O00OOO0OOOO0OO0O0 .append ((O0OOOOOOOOOOO0OO0 ,'RunPlugin(%s?action=cache_clearSources)'%O000000OOO0O0OO0O ))
                O00OOO0OOOO0OO0O0 .append (('[COLOR deepskyblue]LE Settings[/COLOR]','RunPlugin(%s?action=tools_openSettings)'%O000000OOO0O0OO0O ))
                if OO00OO0OOOOOOOO00 :O0OO0000OOO0OOO00 .update ({'trailer':OO00OO0OOOOOOOO00 })
                else :O0OO0000OOO0OOO00 .update ({'trailer':'%s?action=trailer&type=%s&name=%s&year=%s&imdb=%s'%(O000000OOO0O0OO0O ,'movie',OOO0O00OO00O0OO0O ,O00OOO000OO00OOO0 ,OO00OOOOO0OOO0O0O )})
                OO0OO0000O00O0000 =control .item (label =OOOOOOOO000O00OO0 ,offscreen =True )
                if 'castandart'in OOOO0OO0O0OOO0OOO :OO0OO0000O00O0000 .setCast (OOOO0OO0O0OOO0OOO ['castandart'])
                OO0OO0000O00O0000 .setArt (O000000000O0O00OO )
                OO0OO0000O00O0000 .setUniqueIDs ({'imdb':OO00OOOOO0OOO0O0O ,'tmdb':O00O0OO0O00000OO0 })
                OO0OO0000O00O0000 .setProperty ('IsPlayable',OO0O0O0000OO00OOO )
                if O0OO0OOOOO0OO00OO :OO0OO0000O00O0000 .setProperty ('isLE_widget','true')
                O00O00OO0OOOO0000 =Bookmarks ().get (name =OO00OO000OO00OOO0 ,imdb =OO00OOOOO0OOO0O0O ,tmdb =O00O0OO0O00000OO0 ,year =str (O00OOO000OO00OOO0 ),runtime =OOO0OO0OO00O00000 ,ck =True )
                OO0OO0000O00O0000 .setProperty ('ResumeTime',str (O00O00OO0OOOO0000 ))
                try :
                    O0O00OOO00OOO0O0O =round (float (O00O00OO0OOOO0000 )/float (OOO0OO0OO00O00000 )*100 ,1 )
                    OO0OO0000O00O0000 .setProperty ('PercentPlayed',str (O0O00OOO00OOO0O0O ))
                except :pass 
                OO0OO0000O00O0000 .setInfo (type ='video',infoLabels =control .metadataClean (O0OO0000OOO0OOO00 ))
                OO0OO0000O00O0000 .addContextMenuItems (O00OOO0OOOO0OO0O0 )
                control .addItem (handle =O000000OO00O000OO ,url =OO0O0OOOOOOOOO000 ,listitem =OO0OO0000O00O0000 ,isFolder =False )
            except :
                log_utils .error ()
        if O000OOO00OOOO000O :
            try :
                if not O00OO0OO0OO0OOOOO :raise Exception ()
                OO0O0OOOOOOOOO000 =O00OO0OO0OO0OOOOO [0 ]['next']
                if not OO0O0OOOOOOOOO000 :raise Exception ()
                O0O00O0000O000O00 =dict (parse_qsl (urlsplit (OO0O0OOOOOOOOO000 ).query ))
                if 'imdb.com'in OO0O0OOOOOOOOO000 and 'start'in O0O00O0000O000O00 :
                    OO00O0OO00OO000O0 ='  [I](%s)[/I]'%str (int (((int (O0O00O0000O000O00 .get ('start'))-1 )/int (OO0O000OOOOO0OOO0 .count ))+1 ))
                else :
                    OO00O0OO00OO000O0 ='  [I](%s)[/I]'%O0O00O0000O000O00 .get ('page')
                OO000OO00O0OOOO00 ='[COLOR skyblue]'+OO000OO00O0OOOO00 +OO00O0OO00OO000O0 +'[/COLOR]'
                OO00000OOO00OOOOO =urlparse (OO0O0OOOOOOOOO000 ).netloc .lower ()
                if OO00000OOO00OOOOO not in OO0O000OOOOO0OOO0 .tmdb_link :
                    OO0O0OOOOOOOOO000 ='%s?action=moviePage&url=%s'%(O000000OOO0O0OO0O ,quote_plus (OO0O0OOOOOOOOO000 ))
                elif OO00000OOO00OOOOO in OO0O000OOOOO0OOO0 .tmdb_link :
                    OO0O0OOOOOOOOO000 ='%s?action=tmdbmoviePage&url=%s'%(O000000OOO0O0OO0O ,quote_plus (OO0O0OOOOOOOOO000 ))
                OO0OO0000O00O0000 =control .item (label =OO000OO00O0OOOO00 ,offscreen =True )
                O0O00O0O0OOO00O0O =control .addonNext ()
                OO0OO0000O00O0000 .setProperty ('IsPlayable','false')
                OO0OO0000O00O0000 .setArt ({'icon':O0O00O0O0OOO00O0O ,'thumb':O0O00O0O0OOO00O0O ,'poster':O0O00O0O0OOO00O0O ,'banner':O0O00O0O0OOO00O0O })
                OO0OO0000O00O0000 .setProperty ('SpecialSort','bottom')
                control .addItem (handle =O000000OO00O000OO ,url =OO0O0OOOOOOOOO000 ,listitem =OO0OO0000O00O0000 ,isFolder =True )
            except :
                log_utils .error ()
        control .content (O000000OO00O000OO ,'movies')
        control .directory (O000000OO00O000OO ,cacheToDisc =True )
        control .sleep (500 )
        views .setView ('movies',{'skin.estuary':55 ,'skin.confluence':500 })
    def addDirectory (OOOO0O0O00OOOO00O ,OO0OO00000OO00OO0 ,OO00000O00O0O00O0 =False ):
        if not OO0OO00000OO00OO0 :
            control .hide ();control .notification (title =32001 ,message =33049 )
        OOO0O00O0O0OOO0O0 ,OO00OOO0O00O0O0O0 =argv [0 ],int (argv [1 ])
        O0OOO00000O0OO000 =control .addonThumb ()
        O0OOO0000O0O00O00 =control .artPath ()
        OOOO0OOO00OOOO0O0 ,O0000OOOO000000OO ,O0OO0O0000OO0OO0O =control .lang (32065 ),control .lang (32535 ),control .lang (32551 )
        for O0OOO0OOO0O0O00O0 in OO0OO00000OO00OO0 :
            try :
                O0OO0OOOOOO00O00O =O0OOO0OOO0O0O00O0 ['name']
                if O0OOO0OOO0O0O00O0 ['image'].startswith ('http'):OOO0O0O000OOO000O =O0OOO0OOO0O0O00O0 ['image']
                elif O0OOO0000O0O00O00 :OOO0O0O000OOO000O =control .joinPath (O0OOO0000O0O00O00 ,O0OOO0OOO0O0O00O0 ['image'])
                else :OOO0O0O000OOO000O =O0OOO00000O0OO000 
                OOOOO0O0000O0OO00 =O0OOO0OOO0O0O00O0 .get ('icon',0 )
                if not OOOOO0O0000O0OO00 :OOOOO0O0000O0OO00 ='DefaultFolder.png'
                O0000O0OOO00O000O ='%s?action=%s'%(OOO0O00O0O0OOO0O0 ,O0OOO0OOO0O0O00O0 ['action'])
                try :O0000O0OOO00O000O +='&url=%s'%quote_plus (O0OOO0OOO0O0O00O0 ['url'])
                except :pass 
                OO0OO00000O0O0OO0 =[]
                OO0OO00000O0O0OO0 .append ((O0000OOOO000000OO ,'RunPlugin(%s?action=random&rtype=movie&url=%s)'%(OOO0O00O0O0OOO0O0 ,quote_plus (O0OOO0OOO0O0O00O0 ['url']))))
                if OO00000O00O0O00O0 :OO0OO00000O0O0OO0 .append ((OOOO0OOO00OOOO0O0 ,'RunPlugin(%s?action=playlist_QueueItem)'%OOO0O00O0O0OOO0O0 ))
                try :
                    if control .setting ('library.service.update')=='true':
                        OO0OO00000O0O0OO0 .append ((O0OO0O0000OO0OO0O ,'RunPlugin(%s?action=library_moviesToLibrary&url=%s&name=%s)'%(OOO0O00O0O0OOO0O0 ,quote_plus (O0OOO0OOO0O0O00O0 ['context']),O0OO0OOOOOO00O00O )))
                except :pass 
                OO0OO00000O0O0OO0 .append (('[COLOR deepskyblue]LE Settings[/COLOR]','RunPlugin(%s?action=tools_openSettings)'%OOO0O00O0O0OOO0O0 ))
                O0OOOO0OO0000OO0O =control .item (label =O0OO0OOOOOO00O00O ,offscreen =True )
                O0OOOO0OO0000OO0O .setProperty ('IsPlayable','false')
                O0OOOO0OO0000OO0O .setArt ({'icon':OOOOO0O0000O0OO00 ,'poster':OOO0O0O000OOO000O ,'thumb':OOO0O0O000OOO000O ,'fanart':control .addonFanart (),'banner':OOO0O0O000OOO000O })
                O0OOOO0OO0000OO0O .addContextMenuItems (OO0OO00000O0O0OO0 )
                control .addItem (handle =OO00OOO0O00O0O0O0 ,url =O0000O0OOO00O000O ,listitem =O0OOOO0OO0000OO0O ,isFolder =True )
            except :
                log_utils .error ()
        control .content (OO00OOO0O00O0O0O0 ,'addons')
        control .directory (OO00OOO0O00O0O0O0 ,cacheToDisc =True )