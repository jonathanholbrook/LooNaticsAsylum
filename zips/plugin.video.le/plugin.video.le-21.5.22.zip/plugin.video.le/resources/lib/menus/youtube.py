from sys import argv 
from resources .lib .modules import control 
from resources .lib .modules import log_utils 
from resources .lib .modules import youtube_menu 
class yt_index :
    def __init__ (OOO00OOO0O0OOOOO0 ):
        OOO00OOO0O0OOOOO0 .action ='musicvids'
        OOO00OOO0O0OOOOO0 .base_url ='https://raw.githubusercontent.com/techecoyote/LooNaticsAsylum/master/text/extra/'
        OOO00OOO0O0OOOOO0 .mainmenu =OOO00OOO0O0OOOOO0 .base_url +'musicvids.txt'
        OOO00OOO0O0OOOOO0 .submenu ='%s/%s.txt'
        OOO00OOO0O0OOOOO0 .default_icon ='%s/icons/music_video_folder_icon.png'
        OOO00OOO0O0OOOOO0 .default_fanart ='%s/icons/music_video_folder_fanart.jpg'
    def init_vars (OOOO00O0OOO00OOO0 ,O00O00OOO00OO000O ):
        try :
            if O00O00OOO00OO000O =='youtube':
                OOOO00O0OOO00OOO0 .action ='youtube'
                OOOO00O0OOO00OOO0 .base_url ='https://raw.githubusercontent.com/techecoyote/LooNaticsAsylum/master/text/extra/'
                OOOO00O0OOO00OOO0 .mainmenu ='%sytmain.txt'%(OOOO00O0OOO00OOO0 .base_url )
            elif O00O00OOO00OO000O =='tvReviews':
                OOOO00O0OOO00OOO0 .action ='tvReviews'
                OOOO00O0OOO00OOO0 .base_url ='https://raw.githubusercontent.com/techecoyote/LooNaticsAsylum/master/text/extra/'
                OOOO00O0OOO00OOO0 .mainmenu ='%stvtrailer.txt'%(OOOO00O0OOO00OOO0 .base_url )
            elif O00O00OOO00OO000O =='movieReviews':
                OOOO00O0OOO00OOO0 .action ='movieReviews'
                OOOO00O0OOO00OOO0 .base_url ='https://raw.githubusercontent.com/techecoyote/LooNaticsAsylum/master/text/extra/'
                OOOO00O0OOO00OOO0 .mainmenu ='%smovietrailer.txt'%(OOOO00O0OOO00OOO0 .base_url )
            OOOO00O0OOO00OOO0 .submenu =OOOO00O0OOO00OOO0 .submenu %(OOOO00O0OOO00OOO0 .base_url ,'%s')
            OOOO00O0OOO00OOO0 .default_icon =OOOO00O0OOO00OOO0 .default_icon %(OOOO00O0OOO00OOO0 .base_url )
            OOOO00O0OOO00OOO0 .default_fanart =OOOO00O0OOO00OOO0 .default_fanart %(OOOO00O0OOO00OOO0 .base_url )
        except :
            log_utils .error ()
    def root (O0O0O000OO0000O00 ,OO0OOOO0O00O0O0O0 ):
        try :
            O0O0O000OO0000O00 .init_vars (OO0OOOO0O00O0O0O0 )
            O0OOOOO00OOO0O0OO =youtube_menu .youtube_menu ().processMenuFile (O0O0O000OO0000O00 .mainmenu )
            for O00OOOO0OO000O0OO ,O0OO000OO0O0OO0OO ,O0OO000O0OOOO0000 ,OO000OOOO00OOO00O ,OO00O00O00O0O00O0 ,OOOOO00O0000OO0O0 ,OO00OO000OO00OO0O ,O0O0000OO0OOOOOO0 ,O0000O00000000OO0 ,O000O0OOO00O0000O in O0OOOOO00OOO0O0OO :
                if OO000OOOO00OOO00O !='false':
                    youtube_menu .youtube_menu ().addMenuItem (O00OOOO0OO000O0OO ,O0O0O000OO0000O00 .action ,OO000OOOO00OOO00O ,O0O0000OO0OOOOOO0 ,O0000O00000000OO0 ,O000O0OOO00O0000O ,True )
                elif O0OO000O0OOOO0000 !='false':
                    youtube_menu .youtube_menu ().addSearchItem (O00OOOO0OO000O0OO ,O0OO000O0OOOO0000 ,O0O0000OO0OOOOOO0 ,O0000O00000000OO0 )
                elif OO00OO000OO00OO0O !='false':
                    youtube_menu .youtube_menu ().addVideoItem (O00OOOO0OO000O0OO ,OO00OO000OO00OO0O ,O0O0000OO0OOOOOO0 ,O0000O00000000OO0 )
                elif OOOOO00O0000OO0O0 !='false':
                    if OOOOO00O0000OO0O0 .startswith ('UC'):
                        youtube_menu .youtube_menu ().addChannelItem (O00OOOO0OO000O0OO ,OOOOO00O0000OO0O0 ,O0O0000OO0OOOOOO0 ,O0000O00000000OO0 )
                    else :
                        youtube_menu .youtube_menu ().addUserItem (O00OOOO0OO000O0OO ,OOOOO00O0000OO0O0 ,O0O0000OO0OOOOOO0 ,O0000O00000000OO0 )
                elif OO00O00O00O0O00O0 !='false':
                    youtube_menu .youtube_menu ().addPlaylistItem (O00OOOO0OO000O0OO ,OO00O00O00O0O00O0 ,O0O0000OO0OOOOOO0 ,O0000O00000000OO0 )
                elif O0OO000OO0O0OO0OO !='false':
                    youtube_menu .youtube_menu ().addSectionItem (O00OOOO0OO000O0OO ,O0O0O000OO0000O00 .default_icon ,O0O0O000OO0000O00 .default_fanart )
            O0O0O000OO0000O00 .endDirectory ()
        except :
            log_utils .error ()
    def get (O0OOO0O00OOOO000O ,O0OOO0O00O00OO0O0 ,O00000OO0OOOOO0OO ):
        try :
            O0OOO0O00OOOO000O .init_vars (O0OOO0O00O00OO0O0 )
            O0O00O0OOOO000O0O =O0OOO0O00OOOO000O .submenu %(O00000OO0OOOOO0OO )
            O00OO00O0OOOO0000 =youtube_menu .youtube_menu ().processMenuFile (O0O00O0OOOO000O0O )
            for O0O0OOOO0OOO000OO ,OO0O0O00OOO0000OO ,O0O000OO0O0OOOO0O ,O00000OO0OOOOO0OO ,OOOOO000O0O0OOO0O ,O00O00OOOOO0OO0O0 ,O0000OO00O0O0O0OO ,OO00O0O00OOO00O00 ,O0O0O0OO00O00000O ,O000O00O0O00O0OO0 in O00OO00O0OOOO0000 :
                if O00000OO0OOOOO0OO !='false':
                    youtube_menu .youtube_menu ().addMenuItem (O0O0OOOO0OOO000OO ,O0OOO0O00OOOO000O .action ,O00000OO0OOOOO0OO ,OO00O0O00OOO00O00 ,O0O0O0OO00O00000O ,O000O00O0O00O0OO0 ,True )
                elif O0O000OO0O0OOOO0O !='false':
                    youtube_menu .youtube_menu ().addSearchItem (O0O0OOOO0OOO000OO ,O0O000OO0O0OOOO0O ,OO00O0O00OOO00O00 ,O0O0O0OO00O00000O )
                elif O0000OO00O0O0O0OO !='false':
                    youtube_menu .youtube_menu ().addVideoItem (O0O0OOOO0OOO000OO ,O0000OO00O0O0O0OO ,OO00O0O00OOO00O00 ,O0O0O0OO00O00000O )
                elif O00O00OOOOO0OO0O0 !='false':
                    if O00O00OOOOO0OO0O0 .startswith ('UC'):
                        youtube_menu .youtube_menu ().addChannelItem (O0O0OOOO0OOO000OO ,O00O00OOOOO0OO0O0 ,OO00O0O00OOO00O00 ,O0O0O0OO00O00000O )
                    else :
                        youtube_menu .youtube_menu ().addUserItem (O0O0OOOO0OOO000OO ,O00O00OOOOO0OO0O0 ,OO00O0O00OOO00O00 ,O0O0O0OO00O00000O )
                elif OOOOO000O0O0OOO0O !='false':
                    youtube_menu .youtube_menu ().addPlaylistItem (O0O0OOOO0OOO000OO ,OOOOO000O0O0OOO0O ,OO00O0O00OOO00O00 ,O0O0O0OO00O00000O )
                elif OO0O0O00OOO0000OO !='false':
                    youtube_menu .youtube_menu ().addSectionItem (O0O0OOOO0OOO000OO ,O0OOO0O00OOOO000O .default_icon ,O0OOO0O00OOOO000O .default_fanart )
            O0OOO0O00OOOO000O .endDirectory ()
        except :
            log_utils .error ()
    def endDirectory (OO0OO0O0OOO0OOO00 ):
        control .directory (int (argv [1 ]),cacheToDisc =True )