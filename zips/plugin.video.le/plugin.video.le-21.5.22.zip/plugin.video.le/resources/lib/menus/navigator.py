from sys import argv ,exit as sysexit 
from resources .lib .modules import control 
from resources .lib .modules import log_utils 
try :
    from urllib import quote_plus 
except ImportError :
    from urllib .parse import quote_plus 
from resources .lib .modules .trakt import getTraktCredentialsInfo ,getTraktIndicatorsInfo 
artPath =control .artPath ()
traktCredentials =getTraktCredentialsInfo ()
traktIndicators =getTraktIndicatorsInfo ()
imdbCredentials =control .setting ('imdb.user')!=''
tmdbSessionID =control .setting ('tmdb.session_id')!=''
indexLabels =control .setting ('index.labels')=='true'
iconLogos =control .setting ('icon.logos')!='Traditional'
movielist1 =control .setting ('tmdb.movielist_name1')
movielist2 =control .setting ('tmdb.movielist_name2')
movielist3 =control .setting ('tmdb.movielist_name3')
movielist4 =control .setting ('tmdb.movielist_name4')
movielist5 =control .setting ('tmdb.movielist_name5')
movielist6 =control .setting ('tmdb.movielist_name6')
movielist7 =control .setting ('tmdb.movielist_name7')
movielist8 =control .setting ('tmdb.movielist_name8')
movielist9 =control .setting ('tmdb.movielist_name9')
movielist10 =control .setting ('tmdb.movielist_name10')
tvlist1 =control .setting ('tmdb.tvlist_name1')
tvlist2 =control .setting ('tmdb.tvlist_name2')
tvlist3 =control .setting ('tmdb.tvlist_name3')
tvlist4 =control .setting ('tmdb.tvlist_name4')
tvlist5 =control .setting ('tmdb.tvlist_name5')
tvlist6 =control .setting ('tmdb.tvlist_name6')
tvlist7 =control .setting ('tmdb.tvlist_name7')
tvlist8 =control .setting ('tmdb.tvlist_name8')
tvlist9 =control .setting ('tmdb.tvlist_name9')
tvlist10 =control .setting ('tmdb.tvlist_name10')
mymovlist1 =control .setting ('tmdb.mymovlist_name1')
mymovlist2 =control .setting ('tmdb.mymovlist_name2')
mymovlist3 =control .setting ('tmdb.mymovlist_name3')
mymovlist4 =control .setting ('tmdb.mymovlist_name4')
mymovlist5 =control .setting ('tmdb.mymovlist_name5')
mymovlist6 =control .setting ('tmdb.mymovlist_name6')
mymovlist7 =control .setting ('tmdb.mymovlist_name7')
mymovlist8 =control .setting ('tmdb.mymovlist_name8')
mymovlist9 =control .setting ('tmdb.mymovlist_name9')
mymovlist10 =control .setting ('tmdb.mymovlist_name10')
mytvlist1 =control .setting ('tmdb.mytvlist_name1')
mytvlist2 =control .setting ('tmdb.mytvlist_name2')
mytvlist3 =control .setting ('tmdb.mytvlist_name3')
mytvlist4 =control .setting ('tmdb.mytvlist_name4')
mytvlist5 =control .setting ('tmdb.mytvlist_name5')
mytvlist6 =control .setting ('tmdb.mytvlist_name6')
mytvlist7 =control .setting ('tmdb.mytvlist_name7')
mytvlist8 =control .setting ('tmdb.mytvlist_name8')
mytvlist9 =control .setting ('tmdb.mytvlist_name9')
mytvlist10 =control .setting ('tmdb.mytvlist_name10')
class Navigator :
    def root (O00OOO000O0O0000O ):
        O00OOO000O0O0000O .addDirectoryItem (33046 ,'movieNavigator','movies.png','DefaultMovies.png')
        O00OOO000O0O0000O .addDirectoryItem (33047 ,'tvNavigator','tvshows.png','DefaultTVShows.png')
        if control .getMenuEnabled ('mylists.widget'):
            O00OOO000O0O0000O .addDirectoryItem (32003 ,'mymovieNavigator','mymovies.png','DefaultVideoPlaylists.png')
            O00OOO000O0O0000O .addDirectoryItem (32004 ,'mytvNavigator','mytvshows.png','DefaultVideoPlaylists.png')
        if control .setting ('furk.api')!=''and control .getMenuEnabled ('navi.furk'):O00OOO000O0O0000O .addDirectoryItem ('Furk.net','furkNavigator','movies.png','DefaultMovies.png')
        if control .getMenuEnabled ('navi.main.lelists'):
            O00OOO000O0O0000O .addDirectoryItem ('Loonatics / Free / Family / DC / Marvel','listsListsNavigator','lists.png','DefaultMovies.png')
        if control .getMenuEnabled ('navi.main.iptv'):
            O00OOO000O0O0000O .addDirectoryItem ('IPTV & Sports','iptvListsNavigator','iptv.png','DefaultTVShows.png')
        if control .getMenuEnabled ('navi.main.originals'):
            O00OOO000O0O0000O .addDirectoryItem (40077 if indexLabels else 40070 ,'tvOriginals','tvmaze.png'if iconLogos else 'netamahu.png','DefaultNetwork.png')
        if control .getMenuEnabled ('navi.main.tmdb'):
            O00OOO000O0O0000O .addDirectoryItem ('TMDB Movie Arena','tmdbnavigator','tmdb.png','DefaultMovies.png')
        if control .getMenuEnabled ('navi.main.imdb'):
            O00OOO000O0O0000O .addDirectoryItem ('IMDB Movie Arena','imdbnavigator','imdb.png','DefaultMovies.png')
        if control .getMenuEnabled ('navi.main.docs'):
            O00OOO000O0O0000O .addDirectoryItem ('Documentaries','movies&url=docs','docs.png','DefaultMovies.png')
        if control .getMenuEnabled ('navi.main.anime'):
            O00OOO000O0O0000O .addDirectoryItem ('Anime','anime_Navigator','anime.png','DefaultFolder.png')
        if control .getMenuEnabled ('navi.main.cartoons'):
            O00OOO000O0O0000O .addDirectoryItem (30808 ,'tvshows&url=https://api.trakt.tv/users/sg0/lists/sg0-s-toontv/items','retrotoons.png','DefaultTVShows.png')
        if control .getMenuEnabled ('navi.main.standup'):
            O00OOO000O0O0000O .addDirectoryItem (30810 ,'movies&url=https://api.trakt.tv/users/giladg/lists/stand-up-comedy/items','standup.png','DefaultTVShows.png')
        if control .getMenuEnabled ('navi.youtube'):
            O00OOO000O0O0000O .addDirectoryItem ('You Tube Videos','youtube','youtube.png','youtube.png')
        O0O00O000OOOOO000 =True if control .setting ('adult_pw')=='yen00L'else False 
        if O0O00O000OOOOO000 ==True :
            O00OOO000O0O0000O .addDirectoryItem ('Adult Cartoons','tvshows&url=https://api.trakt.tv/users/sirmax/lists/bad-toontv/items','adults.png','DefaultTVShows.png')
        O00OOO000O0O0000O .addDirectoryItem (32010 ,'tools_searchNavigator','search.png','DefaultAddonsSearch.png')
        O00OOO000O0O0000O .addDirectoryItem (32008 ,'tools_toolNavigator','tools.png','DefaultAddonService.png')
        OOO0O0OOOOO0O0OOO =True if control .setting ('downloads')=='true'and (len (control .listDir (control .setting ('movie.download.path'))[0 ])>0 or len (control .listDir (control .setting ('tv.download.path'))[0 ])>0 )else False 
        if OOO0O0OOOOO0O0OOO :
            O00OOO000O0O0000O .addDirectoryItem (32009 ,'downloadNavigator','downloads.png','DefaultFolder.png')
        if control .getMenuEnabled ('navi.prem.services'):
            O00OOO000O0O0000O .addDirectoryItem ('Debrid Services','premiumNavigator','premium.png','DefaultFolder.png')
        if control .getMenuEnabled ('navi.news'):
            O00OOO000O0O0000O .addDirectoryItem (32013 ,'tools_ShowNews','icon.png','DefaultAddonHelper.png',isFolder =False )
        if control .getMenuEnabled ('navi.changelog'):
            O00OOO000O0O0000O .addDirectoryItem (32014 ,'tools_ShowChangelog','icon.png','DefaultAddonsUpdates.png',isFolder =False )
        O00OOO000O0O0000O .endDirectory ()
    def furk (OOOOOOOOOOO00OO00 ):
        OOOOOOOOOOO00OO00 .addDirectoryItem ('User Files','furkUserFiles','userlists.png','DefaultVideoPlaylists.png')
        OOOOOOOOOOO00OO00 .addDirectoryItem ('Search','furkSearch','search.png','search.png')
        OOOOOOOOOOO00OO00 .endDirectory ()
    def movies (OO0O0OOO00O0OOO0O ,OOOOOOOO0OO0OOO0O =False ):
        if control .getMenuEnabled ('navi.movie.trakt.anticipated'):
            OO0O0OOO00O0OOO0O .addDirectoryItem (32425 if indexLabels else 32424 ,'movies&url=traktanticipated','trakt.png'if iconLogos else 'in-theaters.png','DefaultMovies.png')
        if control .getMenuEnabled ('navi.movie.imdb.boxoffice'):
            OO0O0OOO00O0OOO0O .addDirectoryItem (32435 if indexLabels else 32434 ,'movies&url=imdbboxoffice','imdb.png'if iconLogos else 'box-office.png','DefaultMovies.png')
        if control .getMenuEnabled ('navi.movie.tmdb.boxoffice'):
            OO0O0OOO00O0OOO0O .addDirectoryItem (32436 if indexLabels else 32434 ,'tmdbmovies&url=tmdb_boxoffice','tmdb.png'if iconLogos else 'box-office.png','DefaultMovies.png')
        if control .getMenuEnabled ('navi.movie.trakt.boxoffice'):
            OO0O0OOO00O0OOO0O .addDirectoryItem (32437 if indexLabels else 32434 ,'movies&url=traktboxoffice','trakt.png'if iconLogos else 'box-office.png','DefaultMovies.png')
        if control .getMenuEnabled ('navi.movie.imdb.certificates'):
            OO0O0OOO00O0OOO0O .addDirectoryItem (32464 if indexLabels else 32463 ,'movieCertificates','imdb.png'if iconLogos else 'certificates.png','DefaultMovies.png')
        if control .getMenuEnabled ('navi.movie.collections'):
            OO0O0OOO00O0OOO0O .addDirectoryItem (32000 ,'collections_Navigator','boxsets.png','DefaultSets.png')
        if control .getMenuEnabled ('navi.movie.imdb.featured'):
            OO0O0OOO00O0OOO0O .addDirectoryItem (32447 if indexLabels else 32446 ,'movies&url=featured','imdb.png'if iconLogos else 'movies.png','DefaultMovies.png')
        if control .getMenuEnabled ('navi.movie.imdb.genres'):
            OO0O0OOO00O0OOO0O .addDirectoryItem (32456 if indexLabels else 32455 ,'movieGenres','imdb.png'if iconLogos else 'genres.png','DefaultGenre.png')
        if control .getMenuEnabled ('navi.movie.imdb.intheater'):
            OO0O0OOO00O0OOO0O .addDirectoryItem (32421 if indexLabels else 32420 ,'movies&url=theaters','imdb.png'if iconLogos else 'in-theaters.png','DefaultMovies.png')
        if control .getMenuEnabled ('navi.movie.imdb.languages'):
            OO0O0OOO00O0OOO0O .addDirectoryItem (32462 if indexLabels else 32461 ,'movieLanguages','imdb.png'if iconLogos else 'languages.png','DefaultAddonLanguage.png')
        if control .getMenuEnabled ('navi.movie.most'):
            OO0O0OOO00O0OOO0O .addDirectoryItem ('Most Played / Collected / Watched','movieMosts','people-watching.png','DefaultMovies.png')
        if control .getMenuEnabled ('navi.movie.imdb.popular'):
            OO0O0OOO00O0OOO0O .addDirectoryItem (32429 if indexLabels else 32428 ,'movies&url=mostpopular','imdb.png'if iconLogos else 'most-popular.png','DefaultMovies.png')
        if control .getMenuEnabled ('navi.movie.imdb.mostvoted'):
            OO0O0OOO00O0OOO0O .addDirectoryItem (32439 if indexLabels else 32438 ,'movies&url=mostvoted','imdb.png'if iconLogos else 'most-voted.png','DefaultMovies.png')
        if control .getMenuEnabled ('navi.movie.tmdb.nowplaying'):
            OO0O0OOO00O0OOO0O .addDirectoryItem (32423 if indexLabels else 32422 ,'tmdbmovies&url=tmdb_nowplaying','tmdb.png'if iconLogos else 'in-theaters.png','DefaultMovies.png')
        if control .getMenuEnabled ('navi.movie.imdb.oscarwinners'):
            OO0O0OOO00O0OOO0O .addDirectoryItem (32452 if indexLabels else 32451 ,'movies&url=oscars','imdb.png'if iconLogos else 'oscar-winners.png','DefaultMovies.png')
        if control .getMenuEnabled ('navi.movie.imdb.oscarnominees'):
            OO0O0OOO00O0OOO0O .addDirectoryItem (32454 if indexLabels else 32453 ,'movies&url=oscarsnominees','imdb.png'if iconLogos else 'oscar-winners.png','DefaultMovies.png')
        if control .getMenuEnabled ('navi.movie.imdb.people'):
            OO0O0OOO00O0OOO0O .addDirectoryItem (32460 if indexLabels else 32459 ,'moviePersons','imdb.png'if iconLogos else 'people.png','DefaultActor.png')
        if control .getMenuEnabled ('navi.movie.tmdb.popular'):
            OO0O0OOO00O0OOO0O .addDirectoryItem (32431 if indexLabels else 32430 ,'tmdbmovies&url=tmdb_popular','tmdb.png'if iconLogos else 'most-popular.png','DefaultMovies.png')
        if control .getMenuEnabled ('navi.movie.trakt.popular'):
            OO0O0OOO00O0OOO0O .addDirectoryItem (32433 if indexLabels else 32432 ,'movies&url=traktpopular','trakt.png'if iconLogos else 'most-popular.png','DefaultMovies.png')
        if control .getMenuEnabled ('navi.movie.trakt.recommended'):
            OO0O0OOO00O0OOO0O .addDirectoryItem (32445 if indexLabels else 32444 ,'movies&url=traktrecommendations','trakt.png'if iconLogos else 'highly-rated.png','DefaultMovies.png')
        if control .getMenuEnabled ('navi.movie.tmdb.toprated'):
            OO0O0OOO00O0OOO0O .addDirectoryItem (32441 if indexLabels else 32440 ,'tmdbmovies&url=tmdb_toprated','tmdb.png'if iconLogos else 'most-voted.png','DefaultMovies.png')
        if control .getMenuEnabled ('navi.movie.trakt.trending'):
            OO0O0OOO00O0OOO0O .addDirectoryItem (32443 if indexLabels else 32442 ,'movies&url=trakttrending','trakt.png'if iconLogos else 'trending.png','DefaultMovies.png')
        if control .getMenuEnabled ('navi.movie.tmdb.upcoming'):
            OO0O0OOO00O0OOO0O .addDirectoryItem (32427 if indexLabels else 32426 ,'tmdbmovies&url=tmdb_upcoming','tmdb.png'if iconLogos else 'in-theaters.png','DefaultMovies.png')
        if control .getMenuEnabled ('navi.movie.imdb.years'):
            OO0O0OOO00O0OOO0O .addDirectoryItem (32458 if indexLabels else 32457 ,'movieYears','imdb.png'if iconLogos else 'years.png','DefaultYear.png')
        if not OOOOOOOO0OO0OOO0O :
            if control .getMenuEnabled ('mylists.widget'):
                OO0O0OOO00O0OOO0O .addDirectoryItem (32003 ,'mymovieliteNavigator','mymovies.png','DefaultMovies.png')
            OO0O0OOO00O0OOO0O .addDirectoryItem (33044 ,'moviePerson','imdb.png'if iconLogos else 'people-search.png','DefaultAddonsSearch.png')
            OO0O0OOO00O0OOO0O .addDirectoryItem (33042 ,'movieSearch','trakt.png'if iconLogos else 'search.png','DefaultAddonsSearch.png')
            OO0O0OOO00O0OOO0O .addDirectoryItem (32008 ,'tools_toolNavigator','tools.png','DefaultAddonService.png')
        OO0O0OOO00O0OOO0O .endDirectory ()
    def movieMosts (O00OOOO0OOOOOOO00 ,O0OOO00000OO0OOOO =False ):
        O00OOOO0OOOOOOO00 .addDirectoryItem ('Most Played This Week','movies&url=played1','most-popular.png','DefaultMovies.png')
        O00OOOO0OOOOOOO00 .addDirectoryItem ('Most Played This Month','movies&url=played2','most-popular.png','DefaultMovies.png')
        O00OOOO0OOOOOOO00 .addDirectoryItem ('Most Played This Year','movies&url=played3','most-popular.png','DefaultMovies.png')
        O00OOOO0OOOOOOO00 .addDirectoryItem ('Most Played All Time','movies&url=played4','most-popular.png','DefaultMovies.png')
        O00OOOO0OOOOOOO00 .addDirectoryItem ('Most Collected This Week','movies&url=collected1','most-popular.png','DefaultMovies.png')
        O00OOOO0OOOOOOO00 .addDirectoryItem ('Most Collected This Month','movies&url=collected2','most-popular.png','DefaultMovies.png')
        O00OOOO0OOOOOOO00 .addDirectoryItem ('Most Collected This Year','movies&url=collected3','most-popular.png','DefaultMovies.png')
        O00OOOO0OOOOOOO00 .addDirectoryItem ('Most Collected All Time','movies&url=collected4','most-popular.png','DefaultMovies.png')
        O00OOOO0OOOOOOO00 .addDirectoryItem ('Most Watched This Week','movies&url=watched1','most-popular.png','DefaultMovies.png')
        O00OOOO0OOOOOOO00 .addDirectoryItem ('Most Watched This Month','movies&url=watched2','most-popular.png','DefaultMovies.png')
        O00OOOO0OOOOOOO00 .addDirectoryItem ('Most Watched This Year','movies&url=watched3','most-popular.png','DefaultMovies.png')
        O00OOOO0OOOOOOO00 .addDirectoryItem ('Most Watched All Time','movies&url=watched4','most-popular.png','DefaultMovies.png')
        O00OOOO0OOOOOOO00 .endDirectory ()
    def mymovies (O00OOO000O0OO0000 ,OOO0OOOOOOOO0O00O =False ):
        O00OOO000O0OO0000 .accountCheck ()
        O00OOO000O0OO0000 .addDirectoryItem (32039 ,'movieUserlists','userlists.png','DefaultVideoPlaylists.png')
        if traktCredentials :
            if traktIndicators :
                O00OOO000O0OO0000 .addDirectoryItem (35308 ,'moviesUnfinished&url=traktunfinished','trakt.png','DefaultVideoPlaylists.png',queue =True )
                O00OOO000O0OO0000 .addDirectoryItem (32036 ,'movies&url=trakthistory','trakt.png','DefaultVideoPlaylists.png',queue =True )
            O00OOO000O0OO0000 .addDirectoryItem (32683 ,'movies&url=traktwatchlist','trakt.png','DefaultVideoPlaylists.png',queue =True ,context =(32551 ,'library_moviesToLibrary&url=traktwatchlist&name=traktwatchlist'))
            O00OOO000O0OO0000 .addDirectoryItem (32032 ,'movies&url=traktcollection','trakt.png','DefaultVideoPlaylists.png',queue =True ,context =(32551 ,'library_moviesToLibrary&url=traktcollection&name=traktcollection'))
        if imdbCredentials :
            O00OOO000O0OO0000 .addDirectoryItem (32682 ,'movies&url=imdbwatchlist','imdb.png','DefaultVideoPlaylists.png',queue =True )
        if not OOO0OOOOOOOO0O00O :
            O00OOO000O0OO0000 .addDirectoryItem (32031 ,'movieliteNavigator','movies.png','DefaultMovies.png')
            O00OOO000O0OO0000 .addDirectoryItem (33044 ,'moviePerson','imdb.png'if iconLogos else 'people-search.png','DefaultAddonsSearch.png')
            O00OOO000O0OO0000 .addDirectoryItem (33042 ,'movieSearch','search.png'if iconLogos else 'search.png','DefaultAddonsSearch.png')
            O00OOO000O0OO0000 .addDirectoryItem (32008 ,'tools_toolNavigator','tools.png','DefaultAddonService.png')
        O00OOO000O0OO0000 .endDirectory ()
    def tvshows (OO00O00O00O00OOOO ,O0OO0O00O0OOO0OO0 =False ):
        if control .getMenuEnabled ('navi.tv.imdb.airingtoday'):
            OO00O00O00O00OOOO .addDirectoryItem (32466 if indexLabels else 32465 ,'tvshows&url=airing','imdb.png'if iconLogos else 'airing-today.png','DefaultRecentlyAddedEpisodes.png')
        if control .getMenuEnabled ('navi.tv.tmdb.airingtoday'):
            OO00O00O00O00OOOO .addDirectoryItem (32467 if indexLabels else 32465 ,'tmdbTvshows&url=tmdb_airingtoday','tmdb.png'if iconLogos else 'airing-today.png','DefaultRecentlyAddedEpisodes.png')
        if control .getMenuEnabled ('navi.tv.tvmaze.calendar'):
            OO00O00O00O00OOOO .addDirectoryItem (32450 if indexLabels else 32027 ,'calendars','tvmaze.png'if iconLogos else 'calendar.png','DefaultYear.png')
        if control .getMenuEnabled ('navi.tv.imdb.certificates'):
            OO00O00O00O00OOOO .addDirectoryItem (32464 if indexLabels else 32463 ,'tvCertificates','imdb.png'if iconLogos else 'certificates.png','DefaultTVShows.png')
        if control .getMenuEnabled ('navi.tv.imdb.genres'):
            OO00O00O00O00OOOO .addDirectoryItem (32456 if indexLabels else 32455 ,'tvGenres','imdb.png'if iconLogos else 'genres.png','DefaultGenre.png')
        if control .getMenuEnabled ('navi.tv.imdb.highlyrated'):
            OO00O00O00O00OOOO .addDirectoryItem (32449 if indexLabels else 32448 ,'tvshows&url=rating','imdb.png'if iconLogos else 'highly-rated.png','DefaultTVShows.png')
        if control .getMenuEnabled ('navi.tv.imdb.languages'):
            OO00O00O00O00OOOO .addDirectoryItem (32462 if indexLabels else 32461 ,'tvLanguages','imdb.png'if iconLogos else 'languages.png','DefaultAddonLanguage.png')
        if control .getMenuEnabled ('navi.tv.most'):
            OO00O00O00O00OOOO .addDirectoryItem ('Most Played / Collected / Watched','showMosts','people-watching.png','DefaultTVShows.png')
        if control .getMenuEnabled ('navi.tv.imdb.popular'):
            OO00O00O00O00OOOO .addDirectoryItem (32429 if indexLabels else 32428 ,'tvshows&url=popular','imdb.png'if iconLogos else 'most-popular.png','DefaultTVShows.png')
        if control .getMenuEnabled ('navi.tv.imdb.mostvoted'):
            OO00O00O00O00OOOO .addDirectoryItem (32439 if indexLabels else 32438 ,'tvshows&url=views','imdb.png'if iconLogos else 'most-voted.png','DefaultTVShows.png')
        if control .getMenuEnabled ('navi.tv.tvmaze.networks'):
            OO00O00O00O00OOOO .addDirectoryItem (32468 if indexLabels else 32469 ,'tvNetworks','tvmaze.png'if iconLogos else 'networks.png','DefaultNetwork.png')
        if control .getMenuEnabled ('navi.tv.imdb.newtvshows'):
            OO00O00O00O00OOOO .addDirectoryItem (32476 if indexLabels else 32475 ,'tvshows&url=premiere','imdb.png'if iconLogos else 'new-tvshows.png','DefaultRecentlyAddedEpisodes.png')
        if control .getMenuEnabled ('navi.tv.tmdb.ontv'):
            OO00O00O00O00OOOO .addDirectoryItem (32472 if indexLabels else 32471 ,'tmdbTvshows&url=tmdb_ontheair','tmdb.png'if iconLogos else 'new-tvshows.png','DefaultRecentlyAddedEpisodes.png')
        if control .getMenuEnabled ('navi.tv.tmdb.popular'):
            OO00O00O00O00OOOO .addDirectoryItem (32431 if indexLabels else 32430 ,'tmdbTvshows&url=tmdb_popular','tmdb.png'if iconLogos else 'most-popular.png','DefaultTVShows.png')
        if control .getMenuEnabled ('navi.tv.trakt.popular'):
            OO00O00O00O00OOOO .addDirectoryItem (32433 if indexLabels else 32432 ,'tvshows&url=traktpopular','trakt.png'if iconLogos else 'most-popular.png','DefaultTVShows.png',queue =True )
        if control .getMenuEnabled ('navi.tv.trakt.recommended'):
            OO00O00O00O00OOOO .addDirectoryItem (32445 if indexLabels else 32444 ,'tvshows&url=traktrecommendations','trakt.png'if iconLogos else 'highly-rated.png','DefaultTVShows.png',queue =True )
        if control .getMenuEnabled ('navi.tv.imdb.returningtvshows'):
            OO00O00O00O00OOOO .addDirectoryItem (32474 if indexLabels else 32473 ,'tvshows&url=active','imdb.png'if iconLogos else 'returning-tvshows.png','DefaultRecentlyAddedEpisodes.png')
        if control .getMenuEnabled ('navi.tv.tmdb.toprated'):
            OO00O00O00O00OOOO .addDirectoryItem (32441 if indexLabels else 32440 ,'tmdbTvshows&url=tmdb_toprated','tmdb.png'if iconLogos else 'most-voted.png','DefaultTVShows.png')
        if control .getMenuEnabled ('navi.tv.trakt.trending'):
            OO00O00O00O00OOOO .addDirectoryItem (32443 if indexLabels else 32442 ,'tvshows&url=trakttrending','trakt.png'if iconLogos else 'trending.png','DefaultTVShows.png')
        if not O0OO0O00O0OOO0OO0 :
            if control .getMenuEnabled ('mylists.widget'):
                OO00O00O00O00OOOO .addDirectoryItem (32004 ,'mytvliteNavigator','mytvshows.png','DefaultTVShows.png')
            OO00O00O00O00OOOO .addDirectoryItem (33045 ,'tvPerson','imdb.png'if iconLogos else 'people-search.png','DefaultAddonsSearch.png')
            OO00O00O00O00OOOO .addDirectoryItem (33043 ,'tvSearch','trakt.png'if iconLogos else 'search.png','DefaultAddonsSearch.png')
            OO00O00O00O00OOOO .addDirectoryItem (32008 ,'tools_toolNavigator','tools.png','DefaultAddonService.png')
        OO00O00O00O00OOOO .endDirectory ()
    def showMosts (OO00O00O0OO0OO0OO ,OO0000OO00O0OOOOO =False ):
        OO00O00O0OO0OO0OO .addDirectoryItem ('Most Played This Week','tvshows&url=played1','most-popular.png','DefaultTVShows.png')
        OO00O00O0OO0OO0OO .addDirectoryItem ('Most Played This Month','tvshows&url=played2','most-popular.png','DefaultTVShows.png')
        OO00O00O0OO0OO0OO .addDirectoryItem ('Most Played This Year','tvshows&url=played3','most-popular.png','DefaultTVShows.png')
        OO00O00O0OO0OO0OO .addDirectoryItem ('Most Played All Time','tvshows&url=played4','most-popular.png','DefaultTVShows.png')
        OO00O00O0OO0OO0OO .addDirectoryItem ('Most Collected This Week','tvshows&url=collected1','most-popular.png','DefaultTVShows.png')
        OO00O00O0OO0OO0OO .addDirectoryItem ('Most Collected This Month','tvshows&url=collected2','most-popular.png','DefaultTVShows.png')
        OO00O00O0OO0OO0OO .addDirectoryItem ('Most Collected This Year','tvshows&url=collected3','most-popular.png','DefaultTVShows.png')
        OO00O00O0OO0OO0OO .addDirectoryItem ('Most Collected All Time','tvshows&url=collected4','most-popular.png','DefaultTVShows.png')
        OO00O00O0OO0OO0OO .addDirectoryItem ('Most Watched This Week','tvshows&url=watched1','most-popular.png','DefaultTVShows.png')
        OO00O00O0OO0OO0OO .addDirectoryItem ('Most Watched This Month','tvshows&url=watched2','most-popular.png','DefaultTVShows.png')
        OO00O00O0OO0OO0OO .addDirectoryItem ('Most Watched This Year','tvshows&url=watched3','most-popular.png','DefaultTVShows.png')
        OO00O00O0OO0OO0OO .addDirectoryItem ('Most Watched All Time','tvshows&url=watched4','most-popular.png','DefaultTVShows.png')
        OO00O00O0OO0OO0OO .endDirectory ()
    def mytvshows (OOOO0O000OO000O00 ,OO00OOOOOO0O000OO =False ):
        OOOO0O000OO000O00 .accountCheck ()
        OOOO0O000OO000O00 .addDirectoryItem (32040 ,'tvUserlists','userlists.png','DefaultVideoPlaylists.png')
        if traktCredentials :
            if traktIndicators :
                OOOO0O000OO000O00 .addDirectoryItem (35308 ,'episodesUnfinished&url=traktunfinished','trakt.png','DefaultVideoPlaylists.png',queue =True )
                OOOO0O000OO000O00 .addDirectoryItem (32036 ,'calendar&url=trakthistory','trakt.png','DefaultVideoPlaylists.png',queue =True )
                OOOO0O000OO000O00 .addDirectoryItem (32037 ,'calendar&url=progress','trakt.png','DefaultVideoPlaylists.png',queue =True )
                OOOO0O000OO000O00 .addDirectoryItem (32019 ,'upcomingProgress&url=progress','trakt.png','DefaultVideoPlaylists.png',queue =True )
                OOOO0O000OO000O00 .addDirectoryItem (32027 ,'calendar&url=mycalendar','trakt.png','DefaultYear.png',queue =True )
            OOOO0O000OO000O00 .addDirectoryItem (32683 ,'tvshows&url=traktwatchlist','trakt.png','DefaultVideoPlaylists.png',context =(32551 ,'library_tvshowsToLibrary&url=traktwatchlist&name=traktwatchlist'))
            OOOO0O000OO000O00 .addDirectoryItem (32032 ,'tvshows&url=traktcollection','trakt.png','DefaultVideoPlaylists.png',context =(32551 ,'library_tvshowsToLibrary&url=traktcollection&name=traktcollection'))
            OOOO0O000OO000O00 .addDirectoryItem (32041 ,'episodesUserlists','userlists.png','DefaultVideoPlaylists.png')
        if imdbCredentials :
            OOOO0O000OO000O00 .addDirectoryItem (32682 ,'tvshows&url=imdbwatchlist','imdb.png','DefaultVideoPlaylists.png')
        if not OO00OOOOOO0O000OO :
            OOOO0O000OO000O00 .addDirectoryItem (32031 ,'tvliteNavigator','tvshows.png','DefaultTVShows.png')
            OOOO0O000OO000O00 .addDirectoryItem (33045 ,'tvPerson','imdb.png'if iconLogos else 'people-search.png','DefaultAddonsSearch.png')
            OOOO0O000OO000O00 .addDirectoryItem (33043 ,'tvSearch','trakt.png'if iconLogos else 'search.png','DefaultAddonsSearch.png')
            OOOO0O000OO000O00 .addDirectoryItem (32008 ,'tools_toolNavigator','tools.png','DefaultAddonService.png')
        OOOO0O000OO000O00 .endDirectory ()
    def anime (OO0O00O0OO0O000OO ,O0O00O00OO0000O00 =False ):
        OO0O00O0OO0O000OO .addDirectoryItem (32001 ,'anime_Movies&url=anime','animemovie.png','DefaultMovies.png')
        OO0O00O0OO0O000OO .addDirectoryItem (32002 ,'anime_TVshows&url=anime','animetv.png','DefaultTVShows.png')
        OO0O00O0OO0O000OO .endDirectory ()
    def iptv (O000O0000O00OO0OO ,O0OO0O000O0O00O00 =False ):
        O000O0000O00OO0OO .addDirectoryItem (30827 ,'tvnsports','tvnsports.png','DefaultTVShows.png')
        O000O0000O00OO0OO .addDirectoryItem (30802 ,'swift','swift.png','DefaultTVShows.png')
        O000O0000O00OO0OO .addDirectoryItem (30803 ,'tvtap','tvtap.png','DefaultTVShows.png')
        O000O0000O00OO0OO .addDirectoryItem (30806 ,'livenet','livenet.png','DefaultTVShows.png')
        O000O0000O00OO0OO .addDirectoryItem (30828 ,'livenetsports','livesports.png','DefaultTVShows.png')
        O000O0000O00OO0OO .endDirectory ()
    def lists (O0OO0O00O00O0O0OO ,O000OOO000000O000 =False ):
        O0OO0O00O00O0O0OO .addDirectoryItem ('Free 1 Click Movies','oneclick','movies.png','DefaultMovies.png')
        O0OO0O00O00O0O0OO .addDirectoryItem (30829 ,'userlists','userlist.png','lists.png')
        O0OO0O00O00O0O0OO .addDirectoryItem (30834 ,'madhouseListsNavigator','madicon.png','lists.png')
        O0OO0O00O00O0O0OO .addDirectoryItem (30835 ,'dcmarvelherosNavigator','dcmarvelheros.png','DefaultMovies.png')
        O0OO0O00O00O0O0OO .endDirectory ()
    def madhouse (O0000O0O00O0O00O0 ,O0OO000000O0OOOOO =False ):
        O0000O0O00O0O00O0 .addDirectoryItem ('WolfGirl','wolfgirl','wolfgirl.png','DefaultMovies.png')
        O0000O0O00O0O00O0 .addDirectoryItem ('Cable','cable','cable.png','DefaultMovies.png')
        O0000O0O00O0O00O0 .addDirectoryItem ('ShadowHawk','shadowhawk','shadowhawk.png','DefaultMovies.png')
        O0000O0O00O0O00O0 .addDirectoryItem ('DocOctyl','dococtyl','dococtyl.png','DefaultMovies.png')
        O0000O0O00O0O00O0 .addDirectoryItem ('DiamondBuild [COLORred](RD ONLY)[/COLOR]','diamondbuild','diamondbuild.png','DefaultMovies.png')
        O0000O0O00O0O00O0 .addDirectoryItem ('SubLime','sublime','sublime.png','DefaultMovies.png')
        O0000O0O00O0O00O0 .addDirectoryItem ('BurninU','burninu','burninu.png','DefaultMovies.png')
        O0000O0O00O0O00O0 .addDirectoryItem ('DcMarvelBuild Top 4K Movies','movies&url=dcmarvelbuild','dcmarvelbuild.png','DefaultMovies.png')
        O0000O0O00O0O00O0 .endDirectory ()
    def wolfgirl (O00OO0000OO0O00O0 ,OOO000000OO000000 =False ):
        O00OO0000OO0O00O0 .addDirectoryItem ('[COLORmediumpurple]Wolfs Picks[/COLOR] - [COLORmediumorchid]Updated Monthly[/COLOR]','movies&url=wgpicks','wolfgirl.png','DefaultMovies.png')
        O00OO0000OO0O00O0 .addDirectoryItem ('Action','movies&url=wgaction','wolfgirl.png','DefaultMovies.png')
        O00OO0000OO0O00O0 .addDirectoryItem ('Apocolypse','movies&url=wgapocolypse','wolfgirl.png','DefaultMovies.png')
        O00OO0000OO0O00O0 .addDirectoryItem ('Christmas','movies&url=wgxmas','wolfgirl.png','DefaultMovies.png')
        O00OO0000OO0O00O0 .addDirectoryItem ('Comedy','movies&url=wgcomedy','wolfgirl.png','DefaultMovies.png')
        O00OO0000OO0O00O0 .addDirectoryItem ('Documentaries','movies&url=wgdocs','wolfgirl.png','DefaultMovies.png')
        O00OO0000OO0O00O0 .addDirectoryItem ('Halloween','movies&url=wgsleepy','wolfgirl.png','DefaultMovies.png')
        O00OO0000OO0O00O0 .addDirectoryItem ('Monster','movies&url=wgmonster','wolfgirl.png','DefaultMovies.png')
        O00OO0000OO0O00O0 .addDirectoryItem ('Paranormal','movies&url=wgparanormal','wolfgirl.png','DefaultMovies.png')
        O00OO0000OO0O00O0 .addDirectoryItem ('Toons','movies&url=wgtoons','wolfgirl.png','DefaultMovies.png')
        O00OO0000OO0O00O0 .addDirectoryItem ('Vault','movies&url=wgvault','wolfgirl.png','DefaultMovies.png')
        O00OO0000OO0O00O0 .endDirectory ()
    def cable (O0OOOOOO0O00000O0 ):
        O0OOOOOO0O00000O0 .addDirectoryItem ('Hot & Spicy Movies','movies&url=cablemovie','cable.png','DefaultMovies.png')
        O0OOOOOO0O00000O0 .addDirectoryItem ('Hot & Spicy TvShows','tvshows&url=cabletv','cable.png','DefaultMovies.png')
        O0OOOOOO0O00000O0 .endDirectory ()
    def shadowhawk (O0OOOOO0OOOOO0O00 ,OOOO0000O0OO0000O =False ):
        O0OOOOO0OOOOO0O00 .addDirectoryItem ('Jay & Silent Bob','movies&url=shjaysilentbob','shadowhawk.png','DefaultMovies.png')
        O0OOOOO0OOOOO0O00 .addDirectoryItem ('Stoner Movies','movies&url=shstonermovies','shadowhawk.png','DefaultMovies.png')
        O0OOOOO0OOOOO0O00 .addDirectoryItem ('Monty Python','movies&url=shmontypython','shadowhawk.png','DefaultMovies.png')
        O0OOOOO0OOOOO0O00 .addDirectoryItem ('Chech & Chong','movies&url=shchechchong','shadowhawk.png','DefaultMovies.png')
        O0OOOOO0OOOOO0O00 .addDirectoryItem ('Stoner Tv Shows','tvshows&url=shstonertvshows','shadowhawk.png','DefaultTVShows.png')
        O0OOOOO0OOOOO0O00 .endDirectory ()
    def sublime (O00OO000000OO00OO ,O0O0O0O00O00OOO00 =False ):
        O00OO000000OO00OO .addDirectoryItem ('Breaking Law Tv Shows','tvshows&url=slbreak','sublime.png','DefaultTVShows.png')
        O00OO000000OO00OO .addDirectoryItem ('Creep Shows','movies&url=slcreep','slcreep.png','DefaultMovies.png')
        O00OO000000OO00OO .addDirectoryItem ('New Movie Picks','movies&url=slpicks','slpicks.png','DefaultMovies.png')
        O00OO000000OO00OO .addDirectoryItem ('Space Odyssey','movies&url=slspace','slpicks.png','DefaultMovies.png')
        O00OO000000OO00OO .endDirectory ()
    def dococtyl (O0000OO0O0O000O0O ,OOO0O0OO00000O0OO =False ):
        O0000OO0O0O000O0O .addDirectoryItem ('70s Sci-fi','movies&url=dosyfy','dococtyl.png','DefaultMovies.png')
        O0000OO0O0O000O0O .addDirectoryItem ('At the Drive-in','movies&url=dodrivein','dococtyl.png','DefaultMovies.png')
        O0000OO0O0O000O0O .addDirectoryItem ('Parallel Universe','movies&url=douniverse','dococtyl.png','DefaultMovies.png')
        O0000OO0O0O000O0O .addDirectoryItem ('Planet of the Apes','movies&url=dopota','dococtyl.png','DefaultMovies.png')
        O0000OO0O0O000O0O .addDirectoryItem ('Time Travel','movies&url=dotimetravel','dococtyl.png','DefaultMovies.png')
        O0000OO0O0O000O0O .endDirectory ()
    def burninu (O0O00O00O0O0OOOOO ,O00O0OO00OOOOOOOO =False ):
        O0O00O00O0O0OOOOO .addDirectoryItem ('BurninU Movies','movies&url=bumovies','burninu.png','DefaultMovies.png')
        O0O00O00O0O0OOOOO .endDirectory ()
    def dcmarvelherosNavigator (OO00OO00O0OO000OO ,O00OOOO000000O000 =False ):
        OO00OO00O0OO000OO .addDirectoryItem ('[COLOR springgreen]Provided by[/COLOR] [COLOR red]Dc[/COLOR]v[COLOR white]Marvel[/COLOR][COLOR blue]Build[/COLOR]','dcmarvelherosNavigator','dcmarvelbuild.png','DefaultVideoPlaylists.png')
        OO00OO00O0OO000OO .addDirectoryItem ('[COLOR red]DC Universe[/COLOR]','movies&url=dcmovies','dcmarvelheros.png','DefaultVideoPlaylists.png')
        OO00OO00O0OO000OO .addDirectoryItem ('[COLOR white]Marvel Universe[/COLOR]','movies&url=marvelmovies','dcmarvelheros.png','DefaultVideoPlaylists.png')
        OO00OO00O0OO000OO .addDirectoryItem ('[COLOR blue]SuperHeros[/COLOR]','movies&url=superhero','dcmarvelheros.png','DefaultVideoPlaylists.png')
        OO00OO00O0OO000OO .endDirectory ()
    def imdbnavigator (O0000OO0O0O0OO00O ,O00O0O0OO0OO0000O =False ):
        O0000OO0O0O0OO00O .addDirectoryItem ('IMDB Movies List(s)','imdbmovies','icon.png','DefaultMovies.png')
        if control .getMenuEnabled ('navi.movie.imdb.boxoffice'):
            O0000OO0O0O0OO00O .addDirectoryItem (32435 if indexLabels else 32434 ,'movies&url=imdbboxoffice','imdb.png'if iconLogos else 'box-office.png','DefaultMovies.png')
        if control .getMenuEnabled ('navi.movie.imdb.certificates'):
            O0000OO0O0O0OO00O .addDirectoryItem (32464 if indexLabels else 32463 ,'movieCertificates','imdb.png'if iconLogos else 'certificates.png','DefaultMovies.png')
        if control .getMenuEnabled ('navi.movie.imdb.featured'):
            O0000OO0O0O0OO00O .addDirectoryItem (32447 if indexLabels else 32446 ,'movies&url=featured','imdb.png'if iconLogos else 'movies.png','DefaultMovies.png')
        if control .getMenuEnabled ('navi.movie.imdb.genres'):
            O0000OO0O0O0OO00O .addDirectoryItem (32456 if indexLabels else 32455 ,'movieGenres','imdb.png'if iconLogos else 'genres.png','DefaultGenre.png')
        if control .getMenuEnabled ('navi.movie.imdb.intheater'):
            O0000OO0O0O0OO00O .addDirectoryItem (32421 if indexLabels else 32420 ,'movies&url=theaters','imdb.png'if iconLogos else 'in-theaters.png','DefaultMovies.png')
        if control .getMenuEnabled ('navi.movie.imdb.languages'):
            O0000OO0O0O0OO00O .addDirectoryItem (32462 if indexLabels else 32461 ,'movieLanguages','imdb.png'if iconLogos else 'languages.png','DefaultAddonLanguage.png')
        if control .getMenuEnabled ('navi.movie.imdb.popular'):
            O0000OO0O0O0OO00O .addDirectoryItem (32429 if indexLabels else 32428 ,'movies&url=mostpopular','imdb.png'if iconLogos else 'most-popular.png','DefaultMovies.png')
        if control .getMenuEnabled ('navi.movie.imdb.mostvoted'):
            O0000OO0O0O0OO00O .addDirectoryItem (32439 if indexLabels else 32438 ,'movies&url=mostvoted','imdb.png'if iconLogos else 'most-voted.png','DefaultMovies.png')
        if control .getMenuEnabled ('navi.movie.imdb.oscarwinners'):
            O0000OO0O0O0OO00O .addDirectoryItem (32452 if indexLabels else 32451 ,'movies&url=oscars','imdb.png'if iconLogos else 'oscar-winners.png','DefaultMovies.png')
        if control .getMenuEnabled ('navi.movie.imdb.oscarnominees'):
            O0000OO0O0O0OO00O .addDirectoryItem (32454 if indexLabels else 32453 ,'movies&url=oscarsnominees','imdb.png'if iconLogos else 'oscar-winners.png','DefaultMovies.png')
        if control .getMenuEnabled ('navi.movie.imdb.people'):
            O0000OO0O0O0OO00O .addDirectoryItem (32460 if indexLabels else 32459 ,'moviePersons','imdb.png'if iconLogos else 'people.png','DefaultActor.png')
        if control .getMenuEnabled ('navi.movie.imdb.years'):
            O0000OO0O0O0OO00O .addDirectoryItem (32458 if indexLabels else 32457 ,'movieYears','imdb.png'if iconLogos else 'years.png','DefaultYear.png')
        O0000OO0O0O0OO00O .addDirectoryItem (33044 ,'moviePerson','imdb.png'if iconLogos else 'people-search.png','DefaultAddonsSearch.png')
        O0000OO0O0O0OO00O .addDirectoryItem (33042 ,'movieSearch','trakt.png'if iconLogos else 'search.png','DefaultAddonsSearch.png')
        O0000OO0O0O0OO00O .addDirectoryItem (32008 ,'tools_toolNavigator','tools.png','DefaultAddonService.png')
        O0000OO0O0O0OO00O .endDirectory ()
    def imdbmovies (OO0O00O000OO0000O ):
        OO0O00O000OO0000O .addDirectoryItem ('Abbot n Costello','movies&url=abbottcostello','icon.png','DefaultMovies.png')
        OO0O00O000OO0000O .addDirectoryItem ('Jerry Lewis & Dean Martin','movies&url=lewismartin','icon.png','DefaultMovies.png')
        OO0O00O000OO0000O .addDirectoryItem ('Top 100','movies&url=top100','icon.png','DefaultMovies.png')
        OO0O00O000OO0000O .addDirectoryItem ('Top 250','movies&url=top250','icon.png','DefaultMovies.png')
        OO0O00O000OO0000O .addDirectoryItem ('Top 1000','movies&url=top1000','icon.png','DefaultMovies.png')
        OO0O00O000OO0000O .addDirectoryItem ('Rated G','movies&url=rated_g','icon.png','DefaultMovies.png')
        OO0O00O000OO0000O .addDirectoryItem ('Rated PG','movies&url=rated_pg','icon.png','DefaultMovies.png')
        OO0O00O000OO0000O .addDirectoryItem ('Rated PG13','movies&url=rated_pg13','icon.png','DefaultMovies.png')
        OO0O00O000OO0000O .addDirectoryItem ('Rated R','movies&url=rated_r','icon.png','DefaultMovies.png')
        OO0O00O000OO0000O .addDirectoryItem ('Rated NC17','movies&url=rated_nc17','icon.png','DefaultMovies.png')
        OO0O00O000OO0000O .addDirectoryItem ('Best Director','movies&url=bestdirector','icon.png','DefaultMovies.png')
        OO0O00O000OO0000O .addDirectoryItem ('National Film Board','movies&url=national_film_board','icon.png','DefaultMovies.png')
        OO0O00O000OO0000O .addDirectoryItem ('Dreamworks','movies&url=dreamworks_pictures','icon.png','DefaultMovies.png')
        OO0O00O000OO0000O .addDirectoryItem ('Fox','movies&url=fox_pictures','icon.png','DefaultMovies.png')
        OO0O00O000OO0000O .addDirectoryItem ('Paramount','movies&url=paramount_pictures','icon.png','DefaultMovies.png')
        OO0O00O000OO0000O .addDirectoryItem ('MGM','movies&url=mgm_pictures','icon.png','DefaultMovies.png')
        OO0O00O000OO0000O .addDirectoryItem ('Universal','movies&url=universal_pictures','icon.png','DefaultMovies.png')
        OO0O00O000OO0000O .addDirectoryItem ('Sony','movies&url=sony_pictures','icon.png','DefaultMovies.png')
        OO0O00O000OO0000O .addDirectoryItem ('Warner Brothers','movies&url=warnerbrothers_pictures','icon.png','DefaultMovies.png')
        OO0O00O000OO0000O .addDirectoryItem ('Amazon Prime','movies&url=amazon_prime','icon.png','DefaultMovies.png')
        OO0O00O000OO0000O .addDirectoryItem ('Disney','movies&url=disney_pictures','icon.png','DefaultMovies.png')
        OO0O00O000OO0000O .addDirectoryItem ('Family','movies&url=family_movies','icon.png','DefaultMovies.png')
        OO0O00O000OO0000O .addDirectoryItem ('Classics','movies&url=classic_movies','icon.png','DefaultMovies.png')
        OO0O00O000OO0000O .addDirectoryItem ('Classic Horror','movies&url=classic_horror','icon.png','DefaultMovies.png')
        OO0O00O000OO0000O .addDirectoryItem ('Classic Fantasy','movies&url=classic_fantasy','icon.png','DefaultMovies.png')
        OO0O00O000OO0000O .addDirectoryItem ('Classic Western','movies&url=classic_western','icon.png','DefaultMovies.png')
        OO0O00O000OO0000O .addDirectoryItem ('Classic Animation','movies&url=classic_animation','icon.png','DefaultMovies.png')
        OO0O00O000OO0000O .addDirectoryItem ('Classic War','movies&url=classic_war','icon.png','DefaultMovies.png')
        OO0O00O000OO0000O .addDirectoryItem ('Classic Scifi','movies&url=classic_scifi','icon.png','DefaultMovies.png')
        OO0O00O000OO0000O .addDirectoryItem ('80s','movies&url=eighties','icon.png','DefaultMovies.png')
        OO0O00O000OO0000O .addDirectoryItem ('90s','movies&url=nineties','icon.png','DefaultMovies.png')
        OO0O00O000OO0000O .addDirectoryItem ('2000s','movies&url=twentyzeros','icon.png','DefaultMovies.png')
        OO0O00O000OO0000O .addDirectoryItem ('2010s','movies&url=twentyten','icon.png','DefaultMovies.png')
        OO0O00O000OO0000O .addDirectoryItem ('2020s','movies&url=twentytwenty','icon.png','DefaultMovies.png')
        OO0O00O000OO0000O .endDirectory ()
    def imdbtvshows (OO000O00O0000OO00 ):
        OO000O00O0000OO00 .addDirectoryItem ('NAME1','tvshows&url=usprime','icon.png','DefaultTVShows.png')
        OO000O00O0000OO00 .addDirectoryItem ('NAME2','tvshows&url=classtv','icon.png','DefaultTVShows.png')
        OO000O00O0000OO00 .addDirectoryItem ('NAME3','tvshows&url=ghostadv','icon.png','DefaultTVShows.png')
        OO000O00O0000OO00 .addDirectoryItem ('NAME4','tvshows&url=mosth','icon.png','DefaultTVShows.png')
        OO000O00O0000OO00 .addDirectoryItem ('NAME5','tvshows&url=ghosth','icon.png','DefaultTVShows.png')
        OO000O00O0000OO00 .addDirectoryItem ('NAME6','tvshows&url=paraw','icon.png','DefaultTVShows.png')
        OO000O00O0000OO00 .addDirectoryItem ('NAME7','tvshows&url=paral','icon.png','DefaultTVShows.png')
        OO000O00O0000OO00 .addDirectoryItem ('NAME8','tvshows&url=haunt','icon.png','DefaultTVShows.png')
        OO000O00O0000OO00 .addDirectoryItem ('NAME9','tvshows&url=hauntc','icon.png','DefaultTVShows.png')
        OO000O00O0000OO00 .addDirectoryItem ('NAME10','tvshows&url=deadp','icon.png','DefaultTVShows.png')
        OO000O00O0000OO00 .addDirectoryItem ('NAME11','tvshows&url=ghosta','icon.png','DefaultTVShows.png')
        OO000O00O0000OO00 .addDirectoryItem ('NAME12','tvshows&url=paran','icon.png','DefaultTVShows.png')
        OO000O00O0000OO00 .addDirectoryItem ('NAME13','tvshows&url=ghosti','icon.png','DefaultTVShows.png')
        OO000O00O0000OO00 .addDirectoryItem ('NAME14','tvshows&url=docsa','icon.png','DefaultTVShows.png')
        OO000O00O0000OO00 .addDirectoryItem ('NAME15','tvshows&url=myst','icon.png','DefaultTVShows.png')
        OO000O00O0000OO00 .addDirectoryItem ('NAME16','tvshows&url=scifi1','icon.png','DefaultTVShows.png')
        OO000O00O0000OO00 .addDirectoryItem ('NAME17','tvshows&url=userr','icon.png','DefaultTVShows.png')
        OO000O00O0000OO00 .addDirectoryItem ('NAME18','tvshows&url=mini','icon.png','DefaultTVShows.png')
        OO000O00O0000OO00 .addDirectoryItem ('NAME19','tvshows&url=pg','icon.png','DefaultTVShows.png')
        OO000O00O0000OO00 .addDirectoryItem ('NAME20','tvshows&url=famtv','icon.png','DefaultTVShows.png')
        OO000O00O0000OO00 .addDirectoryItem ('NAME21','tvshows&url=scian','icon.png','DefaultTVShows.png')
        OO000O00O0000OO00 .addDirectoryItem ('NAME22','tvshows&url=ani1','icon.png','DefaultTVShows.png')
        OO000O00O0000OO00 .addDirectoryItem ('NAME23','tvshows&url=rtv','icon.png','DefaultTVShows.png')
        OO000O00O0000OO00 .addDirectoryItem ('NAME24','tvshows&url=waltd','icon.png','DefaultTVShows.png')
        OO000O00O0000OO00 .addDirectoryItem ('NAME25','tvshows&url=dreamw','icon.png','DefaultTVShows.png')
        OO000O00O0000OO00 .addDirectoryItem ('NAME26','tvshows&url=sony3','icon.png','DefaultTVShows.png')
        OO000O00O0000OO00 .addDirectoryItem ('NAME27','tvshows&url=warnerbro1','icon.png','DefaultTVShows.png')
        OO000O00O0000OO00 .addDirectoryItem ('NAME28','tvshows&url=uni1','icon.png','DefaultTVShows.png')
        OO000O00O0000OO00 .addDirectoryItem ('NAME29','tvshows&url=fox11','icon.png','DefaultTVShows.png')
        OO000O00O0000OO00 .addDirectoryItem ('NAME30','tvshows&url=para4','icon.png','DefaultTVShows.png')
        OO000O00O0000OO00 .addDirectoryItem ('NAME31','tvshows&url=mgm5','icon.png','DefaultTVShows.png')
        OO000O00O0000OO00 .addDirectoryItem ('NAME','tvshows&url=NAME','icon.png','DefaultTVShows.png')
        OO000O00O0000OO00 .endDirectory ()
    def tmdbnavigator (OO00O00OO0000OOOO ):
        OO00O00OO0000OOOO .addDirectoryItem ('TMDB User Movies List(s)','usertmdbmovies','mymovies.png','mymovies.png')
        OO00O00OO0000OOOO .addDirectoryItem ('TMDB Empire Movies List(s)','empiremovies','mymovies.png','mymovies.png')
        if control .getMenuEnabled ('navi.movie.tmdb.boxoffice'):
            OO00O00OO0000OOOO .addDirectoryItem (32436 if indexLabels else 32434 ,'tmdbmovies&url=tmdb_boxoffice','tmdb.png'if iconLogos else 'box-office.png','DefaultMovies.png')
        if control .getMenuEnabled ('navi.movie.tmdb.nowplaying'):
            OO00O00OO0000OOOO .addDirectoryItem (32423 if indexLabels else 32422 ,'tmdbmovies&url=tmdb_nowplaying','tmdb.png'if iconLogos else 'in-theaters.png','DefaultMovies.png')
        if control .getMenuEnabled ('navi.movie.tmdb.popular'):
            OO00O00OO0000OOOO .addDirectoryItem (32431 if indexLabels else 32430 ,'tmdbmovies&url=tmdb_popular','tmdb.png'if iconLogos else 'most-popular.png','DefaultMovies.png')
        if control .getMenuEnabled ('navi.movie.tmdb.toprated'):
            OO00O00OO0000OOOO .addDirectoryItem (32441 if indexLabels else 32440 ,'tmdbmovies&url=tmdb_toprated','tmdb.png'if iconLogos else 'most-voted.png','DefaultMovies.png')
        if control .getMenuEnabled ('navi.movie.tmdb.upcoming'):
            OO00O00OO0000OOOO .addDirectoryItem (32427 if indexLabels else 32426 ,'tmdbmovies&url=tmdb_upcoming','tmdb.png'if iconLogos else 'in-theaters.png','DefaultMovies.png')
        OO00O00OO0000OOOO .addDirectoryItem (33044 ,'moviePerson','imdb.png'if iconLogos else 'people-search.png','DefaultAddonsSearch.png')
        OO00O00OO0000OOOO .addDirectoryItem (33042 ,'movieSearch','trakt.png'if iconLogos else 'search.png','DefaultAddonsSearch.png')
        OO00O00OO0000OOOO .addDirectoryItem (32008 ,'tools_toolNavigator','tools.png','DefaultAddonService.png')
        OO00O00OO0000OOOO .endDirectory ()
    def empiremovies (OOO0OOO00000O00O0 ):
        OOO0OOO00000O00O0 .addDirectoryItem (mymovlist1 ,'tmdbmovies&url=mycustommovlist1','mymovies.png','mymovies.png')
        OOO0OOO00000O00O0 .addDirectoryItem (mymovlist2 ,'tmdbmovies&url=mycustommovlist2','mymovies.png','mymovies.png')
        OOO0OOO00000O00O0 .addDirectoryItem (mymovlist3 ,'tmdbmovies&url=mycustommovlist3','mymovies.png','mymovies.png')
        OOO0OOO00000O00O0 .addDirectoryItem (mymovlist4 ,'tmdbmovies&url=mycustommovlist4','mymovies.png','mymovies.png')
        OOO0OOO00000O00O0 .addDirectoryItem (mymovlist5 ,'tmdbmovies&url=mycustommovlist5','mymovies.png','mymovies.png')
        OOO0OOO00000O00O0 .addDirectoryItem (mymovlist6 ,'tmdbmovies&url=mycustommovlist6','mymovies.png','mymovies.png')
        OOO0OOO00000O00O0 .addDirectoryItem (mymovlist7 ,'tmdbmovies&url=mycustommovlist7','mymovies.png','mymovies.png')
        OOO0OOO00000O00O0 .addDirectoryItem (mymovlist8 ,'tmdbmovies&url=mycustommovlist8','mymovies.png','mymovies.png')
        OOO0OOO00000O00O0 .addDirectoryItem (mymovlist9 ,'tmdbmovies&url=mycustommovlist9','mymovies.png','mymovies.png')
        OOO0OOO00000O00O0 .addDirectoryItem (mymovlist10 ,'tmdbmovies&url=mycustommovlist10','mymovies.png','mymovies.png')
        OOO0OOO00000O00O0 .endDirectory ()
    def empiretv (OO00OOO00OOO0OOOO ):
        OO00OOO00OOO0OOOO .addDirectoryItem (mytvlist1 ,'tmdbtvshows&url=mycustomtvlist1','mytvshows.png','mytvshows.png')
        OO00OOO00OOO0OOOO .addDirectoryItem (mytvlist2 ,'tmdbtvshows&url=mycustomtvlist2','mytvshows.png','mytvshows.png')
        OO00OOO00OOO0OOOO .addDirectoryItem (mytvlist3 ,'tmdbtvshows&url=mycustomtvlist3','mytvshows.png','mytvshows.png')
        OO00OOO00OOO0OOOO .addDirectoryItem (mytvlist4 ,'tmdbtvshows&url=mycustomtvlist4','mytvshows.png','mytvshows.png')
        OO00OOO00OOO0OOOO .addDirectoryItem (mytvlist5 ,'tmdbtvshows&url=mycustomtvlist5','mytvshows.png','mytvshows.png')
        OO00OOO00OOO0OOOO .addDirectoryItem (mytvlist6 ,'tmdbtvshows&url=mycustomtvlist6','mytvshows.png','mytvshows.png')
        OO00OOO00OOO0OOOO .addDirectoryItem (mytvlist7 ,'tmdbtvshows&url=mycustomtvlist7','mytvshows.png','mytvshows.png')
        OO00OOO00OOO0OOOO .addDirectoryItem (mytvlist8 ,'tmdbtvshows&url=mycustomtvlist8','mytvshows.png','mytvshows.png')
        OO00OOO00OOO0OOOO .addDirectoryItem (mytvlist9 ,'tmdbtvshows&url=mycustomtvlist9','mytvshows.png','mytvshows.png')
        OO00OOO00OOO0OOOO .addDirectoryItem (mytvlist10 ,'tmdbtvshows&url=mycustomtvlist10','mytvshows.png','mytvshows.png')
        OO00OOO00OOO0OOOO .endDirectory ()
    def usertmdbmovies (O00OO000O0OO000OO ):
        O00OO000O0OO000OO .addDirectoryItem (movielist1 ,'tmdbmovies&url=mycustomlist1','mymovies.png','mymovies.png')
        O00OO000O0OO000OO .addDirectoryItem (movielist2 ,'tmdbmovies&url=mycustomlist2','mymovies.png','mymovies.png')
        O00OO000O0OO000OO .addDirectoryItem (movielist3 ,'tmdbmovies&url=mycustomlist3','mymovies.png','mymovies.png')
        O00OO000O0OO000OO .addDirectoryItem (movielist4 ,'tmdbmovies&url=mycustomlist4','mymovies.png','mymovies.png')
        O00OO000O0OO000OO .addDirectoryItem (movielist5 ,'tmdbmovies&url=mycustomlist5','mymovies.png','mymovies.png')
        O00OO000O0OO000OO .addDirectoryItem (movielist6 ,'tmdbmovies&url=mycustomlist6','mymovies.png','mymovies.png')
        O00OO000O0OO000OO .addDirectoryItem (movielist7 ,'tmdbmovies&url=mycustomlist7','mymovies.png','mymovies.png')
        O00OO000O0OO000OO .addDirectoryItem (movielist8 ,'tmdbmovies&url=mycustomlist8','mymovies.png','mymovies.png')
        O00OO000O0OO000OO .addDirectoryItem (movielist9 ,'tmdbmovies&url=mycustomlist9','mymovies.png','mymovies.png')
        O00OO000O0OO000OO .addDirectoryItem (movielist10 ,'tmdbmovies&url=mycustomlist10','mymovies.png','mymovies.png')
        O00OO000O0OO000OO .endDirectory ()
    def usertmdbtv (O0OOO0OO00O0OOO00 ):
        O0OOO0OO00O0OOO00 .addDirectoryItem (tvlist1 ,'tmdbtvshows&url=mycustomlist1','mytvshows.png','mytvshows.png')
        O0OOO0OO00O0OOO00 .addDirectoryItem (tvlist2 ,'tmdbtvshows&url=mycustomlist2','mytvshows.png','mytvshows.png')
        O0OOO0OO00O0OOO00 .addDirectoryItem (tvlist3 ,'tmdbtvshows&url=mycustomlist3','mytvshows.png','mytvshows.png')
        O0OOO0OO00O0OOO00 .addDirectoryItem (tvlist4 ,'tmdbtvshows&url=mycustomlist4','mytvshows.png','mytvshows.png')
        O0OOO0OO00O0OOO00 .addDirectoryItem (tvlist5 ,'tmdbtvshows&url=mycustomlist5','mytvshows.png','mytvshows.png')
        O0OOO0OO00O0OOO00 .addDirectoryItem (tvlist6 ,'tmdbtvshows&url=mycustomlist6','mytvshows.png','mytvshows.png')
        O0OOO0OO00O0OOO00 .addDirectoryItem (tvlist7 ,'tmdbtvshows&url=mycustomlist7','mytvshows.png','mytvshows.png')
        O0OOO0OO00O0OOO00 .addDirectoryItem (tvlist8 ,'tmdbtvshows&url=mycustomlist8','mytvshows.png','mytvshows.png')
        O0OOO0OO00O0OOO00 .addDirectoryItem (tvlist9 ,'tmdbtvshows&url=mycustomlist9','mytvshows.png','mytvshows.png')
        O0OOO0OO00O0OOO00 .addDirectoryItem (tvlist10 ,'tmdbtvshows&url=mycustomlist10','mytvshows.png','mytvshows.png')
        O0OOO0OO00O0OOO00 .endDirectory ()
    def tools (OO0OOO0000OO0OOO0 ):
        OO0OOO0000OO0OOO0 .addDirectoryItem (32510 ,'cache_Navigator','tools.png','DefaultAddonService.png',isFolder =True )
        OO0OOO0000OO0OOO0 .addDirectoryItem (32609 ,'tools_openMyAccount','MyAccounts.png','DefaultAddonService.png',isFolder =False )
        if control .condVisibility ('System.HasAddon(service.upnext)'):
            OO0OOO0000OO0OOO0 .addDirectoryItem (32505 ,'tools_UpNextSettings','UpNext.png','DefaultAddonProgram.png',isFolder =False )
        OO0OOO0000OO0OOO0 .addDirectoryItem (32506 ,'tools_contextLESettings','icon.png','DefaultAddonProgram.png',isFolder =False )
        OO0OOO0000OO0OOO0 .addDirectoryItem (32651 ,'tools_fenomscrapersSettings','fenomscrapers.png','DefaultAddonService.png',isFolder =False )
        OO0OOO0000OO0OOO0 .addDirectoryItem (32083 ,'tools_cleanSettings','tools.png','DefaultAddonProgram.png',isFolder =False )
        OO0OOO0000OO0OOO0 .addDirectoryItem (32043 ,'tools_openSettings&query=0.0','tools.png','DefaultAddonService.png',isFolder =False )
        OO0OOO0000OO0OOO0 .addDirectoryItem (32362 ,'tools_openSettings&query=1.1','tools.png','DefaultAddonService.png',isFolder =False )
        OO0OOO0000OO0OOO0 .addDirectoryItem (32045 ,'tools_openSettings&query=3.1','tools.png','DefaultAddonService.png',isFolder =False )
        OO0OOO0000OO0OOO0 .addDirectoryItem (32044 ,'tools_openSettings&query=7.0','tools.png','DefaultAddonService.png',isFolder =False )
        OO0OOO0000OO0OOO0 .addDirectoryItem (32048 ,'tools_openSettings&query=9.0','tools.png','DefaultAddonService.png',isFolder =False )
        OO0OOO0000OO0OOO0 .addDirectoryItem (32046 ,'tools_openSettings&query=10.0','tools.png','DefaultAddonService.png',isFolder =False )
        OO0OOO0000OO0OOO0 .addDirectoryItem ('[B]SETTINGS[/B] : TMDB User Movies List(s)','tools_openSettings&query=13.0','tmdb.png','DefaultAddonService.png',isFolder =False )
        OO0OOO0000OO0OOO0 .addDirectoryItem (32556 ,'library_Navigator','tools.png','DefaultAddonService.png',isFolder =True )
        OO0OOO0000OO0OOO0 .addDirectoryItem (32049 ,'tools_viewsNavigator','tools.png','DefaultAddonService.png',isFolder =True )
        OO0OOO0000OO0OOO0 .addDirectoryItem (32361 ,'tools_resetViewTypes','tools.png','DefaultAddonService.png',isFolder =False )
        OO0OOO0000OO0OOO0 .endDirectory ()
    def cf (O00O0O0OOO00O000O ):
        O00O0O0OOO00O000O .addDirectoryItem (32610 ,'cache_clearAll','tools.png','DefaultAddonService.png',isFolder =False )
        O00O0O0OOO00O000O .addDirectoryItem (32611 ,'cache_clearSources','tools.png','DefaultAddonService.png',isFolder =False )
        O00O0O0OOO00O000O .addDirectoryItem (32612 ,'cache_clearMeta','tools.png','DefaultAddonService.png',isFolder =False )
        O00O0O0OOO00O000O .addDirectoryItem (32613 ,'cache_clearCache','tools.png','DefaultAddonService.png',isFolder =False )
        O00O0O0OOO00O000O .addDirectoryItem (32614 ,'cache_clearSearch','tools.png','DefaultAddonService.png',isFolder =False )
        O00O0O0OOO00O000O .addDirectoryItem (32615 ,'cache_clearBookmarks','tools.png','DefaultAddonService.png',isFolder =False )
        O00O0O0OOO00O000O .endDirectory ()
    def library (OO0OO000O0000OO00 ):
        OO0OO000O0000OO00 .addDirectoryItem (32557 ,'tools_openSettings&query=8.0','tools.png','DefaultAddonProgram.png',isFolder =False )
        OO0OO000O0000OO00 .addDirectoryItem (32558 ,'library_update','library_update.png','DefaultAddonLibrary.png',isFolder =False )
        OO0OO000O0000OO00 .addDirectoryItem (32676 ,'library_clean','library_update.png','DefaultAddonLibrary.png',isFolder =False )
        OO0OO000O0000OO00 .addDirectoryItem (32559 ,control .setting ('library.movie'),'movies.png','DefaultMovies.png',isAction =False )
        OO0OO000O0000OO00 .addDirectoryItem (32560 ,control .setting ('library.tv'),'tvshows.png','DefaultTVShows.png',isAction =False )
        if traktCredentials :
            OO0OO000O0000OO00 .addDirectoryItem (32561 ,'library_moviesToLibrary&url=traktcollection&name=traktcollection','trakt.png','DefaultMovies.png',isFolder =False )
            OO0OO000O0000OO00 .addDirectoryItem (32562 ,'library_moviesToLibrary&url=traktwatchlist&name=traktwatchlist','trakt.png','DefaultMovies.png',isFolder =False )
            OO0OO000O0000OO00 .addDirectoryItem (32672 ,'library_moviesListToLibrary&url=traktlists','trakt.png','DefaultMovies.png',isFolder =False )
            OO0OO000O0000OO00 .addDirectoryItem (32673 ,'library_moviesListToLibrary&url=traktlikedlists','trakt.png','DefaultMovies.png',isFolder =False )
        if tmdbSessionID :
            OO0OO000O0000OO00 .addDirectoryItem ('TMDb: Import Movie Watchlist...','library_moviesToLibrary&url=tmdb_watchlist&name=tmdb_watchlist','tmdb.png','DefaultMovies.png',isFolder =False )
            OO0OO000O0000OO00 .addDirectoryItem ('TMDb: Import Movie Favorites...','library_moviesToLibrary&url=tmdb_favorites&name=tmdb_favorites','tmdb.png','DefaultMovies.png',isFolder =False )
            OO0OO000O0000OO00 .addDirectoryItem ('TMDb: Import Movie User list...','library_moviesListToLibrary&url=tmdb_userlists','tmdb.png','DefaultMovies.png',isFolder =False )
        if traktCredentials :
            OO0OO000O0000OO00 .addDirectoryItem (32563 ,'library_tvshowsToLibrary&url=traktcollection&name=traktcollection','trakt.png','DefaultTVShows.png',isFolder =False )
            OO0OO000O0000OO00 .addDirectoryItem (32564 ,'library_tvshowsToLibrary&url=traktwatchlist&name=traktwatchlist','trakt.png','DefaultTVShows.png',isFolder =False )
            OO0OO000O0000OO00 .addDirectoryItem (32674 ,'library_tvshowsListToLibrary&url=traktlists','trakt.png','DefaultMovies.png',isFolder =False )
            OO0OO000O0000OO00 .addDirectoryItem (32675 ,'library_tvshowsListToLibrary&url=traktlikedlists','trakt.png','DefaultMovies.png',isFolder =False )
        if tmdbSessionID :
            OO0OO000O0000OO00 .addDirectoryItem ('TMDb: Import TV Watchlist...','library_tvshowsToLibrary&url=tmdb_watchlist&name=tmdb_watchlist','tmdb.png','DefaultMovies.png',isFolder =False )
            OO0OO000O0000OO00 .addDirectoryItem ('TMDb: Import TV Favorites...','library_tvshowsToLibrary&url=tmdb_favorites&name=tmdb_favorites','tmdb.png','DefaultMovies.png',isFolder =False )
            OO0OO000O0000OO00 .addDirectoryItem ('TMDb: Import TV User list...','library_tvshowsListToLibrary&url=tmdb_userlists','tmdb.png','DefaultMovies.png',isFolder =False )
        OO0OO000O0000OO00 .endDirectory ()
    def downloads (O00O0OOOO0O0O00O0 ):
        OOOO00OO0000000O0 =control .setting ('movie.download.path')
        O00O0OO0O0O00O0OO =control .setting ('tv.download.path')
        if len (control .listDir (OOOO00OO0000000O0 )[0 ])>0 :O00O0OOOO0O0O00O0 .addDirectoryItem (32001 ,OOOO00OO0000000O0 ,'movies.png','DefaultMovies.png',isAction =False )
        if len (control .listDir (O00O0OO0O0O00O0OO )[0 ])>0 :O00O0OOOO0O0O00O0 .addDirectoryItem (32002 ,O00O0OO0O0O00O0OO ,'tvshows.png','DefaultTVShows.png',isAction =False )
        O00O0OOOO0O0O00O0 .endDirectory ()
    def premium_services (O0O00OO0OO0O0OO00 ):
        O0O00OO0OO0O0OO00 .addDirectoryItem (40059 ,'ad_ServiceNavigator','alldebrid.png','DefaultAddonService.png')
        O0O00OO0OO0O0OO00 .addDirectoryItem (40057 ,'pm_ServiceNavigator','premiumize.png','DefaultAddonService.png')
        O0O00OO0OO0O0OO00 .addDirectoryItem (40058 ,'rd_ServiceNavigator','realdebrid.png','DefaultAddonService.png')
        O0O00OO0OO0O0OO00 .endDirectory ()
    def alldebrid_service (OO0OO0O0O00000O0O ):
        if control .setting ('alldebrid.token'):
            OO0OO0O0O00000O0O .addDirectoryItem ('All-Debrid: Cloud Storage','ad_CloudStorage','alldebrid.png','DefaultAddonService.png')
            OO0OO0O0O00000O0O .addDirectoryItem ('All-Debrid: Transfers','ad_Transfers','alldebrid.png','DefaultAddonService.png')
            OO0OO0O0O00000O0O .addDirectoryItem ('All-Debrid: Account Info','ad_AccountInfo','alldebrid.png','DefaultAddonService.png',isFolder =False )
        else :
            OO0OO0O0O00000O0O .addDirectoryItem ('[I]Please visit My Accounts for setup[/I]','tools_openMyAccount&amp;query=1.4','alldebrid.png','DefaultAddonService.png',isFolder =False )
        OO0OO0O0O00000O0O .endDirectory ()
    def premiumize_service (O0OO0000OOOOO0000 ):
        if control .setting ('premiumize.token'):
            O0OO0000OOOOO0000 .addDirectoryItem ('Premiumize: My Files','pm_MyFiles','premiumize.png','DefaultAddonService.png')
            O0OO0000OOOOO0000 .addDirectoryItem ('Premiumize: Transfers','pm_Transfers','premiumize.png','DefaultAddonService.png')
            O0OO0000OOOOO0000 .addDirectoryItem ('Premiumize: Account Info','pm_AccountInfo','premiumize.png','DefaultAddonService.png',isFolder =False )
        else :
            O0OO0000OOOOO0000 .addDirectoryItem ('[I]Please visit My Accounts for setup[/I]','tools_openMyAccount&amp;query=1.11','premiumize.png','DefaultAddonService.png',isFolder =False )
        O0OO0000OOOOO0000 .endDirectory ()
    def realdebrid_service (OO0OO00O0OOOO0000 ):
        if control .setting ('realdebrid.token'):
            OO0OO00O0OOOO0000 .addDirectoryItem ('Real-Debrid: Torrent Transfers','rd_UserTorrentsToListItem','realdebrid.png','DefaultAddonService.png')
            OO0OO00O0OOOO0000 .addDirectoryItem ('Real-Debrid: My Downloads','rd_MyDownloads&query=1','realdebrid.png','DefaultAddonService.png')
            OO0OO00O0OOOO0000 .addDirectoryItem ('Real-Debrid: Account Info','rd_AccountInfo','realdebrid.png','DefaultAddonService.png',isFolder =False )
        else :
            OO0OO00O0OOOO0000 .addDirectoryItem ('[I]Please visit My Accounts for setup[/I]','tools_openMyAccount&amp;query=1.18','realdebrid.png','DefaultAddonService.png',isFolder =False )
        OO0OO00O0OOOO0000 .endDirectory ()
    def search (O000OO0OOO00O0O0O ):
        O000OO0OOO00O0O0O .addDirectoryItem (33042 ,'movieSearch','trakt.png'if iconLogos else 'search.png','DefaultAddonsSearch.png')
        O000OO0OOO00O0O0O .addDirectoryItem (33043 ,'tvSearch','trakt.png'if iconLogos else 'search.png','DefaultAddonsSearch.png')
        O000OO0OOO00O0O0O .addDirectoryItem (33044 ,'moviePerson','imdb.png'if iconLogos else 'people-search.png','DefaultAddonsSearch.png')
        O000OO0OOO00O0O0O .addDirectoryItem (33045 ,'tvPerson','imdb.png'if iconLogos else 'people-search.png','DefaultAddonsSearch.png')
        O000OO0OOO00O0O0O .addDirectoryItem (32008 ,'tools_toolNavigator','tools.png','DefaultAddonService.png')
        O000OO0OOO00O0O0O .endDirectory ()
    def views (OO0OO00O00OO00O0O ):
        try :
            OO0OOO000O00O00OO =int (argv [1 ])
            control .hide ()
            O0OO00OOOOO0000O0 =[(control .lang (32001 ),'movies'),(control .lang (32002 ),'tvshows'),(control .lang (32054 ),'seasons'),(control .lang (32038 ),'episodes')]
            O0OO000O0OO0OO00O =control .selectDialog ([O0O0O0OOO0OO00OOO [0 ]for O0O0O0OOO0OO00OOO in O0OO00OOOOO0000O0 ],control .lang (32049 ))
            if O0OO000O0OO0OO00O ==-1 :return 
            OO00O00OO0OO0O00O =O0OO00OOOOO0000O0 [O0OO000O0OO0OO00O ][1 ]
            O000OOO0O0O000O0O =control .lang (32059 )
            OOO0O0O00000O00OO ='%s?action=tools_addView&content=%s'%(argv [0 ],OO00O00OO0OO0O00O )
            OO00O0O0O000OOO00 ,OO0OO0OO0OOO0O0O0 ,OOOO0OOOOOOO00O0O =control .addonPoster (),control .addonBanner (),control .addonFanart ()
            try :OO0O00OO00OOOOO0O =control .item (label =O000OOO0O0O000O0O ,offscreen =True )
            except :OO0O00OO00OOOOO0O =control .item (label =O000OOO0O0O000O0O )
            OO0O00OO00OOOOO0O .setInfo (type ='video',infoLabels ={'title':O000OOO0O0O000O0O })
            OO0O00OO00OOOOO0O .setArt ({'icon':OO00O0O0O000OOO00 ,'thumb':OO00O0O0O000OOO00 ,'poster':OO00O0O0O000OOO00 ,'fanart':OOOO0OOOOOOO00O0O ,'banner':OO0OO0OO0OOO0O0O0 })
            OO0O00OO00OOOOO0O .setProperty ('IsPlayable','false')
            control .addItem (handle =OO0OOO000O00O00OO ,url =OOO0O0O00000O00OO ,listitem =OO0O00OO00OOOOO0O ,isFolder =False )
            control .content (OO0OOO000O00O00OO ,OO00O00OO0OO0O00O )
            control .directory (OO0OOO000O00O00OO ,cacheToDisc =True )
            from resources .lib .modules import views 
            views .setView (OO00O00OO0OO0O00O ,{})
        except :
            log_utils .error ()
            return 
    def accountCheck (OO00O00OO0OOOO000 ):
        if not traktCredentials and not imdbCredentials :
            control .hide ()
            control .notification (message =32042 ,icon ='WARNING')
            sysexit ()
    def clearCacheAll (OO0000O000OOO0O0O ):
        control .hide ()
        if not control .yesnoDialog (control .lang (32077 ),'',''):return 
        try :
            def O0O0OOO0OOO0O000O ():
                try :
                    from resources .lib .database import cache ,providerscache ,metacache 
                    providerscache .cache_clear_providers ()
                    metacache .cache_clear_meta ()
                    cache .cache_clear ()
                    cache .cache_clear_search ()
                    return True 
                except :
                    log_utils .error ()
            if O0O0OOO0OOO0O000O ():
                control .notification (message =32089 )
            else :control .notification (message =33586 )
        except :
            log_utils .error ()
    def clearCacheProviders (OOO00000OOO000O0O ):
        control .hide ()
        if not control .yesnoDialog (control .lang (32056 ),'',''):return 
        try :
            from resources .lib .database import providerscache 
            if providerscache .cache_clear_providers ():control .notification (message =32090 )
            else :control .notification (message =33586 )
        except :
            log_utils .error ()
    def clearCacheMeta (O0O000OO00OO0O000 ):
        control .hide ()
        if not control .yesnoDialog (control .lang (32076 ),'',''):return 
        try :
            from resources .lib .database import metacache 
            if metacache .cache_clear_meta ():control .notification (message =32091 )
            else :control .notification (message =33586 )
        except :
            log_utils .error ()
    def clearCache (O0OOO000O0OO00O00 ):
        control .hide ()
        if not control .yesnoDialog (control .lang (32056 ),'',''):return 
        try :
            from resources .lib .database import cache 
            if cache .cache_clear ():control .notification (message =32092 )
            else :control .notification (message =33586 )
        except :
            log_utils .error ()
    def clearCacheSearch (O00OO00O000O000OO ):
        control .hide ()
        if not control .yesnoDialog (control .lang (32056 ),'',''):return 
        try :
            from resources .lib .database import cache 
            if cache .cache_clear_search ():control .notification (message =32093 )
            else :control .notification (message =33586 )
        except :
            log_utils .error ()
    def clearCacheSearchPhrase (OOO000OO0O0O0O000 ,O0000000O0000O00O ,O0O0OOOOO0OOO0OO0 ):
        control .hide ()
        if not control .yesnoDialog (control .lang (32056 ),'',''):return 
        try :
            from resources .lib .database import cache 
            if cache .cache_clear_SearchPhrase (O0000000O0000O00O ,O0O0OOOOO0OOO0OO0 ):control .notification (message =32094 )
            else :control .notification (message =33586 )
        except :
            log_utils .error ()
    def clearBookmarks (O00OOO0OO0O0000OO ):
        control .hide ()
        if not control .yesnoDialog (control .lang (32056 ),'',''):return 
        try :
            from resources .lib .database import cache 
            if cache .cache_clear_bookmarks ():control .notification (message =32100 )
            else :control .notification (message =33586 )
        except :
            log_utils .error ()
    def clearBookmark (OOOO0OOO00OOOO0OO ,O00OOOO00OO00000O ,O00O0OO000O00OOO0 ):
        control .hide ()
        if not control .yesnoDialog (control .lang (32056 ),'',''):return 
        try :
            from resources .lib .database import cache 
            if cache .cache_clear_bookmark (O00OOOO00OO00000O ,O00O0OO000O00OOO0 ):control .notification (title =O00OOOO00OO00000O ,message =32102 )
            else :control .notification (message =33586 )
        except :
            log_utils .error ()
    def addDirectoryItem (OOOOOO0O0O0O0O0O0 ,O00O00000OO0OO0O0 ,O0O0000O0OOO000O0 ,O0O0O0OO00O00OO0O ,O00OOO0OOO00OOO00 ,O00000O0O00O0OO0O =None ,O000000OO00OOOOO0 =False ,OO0OO0OOOO0OOOOO0 =True ,OO0OOO000OOOOOO0O =True ,O00OO0O00OO0OO0OO =False ,O0OO0OOO00O00O0O0 =False ,O00O00OO000OOO000 =''):
        OOO0OO00OOO0O0O0O =argv [0 ];O00O0OOO00O000OOO =int (argv [1 ])
        if isinstance (O00O00000OO0OO0O0 ,int ):O00O00000OO0OO0O0 =control .lang (O00O00000OO0OO0O0 )
        OO00O00000OOOOOOO ='%s?action=%s'%(OOO0OO00OOO0O0O0O ,O0O0000O0OOO000O0 )if OO0OO0OOOO0OOOOO0 else O0O0000O0OOO000O0 
        O0O0O0OO00O00OO0O =control .joinPath (artPath ,O0O0O0OO00O00OO0O )if artPath else O00OOO0OOO00OOO00 
        if not O00OOO0OOO00OOO00 .startswith ('Default'):O00OOO0OOO00OOO00 =control .joinPath (artPath ,O00OOO0OOO00OOO00 )
        OOO000O00000OO00O =[]
        OOO0O0OO0O0O0OOOO =control .lang (32065 )
        if O000000OO00OOOOO0 :OOO000O00000OO00O .append ((OOO0O0OO0O0O0OOOO ,'RunPlugin(%s?action=playlist_QueueItem)'%OOO0OO00OOO0O0O0O ))
        if O00000O0O00O0OO0O :OOO000O00000OO00O .append ((control .lang (O00000O0O00O0OO0O [0 ]),'RunPlugin(%s?action=%s)'%(OOO0OO00OOO0O0O0O ,O00000O0O00O0OO0O [1 ])))
        if O0OO0OOO00O00O0O0 :OOO000O00000OO00O .append (('Clear Search Phrase','RunPlugin(%s?action=cache_clearSearchPhrase&source=%s&name=%s)'%(OOO0OO00OOO0O0O0O ,O00O00OO000OOO000 ,quote_plus (O00O00000OO0OO0O0 ))))
        OOO000O00000OO00O .append (('[COLOR deepskyblue]LE Settings[/COLOR]','RunPlugin(%s?action=tools_openSettings)'%OOO0OO00OOO0O0O0O ))
        try :OO000O0O00OOO0000 =control .item (label =O00O00000OO0OO0O0 ,offscreen =True )
        except :OO000O0O00OOO0000 =control .item (label =O00O00000OO0OO0O0 )
        OO000O0O00OOO0000 .addContextMenuItems (OOO000O00000OO00O )
        if O00OO0O00OO0OO0OO :OO000O0O00OOO0000 .setProperty ('IsPlayable','true')
        else :OO000O0O00OOO0000 .setProperty ('IsPlayable','false')
        OO000O0O00OOO0000 .setArt ({'icon':O00OOO0OOO00OOO00 ,'poster':O0O0O0OO00O00OO0O ,'thumb':O0O0O0OO00O00OO0O ,'fanart':control .addonFanart (),'banner':O0O0O0OO00O00OO0O })
        control .addItem (handle =O00O0OOO00O000OOO ,url =OO00O00000OOOOOOO ,listitem =OO000O0O00OOO0000 ,isFolder =OO0OOO000OOOOOO0O )
    def endDirectory (O0OO0O0O0OO0OO000 ):
        OOOO0OO0OOO0O00O0 =int (argv [1 ])
        control .content (OOOO0OO0OOO0O00O0 ,'addons')
        control .directory (OOOO0OO0OOO0O00O0 ,cacheToDisc =True )