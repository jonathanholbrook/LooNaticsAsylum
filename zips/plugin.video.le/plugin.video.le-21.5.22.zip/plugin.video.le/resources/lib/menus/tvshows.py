from datetime import datetime ,timedelta 
from json import dumps as jsdumps ,loads as jsloads 
import re 
from sys import argv 
try :
    from urllib import quote_plus ,urlencode 
    from urlparse import parse_qsl ,urlparse ,urlsplit 
except ImportError :
    from urllib .parse import quote_plus ,urlencode ,parse_qsl ,urlparse ,urlsplit 
from resources .lib .database import cache ,metacache 
from resources .lib .indexers import tmdb as tmdb_indexer ,fanarttv 
from resources .lib .modules import cleangenre 
from resources .lib .modules import client 
from resources .lib .modules import control 
from resources .lib .modules import log_utils 
from resources .lib .modules import playcount 
from resources .lib .modules import py_tools 
from resources .lib .modules import trakt 
from resources .lib .modules import views 
from resources .lib .modules import workers 
class TVshows :
    def __init__ (OOO000OO00O00000O ,O00000O0OOO0OOO00 ='show',OO00O0000OO0OO0OO =True ):
        OOO000OO00O00000O .count =control .setting ('page.item.limit')
        OOO000OO00O00000O .list =[]
        OOO000OO00O00000O .meta =[]
        OOO000OO00O00000O .threads =[]
        OOO000OO00O00000O .type =O00000O0OOO0OOO00 
        OOO000OO00O00000O .lang =control .apiLanguage ()['tmdb']
        OOO000OO00O00000O .notifications =OO00O0000OO0OO0OO 
        OOO000OO00O00000O .disable_fanarttv =control .setting ('disable.fanarttv')=='true'
        OOO000OO00O00000O .date_time =datetime .now ()
        OOO000OO00O00000O .today_date =(OOO000OO00O00000O .date_time ).strftime ('%Y-%m-%d')
        OOO000OO00O00000O .tvdb_key =control .setting ('tvdb.api.key')
        OOO000OO00O00000O .imdb_user =control .setting ('imdb.user').replace ('ur','')
        OOO000OO00O00000O .user =str (OOO000OO00O00000O .imdb_user )+str (OOO000OO00O00000O .tvdb_key )
        OOO000OO00O00000O .imdb_link ='https://www.imdb.com'
        OOO000OO00O00000O .persons_link ='https://www.imdb.com/search/name?count=100&name='
        OOO000OO00O00000O .personlist_link ='https://www.imdb.com/search/name?count=100&gender=male,female'
        OOO000OO00O00000O .popular_link ='https://www.imdb.com/search/title?title_type=tv_series,mini_series&num_votes=100,&release_date=,date[0]&sort=moviemeter,asc&count=%s&start=1'%OOO000OO00O00000O .count 
        OOO000OO00O00000O .airing_link ='https://www.imdb.com/search/title?title_type=tv_episode&release_date=date[1],date[0]&sort=moviemeter,asc&count=%s&start=1'%OOO000OO00O00000O .count 
        OOO000OO00O00000O .active_link ='https://www.imdb.com/search/title?title_type=tv_series,mini_series&num_votes=10,&production_status=active&sort=moviemeter,asc&count=%s&start=1'%OOO000OO00O00000O .count 
        OOO000OO00O00000O .premiere_link ='https://www.imdb.com/search/title?title_type=tv_series,mini_series&languages=en&num_votes=10,&release_date=date[60],date[0]&sort=release_date,desc&count=%s&start=1'%OOO000OO00O00000O .count 
        OOO000OO00O00000O .rating_link ='https://www.imdb.com/search/title?title_type=tv_series,mini_series&num_votes=5000,&release_date=,date[0]&sort=user_rating,desc&count=%s&start=1'%OOO000OO00O00000O .count 
        OOO000OO00O00000O .views_link ='https://www.imdb.com/search/title?title_type=tv_series,mini_series&num_votes=100,&release_date=,date[0]&sort=num_votes,desc&count=%s&start=1'%OOO000OO00O00000O .count 
        OOO000OO00O00000O .person_link ='https://www.imdb.com/search/title?title_type=tv_series,mini_series&release_date=,date[0]&role=%s&sort=year,desc&count=%s&start=1'%('%s',OOO000OO00O00000O .count )
        OOO000OO00O00000O .genre_link ='https://www.imdb.com/search/title?title_type=tv_series,mini_series&release_date=,date[0]&genres=%s&sort=moviemeter,asc&count=%s&start=1'%('%s',OOO000OO00O00000O .count )
        OOO000OO00O00000O .keyword_link ='https://www.imdb.com/search/title?title_type=tv_series,mini_series&release_date=,date[0]&keywords=%s&sort=moviemeter,asc&count=%s&start=1'%('%s',OOO000OO00O00000O .count )
        OOO000OO00O00000O .language_link ='https://www.imdb.com/search/title?title_type=tv_series,mini_series&num_votes=100,&production_status=released&primary_language=%s&sort=moviemeter,asc&count=%s&start=1'%('%s',OOO000OO00O00000O .count )
        OOO000OO00O00000O .certification_link ='https://www.imdb.com/search/title?title_type=tv_series,mini_series&release_date=,date[0]&certificates=%s&sort=moviemeter,asc&count=%s&start=1'%('%s',OOO000OO00O00000O .count )
        OOO000OO00O00000O .imdbwatchlist_link ='https://www.imdb.com/user/ur%s/watchlist?sort=date_added,desc'%OOO000OO00O00000O .imdb_user 
        OOO000OO00O00000O .imdbwatchlist2_link ='https://www.imdb.com/list/%s/?view=detail&sort=%s&title_type=tvSeries,tvMiniSeries&start=1'%('%s',OOO000OO00O00000O .imdb_sort (type ='shows.watchlist'))
        OOO000OO00O00000O .imdblists_link ='https://www.imdb.com/user/ur%s/lists?tab=all&sort=mdfd&order=desc&filter=titles'%OOO000OO00O00000O .imdb_user 
        OOO000OO00O00000O .imdblist_link ='https://www.imdb.com/list/%s/?view=detail&sort=%s&title_type=tvSeries,tvMiniSeries&start=1'%('%s',OOO000OO00O00000O .imdb_sort ())
        OOO000OO00O00000O .imdbratings_link ='https://www.imdb.com/user/ur%s/ratings?sort=your_rating,desc&mode=detail&start=1'%OOO000OO00O00000O .imdb_user 
        OOO000OO00O00000O .anime_link ='https://www.imdb.com/search/keyword?keywords=anime&title_type=tvSeries,miniSeries&sort=moviemeter,asc&count=%s&start=1'%OOO000OO00O00000O .count 
        OOO000OO00O00000O .trakt_user =control .setting ('trakt.user').strip ()
        OOO000OO00O00000O .traktCredentials =trakt .getTraktCredentialsInfo ()
        OOO000OO00O00000O .trakt_link ='https://api.trakt.tv'
        OOO000OO00O00000O .search_link ='https://api.trakt.tv/search/show?limit=%s&page=1&query='%OOO000OO00O00000O .count 
        OOO000OO00O00000O .traktlist_link ='https://api.trakt.tv/users/%s/lists/%s/items/shows'
        OOO000OO00O00000O .traktlikedlists_link ='https://api.trakt.tv/users/likes/lists?limit=1000000'
        OOO000OO00O00000O .traktlists_link ='https://api.trakt.tv/users/me/lists'
        OOO000OO00O00000O .traktwatchlist_link ='https://api.trakt.tv/users/me/watchlist/shows'
        OOO000OO00O00000O .traktcollection_link ='https://api.trakt.tv/users/me/collection/shows'
        OOO000OO00O00000O .trakttrending_link ='https://api.trakt.tv/shows/trending?page=1&limit=%s'%OOO000OO00O00000O .count 
        OOO000OO00O00000O .traktpopular_link ='https://api.trakt.tv/shows/popular?page=1&limit=%s'%OOO000OO00O00000O .count 
        OOO000OO00O00000O .traktrecommendations_link ='https://api.trakt.tv/recommendations/shows?limit=40'
        OOO000OO00O00000O .tvmaze_link ='https://www.tvmaze.com'
        OOO000OO00O00000O .tmdb_key =control .setting ('tmdb.api.key')
        if OOO000OO00O00000O .tmdb_key ==''or OOO000OO00O00000O .tmdb_key is None :
            OOO000OO00O00000O .tmdb_key ='3320855e65a9758297fec4f7c9717698'
        OOO000OO00O00000O .tmdb_session_id =control .setting ('tmdb.session_id')
        OOO000OO00O00000O .tmdb_link ='https://api.themoviedb.org'
        OOO000OO00O00000O .tmdb_userlists_link ='https://api.themoviedb.org/3/account/{account_id}/lists?api_key=%s&language=en-US&session_id=%s&page=1'%('%s',OOO000OO00O00000O .tmdb_session_id )
        OOO000OO00O00000O .tmdb_watchlist_link ='https://api.themoviedb.org/3/account/{account_id}/watchlist/tv?api_key=%s&session_id=%s&sort_by=created_at.asc&page=1'%('%s',OOO000OO00O00000O .tmdb_session_id )
        OOO000OO00O00000O .tmdb_favorites_link ='https://api.themoviedb.org/3/account/{account_id}/favorite/tv?api_key=%s&session_id=%s&sort_by=created_at.asc&page=1'%('%s',OOO000OO00O00000O .tmdb_session_id )
        OOO000OO00O00000O .tmdb_popular_link ='https://api.themoviedb.org/3/tv/popular?api_key=%s&language=en-US&region=US&page=1'
        OOO000OO00O00000O .tmdb_toprated_link ='https://api.themoviedb.org/3/tv/top_rated?api_key=%s&language=en-US&region=US&page=1'
        OOO000OO00O00000O .tmdb_ontheair_link ='https://api.themoviedb.org/3/tv/on_the_air?api_key=%s&language=en-US&region=US&page=1'
        OOO000OO00O00000O .tmdb_airingtoday_link ='https://api.themoviedb.org/3/tv/airing_today?api_key=%s&language=en-US&region=US&page=1'
        OOO000OO00O00000O .tmdb_networks_link ='https://api.themoviedb.org/3/discover/tv?api_key=%s&sort_by=popularity.desc&with_networks=%s&page=1'
        OOO000OO00O00000O .played1_link ='https://api.trakt.tv/shows/played/weekly?page=1&limit=%s'%OOO000OO00O00000O .count 
        OOO000OO00O00000O .played2_link ='https://api.trakt.tv/shows/played/monthly??page=1&limit=%s'%OOO000OO00O00000O .count 
        OOO000OO00O00000O .played3_link ='https://api.trakt.tv/shows/played/yearly?page=1&limit=%s'%OOO000OO00O00000O .count 
        OOO000OO00O00000O .played4_link ='https://api.trakt.tv/shows/played/all?page=1&limit=%s'%OOO000OO00O00000O .count 
        OOO000OO00O00000O .collected1_link ='https://api.trakt.tv/shows/collected/weekly?page=1&limit=%s'%OOO000OO00O00000O .count 
        OOO000OO00O00000O .collected2_link ='https://api.trakt.tv/shows/collected/monthly?page=1&limit=%s'%OOO000OO00O00000O .count 
        OOO000OO00O00000O .collected3_link ='https://api.trakt.tv/shows/collected/yearly?page=1&limit=%s'%OOO000OO00O00000O .count 
        OOO000OO00O00000O .collected4_link ='https://api.trakt.tv/shows/collected/all?page=1&limit=%s'%OOO000OO00O00000O .count 
        OOO000OO00O00000O .watched1_link ='https://api.trakt.tv/shows/watched/weekly?page=1&limit=%s'%OOO000OO00O00000O .count 
        OOO000OO00O00000O .watched2_link ='https://api.trakt.tv/shows/watched/monthly?page=1&limit=%s'%OOO000OO00O00000O .count 
        OOO000OO00O00000O .watched3_link ='https://api.trakt.tv/shows/watched/yearly?page=1&limit=%s'%OOO000OO00O00000O .count 
        OOO000OO00O00000O .watched4_link ='https://api.trakt.tv/shows/watched/all?page=1&limit=%s'%OOO000OO00O00000O .count 
        OOO000OO00O00000O .retrocartoons_link ='https://www.imdb.com/list/ls052624514/?view=detail&sort=alpha,asc&title_type=tvSeries,tvMiniSeries&count=%s&start=1'%OOO000OO00O00000O .count 
        OOO000OO00O00000O .adultcartoons_link ='https://www.imdb.com/list/ls033696642/?view=detail&sort=alpha,asc&title_type=tvSeries,tvMiniSeries&count=%s&start=1'%OOO000OO00O00000O .count 
        OOO000OO00O00000O .shstonertvshows_link ='https://www.imdb.com/list/ls093291259/?view=detail&sort=alpha,asc&title_type=tvSeries,tvMiniSeries&count=%s&start=1'%OOO000OO00O00000O .count 
        OOO000OO00O00000O .slbreak_link ='https://www.imdb.com/list/ls500365647/?view=detail&sort=alpha,asc&title_type=tvSeries,tvMiniSeries&count=%s&start=1'%OOO000OO00O00000O .count 
        OOO000OO00O00000O .cabletv_link ='https://www.imdb.com/list/ls066306505/?view=detail&sort=alpha,asc&title_type=tvSeries,tvMiniSeries&count=%s&start=1'%OOO000OO00O00000O .count 
        OOO000OO00O00000O .usprime_link ='https://www.imdb.com/search/title/?title_type=tv_series,tv_miniseries&countries=us&languages=en&plot=horror&count=%s&start=1'%OOO000OO00O00000O .count 
        OOO000OO00O00000O .tmdbtvlist1_link =control .setting ('tmdb.tvlist_id1')
        OOO000OO00O00000O .tmdbtvlist2_link =control .setting ('tmdb.tvlist_id2')
        OOO000OO00O00000O .tmdbtvlist3_link =control .setting ('tmdb.tvlist_id3')
        OOO000OO00O00000O .tmdbtvlist4_link =control .setting ('tmdb.tvlist_id4')
        OOO000OO00O00000O .tmdbtvlist5_link =control .setting ('tmdb.tvlist_id5')
        OOO000OO00O00000O .tmdbtvlist6_link =control .setting ('tmdb.tvlist_id6')
        OOO000OO00O00000O .tmdbtvlist7_link =control .setting ('tmdb.tvlist_id7')
        OOO000OO00O00000O .tmdbtvlist8_link =control .setting ('tmdb.tvlist_id8')
        OOO000OO00O00000O .tmdbtvlist9_link =control .setting ('tmdb.tvlist_id9')
        OOO000OO00O00000O .tmdbtvlist10_link =control .setting ('tmdb.tvlist_id10')
        OOO000OO00O00000O .mycustomlist1_link ='https://api.themoviedb.org/3/list/%s?api_key=%s'%(OOO000OO00O00000O .tmdbtvlist1_link ,OOO000OO00O00000O .tmdb_key )
        OOO000OO00O00000O .mycustomlist2_link ='https://api.themoviedb.org/3/list/%s?api_key=%s'%(OOO000OO00O00000O .tmdbtvlist2_link ,OOO000OO00O00000O .tmdb_key )
        OOO000OO00O00000O .mycustomlist3_link ='https://api.themoviedb.org/3/list/%s?api_key=%s'%(OOO000OO00O00000O .tmdbtvlist3_link ,OOO000OO00O00000O .tmdb_key )
        OOO000OO00O00000O .mycustomlist4_link ='https://api.themoviedb.org/3/list/%s?api_key=%s'%(OOO000OO00O00000O .tmdbtvlist4_link ,OOO000OO00O00000O .tmdb_key )
        OOO000OO00O00000O .mycustomlist5_link ='https://api.themoviedb.org/3/list/%s?api_key=%s'%(OOO000OO00O00000O .tmdbtvlist5_link ,OOO000OO00O00000O .tmdb_key )
        OOO000OO00O00000O .mycustomlist6_link ='https://api.themoviedb.org/3/list/%s?api_key=%s'%(OOO000OO00O00000O .tmdbtvlist6_link ,OOO000OO00O00000O .tmdb_key )
        OOO000OO00O00000O .mycustomlist7_link ='https://api.themoviedb.org/3/list/%s?api_key=%s'%(OOO000OO00O00000O .tmdbtvlist7_link ,OOO000OO00O00000O .tmdb_key )
        OOO000OO00O00000O .mycustomlist8_link ='https://api.themoviedb.org/3/list/%s?api_key=%s'%(OOO000OO00O00000O .tmdbtvlist8_link ,OOO000OO00O00000O .tmdb_key )
        OOO000OO00O00000O .mycustomlist9_link ='https://api.themoviedb.org/3/list/%s?api_key=%s'%(OOO000OO00O00000O .tmdbtvlist9_link ,OOO000OO00O00000O .tmdb_key )
        OOO000OO00O00000O .mycustomlist10_link ='https://api.themoviedb.org/3/list/%s?api_key=%s'%(OOO000OO00O00000O .tmdbtvlist10_link ,OOO000OO00O00000O .tmdb_key )
        OOO000OO00O00000O .tmdbmytvlist1_link =control .setting ('tmdb.mytvlist_id1')
        OOO000OO00O00000O .tmdbmytvlist2_link =control .setting ('tmdb.mytvlist_id2')
        OOO000OO00O00000O .tmdbmytvlist3_link =control .setting ('tmdb.mytvlist_id3')
        OOO000OO00O00000O .tmdbmytvlist4_link =control .setting ('tmdb.mytvlist_id4')
        OOO000OO00O00000O .tmdbmytvlist5_link =control .setting ('tmdb.mytvlist_id5')
        OOO000OO00O00000O .tmdbmytvlist6_link =control .setting ('tmdb.mytvlist_id6')
        OOO000OO00O00000O .tmdbmytvlist7_link =control .setting ('tmdb.mytvlist_id7')
        OOO000OO00O00000O .tmdbmytvlist8_link =control .setting ('tmdb.mytvlist_id8')
        OOO000OO00O00000O .tmdbmytvlist9_link =control .setting ('tmdb.mytvlist_id9')
        OOO000OO00O00000O .tmdbmytvlist10_link =control .setting ('tmdb.mytvlist_id10')
        OOO000OO00O00000O .mycustomtvlist1_link ='https://api.themoviedb.org/3/list/%s?api_key=%s'%(OOO000OO00O00000O .tmdbmytvlist1_link ,OOO000OO00O00000O .tmdb_key )
        OOO000OO00O00000O .mycustomtvlist2_link ='https://api.themoviedb.org/3/list/%s?api_key=%s'%(OOO000OO00O00000O .tmdbmytvlist2_link ,OOO000OO00O00000O .tmdb_key )
        OOO000OO00O00000O .mycustomtvlist3_link ='https://api.themoviedb.org/3/list/%s?api_key=%s'%(OOO000OO00O00000O .tmdbmytvlist3_link ,OOO000OO00O00000O .tmdb_key )
        OOO000OO00O00000O .mycustomtvlist4_link ='https://api.themoviedb.org/3/list/%s?api_key=%s'%(OOO000OO00O00000O .tmdbmytvlist4_link ,OOO000OO00O00000O .tmdb_key )
        OOO000OO00O00000O .mycustomtvlist5_link ='https://api.themoviedb.org/3/list/%s?api_key=%s'%(OOO000OO00O00000O .tmdbmytvlist5_link ,OOO000OO00O00000O .tmdb_key )
        OOO000OO00O00000O .mycustomtvlist6_link ='https://api.themoviedb.org/3/list/%s?api_key=%s'%(OOO000OO00O00000O .tmdbmytvlist6_link ,OOO000OO00O00000O .tmdb_key )
        OOO000OO00O00000O .mycustomtvlist7_link ='https://api.themoviedb.org/3/list/%s?api_key=%s'%(OOO000OO00O00000O .tmdbmytvlist7_link ,OOO000OO00O00000O .tmdb_key )
        OOO000OO00O00000O .mycustomtvlist8_link ='https://api.themoviedb.org/3/list/%s?api_key=%s'%(OOO000OO00O00000O .tmdbmytvlist8_link ,OOO000OO00O00000O .tmdb_key )
        OOO000OO00O00000O .mycustomtvlist9_link ='https://api.themoviedb.org/3/list/%s?api_key=%s'%(OOO000OO00O00000O .tmdbmytvlist9_link ,OOO000OO00O00000O .tmdb_key )
        OOO000OO00O00000O .mycustomtvlist10_link ='https://api.themoviedb.org/3/list/%s?api_key=%s'%(OOO000OO00O00000O .tmdbmytvlist10_link ,OOO000OO00O00000O .tmdb_key )
    def get (O00OO0O0OO00OOOO0 ,OOOOOOOO0OOOO0OOO ,OOO0O0O00OOO0O000 =True ,O00000OOO0OOO0O00 =True ):
        O00OO0O0OO00OOOO0 .list =[]
        try :
            try :OOOOOOOO0OOOO0OOO =getattr (O00OO0O0OO00OOOO0 ,OOOOOOOO0OOOO0OOO +'_link')
            except :pass 
            try :O0O00000000OOO0OO =urlparse (OOOOOOOO0OOOO0OOO ).netloc .lower ()
            except :pass 
            if O0O00000000OOO0OO in O00OO0O0OO00OOOO0 .trakt_link and '/users/'in OOOOOOOO0OOOO0OOO :
                try :
                    if '/users/me/'not in OOOOOOOO0OOOO0OOO :raise Exception ()
                    if trakt .getActivity ()>cache .timeout (O00OO0O0OO00OOOO0 .trakt_list ,OOOOOOOO0OOOO0OOO ,O00OO0O0OO00OOOO0 .trakt_user ):raise Exception ()
                    O00OO0O0OO00OOOO0 .list =cache .get (O00OO0O0OO00OOOO0 .trakt_list ,720 ,OOOOOOOO0OOOO0OOO ,O00OO0O0OO00OOOO0 .trakt_user )
                except :
                    O00OO0O0OO00OOOO0 .list =cache .get (O00OO0O0OO00OOOO0 .trakt_list ,0 ,OOOOOOOO0OOOO0OOO ,O00OO0O0OO00OOOO0 .trakt_user )
                if OOO0O0O00OOO0O000 :O00OO0O0OO00OOOO0 .worker ()
                if OOOOOOOO0OOOO0OOO ==O00OO0O0OO00OOOO0 .traktwatchlist_link :O00OO0O0OO00OOOO0 .sort (type ='shows.watchlist')
                else :O00OO0O0OO00OOOO0 .sort ()
            elif O0O00000000OOO0OO in O00OO0O0OO00OOOO0 .trakt_link and O00OO0O0OO00OOOO0 .search_link in OOOOOOOO0OOOO0OOO :
                O00OO0O0OO00OOOO0 .list =cache .get (O00OO0O0OO00OOOO0 .trakt_list ,1 ,OOOOOOOO0OOOO0OOO ,O00OO0O0OO00OOOO0 .trakt_user )
                if OOO0O0O00OOO0O000 :O00OO0O0OO00OOOO0 .worker (level =0 )
            elif O0O00000000OOO0OO in O00OO0O0OO00OOOO0 .trakt_link :
                O00OO0O0OO00OOOO0 .list =cache .get (O00OO0O0OO00OOOO0 .trakt_list ,24 ,OOOOOOOO0OOOO0OOO ,O00OO0O0OO00OOOO0 .trakt_user )
                if OOO0O0O00OOO0O000 :O00OO0O0OO00OOOO0 .worker ()
            elif O0O00000000OOO0OO in O00OO0O0OO00OOOO0 .imdb_link and ('/user/'in OOOOOOOO0OOOO0OOO or '/list/'in OOOOOOOO0OOOO0OOO ):
                OOOOOO00OOOOO000O =True if O00OO0O0OO00OOOO0 .imdbratings_link in OOOOOOOO0OOOO0OOO else False 
                O00OO0O0OO00OOOO0 .list =cache .get (O00OO0O0OO00OOOO0 .imdb_list ,0 ,OOOOOOOO0OOOO0OOO ,OOOOOO00OOOOO000O )
                if OOO0O0O00OOO0O000 :O00OO0O0OO00OOOO0 .worker ()
            elif O0O00000000OOO0OO in O00OO0O0OO00OOOO0 .imdb_link :
                O00OO0O0OO00OOOO0 .list =cache .get (O00OO0O0OO00OOOO0 .imdb_list ,96 ,OOOOOOOO0OOOO0OOO )
                if OOO0O0O00OOO0O000 :O00OO0O0OO00OOOO0 .worker ()
            if O00OO0O0OO00OOOO0 .list is None :O00OO0O0OO00OOOO0 .list =[]
            if OOO0O0O00OOO0O000 and O00000OOO0OOO0O00 :O00OO0O0OO00OOOO0 .tvshowDirectory (O00OO0O0OO00OOOO0 .list )
            return O00OO0O0OO00OOOO0 .list 
        except :
            log_utils .error ()
            if not O00OO0O0OO00OOOO0 .list :
                control .hide ()
                if O00OO0O0OO00OOOO0 .notifications :control .notification (title =32002 ,message =33049 )
    def getTMDb (OOOOOO0OO00O000OO ,OO0O00O00O00O0O00 ,O0000000O0O00O00O =True ,O0000OO00OOOOO000 =True ):
        OOOOOO0OO00O000OO .list =[]
        try :
            try :OO0O00O00O00O0O00 =getattr (OOOOOO0OO00O000OO ,OO0O00O00O00O0O00 +'_link')
            except :pass 
            try :O00OO000O0OOO0000 =urlparse (OO0O00O00O00O0O00 ).netloc .lower ()
            except :pass 
            if O00OO000O0OOO0000 in OOOOOO0OO00O000OO .tmdb_link and '/list/'in OO0O00O00O00O0O00 :
                OOOOOO0OO00O000OO .list =cache .get (tmdb_indexer .TVshows ().tmdb_collections_list ,0 ,OO0O00O00O00O0O00 )
            elif O00OO000O0OOO0000 in OOOOOO0OO00O000OO .tmdb_link and not '/list/'in OO0O00O00O00O0O00 :
                OO00OOOOOOO000000 =168 if O0000OO00OOOOO000 else 0 
                OOOOOO0OO00O000OO .list =cache .get (tmdb_indexer .TVshows ().tmdb_list ,OO00OOOOOOO000000 ,OO0O00O00O00O0O00 )
            if OOOOOO0OO00O000OO .list is None :OOOOOO0OO00O000OO .list =[]
            if O0000000O0O00O00O :OOOOOO0OO00O000OO .tvshowDirectory (OOOOOO0OO00O000OO .list )
            return OOOOOO0OO00O000OO .list 
        except :
            log_utils .error ()
            if not OOOOOO0OO00O000OO .list :
                control .hide ()
                if OOOOOO0OO00O000OO .notifications :control .notification (title =32002 ,message =33049 )
    def getTVmaze (OO0000000O00O0O00 ,OOOO00OOO0O000OO0 ,O0000O0OOO0OO0OO0 =True ):
        from resources .lib .indexers import tvmaze 
        OO0000000O00O0O00 .list =[]
        try :
            try :OOOO00OOO0O000OO0 =getattr (OO0000000O00O0O00 ,OOOO00OOO0O000OO0 +'_link')
            except :pass 
            OO0000000O00O0O00 .list =cache .get (tvmaze .tvshows ().tvmaze_list ,168 ,OOOO00OOO0O000OO0 )
            if OO0000000O00O0O00 .list is None :OO0000000O00O0O00 .list =[]
            if O0000O0OOO0OO0OO0 :OO0000000O00O0O00 .tvshowDirectory (OO0000000O00O0O00 .list )
            return OO0000000O00O0O00 .list 
        except :
            log_utils .error ()
            if not OO0000000O00O0O00 .list :
                control .hide ()
                if OO0000000O00O0O00 .notifications :control .notification (title =32002 ,message =33049 )
    def sort (O0OOOO0O00OOOO0OO ,OO0000OOO00O0OO00 ='shows'):
        try :
            if not O0OOOO0O00OOOO0OO .list :return 
            O0O0OOO0000OOOO0O =int (control .setting ('sort.%s.type'%OO0000OOO00O0OO00 ))
            OO00OOOO00O00O000 =int (control .setting ('sort.%s.order'%OO0000OOO00O0OO00 ))==1 
            if O0O0OOO0000OOOO0O ==0 :OO00OOOO00O00O000 =False 
            if O0O0OOO0000OOOO0O >0 :
                if O0O0OOO0000OOOO0O ==1 :
                    try :O0OOOO0O00OOOO0OO .list =sorted (O0OOOO0O00OOOO0OO .list ,key =lambda OOOO0O0000O000OOO :re .sub (r'(^the |^a |^an )','',OOOO0O0000O000OOO ['tvshowtitle'].lower ()),reverse =OO00OOOO00O00O000 )
                    except :O0OOOO0O00OOOO0OO .list =sorted (O0OOOO0O00OOOO0OO .list ,key =lambda O00000OO00O0OO00O :re .sub (r'(^the |^a |^an )','',O00000OO00O0OO00O ['title'].lower ()),reverse =OO00OOOO00O00O000 )
                elif O0O0OOO0000OOOO0O ==2 :O0OOOO0O00OOOO0OO .list =sorted (O0OOOO0O00OOOO0OO .list ,key =lambda OO0OOOOO000OO000O :float (OO0OOOOO000OO000O ['rating']),reverse =OO00OOOO00O00O000 )
                elif O0O0OOO0000OOOO0O ==3 :O0OOOO0O00OOOO0OO .list =sorted (O0OOOO0O00OOOO0OO .list ,key =lambda OO0OOOO00O00O00OO :int (OO0OOOO00O00O00OO ['votes'].replace (',','')),reverse =OO00OOOO00O00O000 )
                elif O0O0OOO0000OOOO0O ==4 :
                    for O0O0O00OOO000OO0O in range (len (O0OOOO0O00OOOO0OO .list )):
                        if 'premiered'not in O0OOOO0O00OOOO0OO .list [O0O0O00OOO000OO0O ]:O0OOOO0O00OOOO0OO .list [O0O0O00OOO000OO0O ]['premiered']=''
                    O0OOOO0O00OOOO0OO .list =sorted (O0OOOO0O00OOOO0OO .list ,key =lambda O0OO00OO000O0OO0O :O0OO00OO000O0OO0O ['premiered'],reverse =OO00OOOO00O00O000 )
                elif O0O0OOO0000OOOO0O ==5 :
                    for O0O0O00OOO000OO0O in range (len (O0OOOO0O00OOOO0OO .list )):
                        if 'added'not in O0OOOO0O00OOOO0OO .list [O0O0O00OOO000OO0O ]:O0OOOO0O00OOOO0OO .list [O0O0O00OOO000OO0O ]['added']=''
                    O0OOOO0O00OOOO0OO .list =sorted (O0OOOO0O00OOOO0OO .list ,key =lambda OOO0OO0O00O00O000 :OOO0OO0O00O00O000 ['added'],reverse =OO00OOOO00O00O000 )
                elif O0O0OOO0000OOOO0O ==6 :
                    for O0O0O00OOO000OO0O in range (len (O0OOOO0O00OOOO0OO .list )):
                        if 'lastplayed'not in O0OOOO0O00OOOO0OO .list [O0O0O00OOO000OO0O ]:O0OOOO0O00OOOO0OO .list [O0O0O00OOO000OO0O ]['lastplayed']=''
                    O0OOOO0O00OOOO0OO .list =sorted (O0OOOO0O00OOOO0OO .list ,key =lambda O0O00OO0O0O0000O0 :O0O00OO0O0O0000O0 ['lastplayed'],reverse =OO00OOOO00O00O000 )
            elif OO00OOOO00O00O000 :
                O0OOOO0O00OOOO0OO .list =list (reversed (O0OOOO0O00OOOO0OO .list ))
        except :
            log_utils .error ()
    def imdb_sort (O00O00OOOOOOO000O ,O00OO0O0O00OOOOOO ='shows'):
        OOOO00OOO0OO00O0O =int (control .setting ('sort.%s.type'%O00OO0O0O00OOOOOO ))
        O00OO0OO0O000O0OO ='list_order'
        if OOOO00OOO0OO00O0O ==1 :O00OO0OO0O000O0OO ='alpha'
        if OOOO00OOO0OO00O0O in [2 ,3 ]:O00OO0OO0O000O0OO ='user_rating'
        if OOOO00OOO0OO00O0O ==4 :O00OO0OO0O000O0OO ='release_date'
        if OOOO00OOO0OO00O0O in [5 ,6 ]:O00OO0OO0O000O0OO ='date_added'
        OO00O0OOO000OO0O0 =',asc'if int (control .setting ('sort.%s.order'%O00OO0O0O00OOOOOO ))==0 else ',desc'
        OOOOO0OOO0OO0O0OO =O00OO0OO0O000O0OO +OO00O0OOO000OO0O0 
        return OOOOO0OOO0OO0O0OO 
    def search (OO0000O0O0O000OO0 ):
        from resources .lib .menus import navigator 
        navigator .Navigator ().addDirectoryItem (32603 ,'tvSearchnew','search.png','DefaultAddonsSearch.png')
        try :from sqlite3 import dbapi2 as database 
        except ImportError :from pysqlite2 import dbapi2 as database 
        try :
            if not control .existsPath (control .dataPath ):control .makeFile (control .dataPath )
            OO0O0O00O0000OOO0 =database .connect (control .searchFile )
            OOO00000O0O0OOO0O =OO0O0O00O0000OOO0 .cursor ()
            OOO00000O0O0OOO0O .executescript ('''CREATE TABLE IF NOT EXISTS tvshow (ID Integer PRIMARY KEY AUTOINCREMENT, term);''')
            OOO00000O0O0OOO0O .execute ('''SELECT * FROM tvshow ORDER BY ID DESC''')
            OOO00000O0O0OOO0O .connection .commit ()
            OO00O0O00O0OO0000 =[]
            OOO00O0O0OOO0OO0O =False 
            for (OO0O000OO0O000OOO ,OO000O00O0OOO0O0O )in OOO00000O0O0OOO0O .fetchall ():
                OO000O00O0OOO0O0O =py_tools .ensure_str (OO000O00O0OOO0O0O )
                if OO000O00O0OOO0O0O not in str (OO00O0O00O0OO0000 ):
                    OOO00O0O0OOO0OO0O =True 
                    navigator .Navigator ().addDirectoryItem (OO000O00O0OOO0O0O ,'tvSearchterm&name=%s'%OO000O00O0OOO0O0O ,'search.png','DefaultAddonsSearch.png',isSearch =True ,table ='tvshow')
                    OO00O0O00O0OO0000 +=[(OO000O00O0OOO0O0O )]
        except :
            log_utils .error ()
        finally :
            OOO00000O0O0OOO0O .close ();OO0O0O00O0000OOO0 .close ()
        if OOO00O0O0OOO0OO0O :
            navigator .Navigator ().addDirectoryItem (32605 ,'cache_clearSearch','tools.png','DefaultAddonService.png',isFolder =False )
        navigator .Navigator ().endDirectory ()
    def search_new (O0OO0000OOO0O0O0O ):
        OO00OOOO000OOOO0O =control .lang (32010 )
        OO0O0OOO0OO00000O =control .keyboard ('',OO00OOOO000OOOO0O )
        OO0O0OOO0OO00000O .doModal ()
        OOO0O0OOO0OOOO0OO =OO0O0OOO0OO00000O .getText ()if OO0O0OOO0OO00000O .isConfirmed ()else None 
        if not OOO0O0OOO0OOOO0OO :return 
        try :from sqlite3 import dbapi2 as database 
        except ImportError :from pysqlite2 import dbapi2 as database 
        try :
            OO0O00OOO0O0O0O0O =database .connect (control .searchFile )
            O00O0000OOOO0OOOO =OO0O00OOO0O0O0O0O .cursor ()
            O00O0000OOOO0OOOO .execute ('''INSERT INTO tvshow VALUES (?,?)''',(None ,OOO0O0OOO0OOOO0OO ))
            O00O0000OOOO0OOOO .connection .commit ()
        except :
            log_utils .error ()
        finally :
            O00O0000OOOO0OOOO .close ();OO0O00OOO0O0O0O0O .close ()
        O0O0000OOO0OO00OO =O0OO0000OOO0O0O0O .search_link +quote_plus (OOO0O0OOO0OOOO0OO )
        if control .getKodiVersion ()>=18 :
            O0OO0000OOO0O0O0O .get (O0O0000OOO0OO00OO )
        else :
            O0O0000OOO0OO00OO ='%s?action=tvshowPage&url=%s'%(argv [0 ],quote_plus (O0O0000OOO0OO00OO ))
            control .execute ('Container.Update(%s)'%O0O0000OOO0OO00OO )
    def search_term (O0O0OOOO0O0OOO00O ,O0OOOOOO0O0OOOO0O ):
        O0OO00OOOOO0O00O0 =O0O0OOOO0O0OOO00O .search_link +quote_plus (O0OOOOOO0O0OOOO0O )
        O0O0OOOO0O0OOO00O .get (O0OO00OOOOO0O00O0 )
    def person (O0O0O00OO00OOOOO0 ):
        OOO00OOO0OOO0O0OO =control .lang (32010 )
        OO00OO0O000OOO0OO =control .keyboard ('',OOO00OOO0OOO0O0OO )
        OO00OO0O000OOO0OO .doModal ()
        O0000O00000O0OOOO =OO00OO0O000OOO0OO .getText ().strip ()if OO00OO0O000OOO0OO .isConfirmed ()else None 
        if not O0000O00000O0OOOO :return 
        O00O0O0O0OOO000O0 =O0O0O00OO00OOOOO0 .persons_link +quote_plus (O0000O00000O0OOOO )
        O0O0O00OO00OOOOO0 .persons (O00O0O0O0OOO000O0 )
    def genres (O000OOO0OOO00000O ):
        OO0OO00O0O00OO0OO =[('Action','action',True ),('Adventure','adventure',True ),('Animation','animation',True ),('Anime','anime',False ),('Biography','biography',True ),('Comedy','comedy',True ),('Crime','crime',True ),('Drama','drama',True ),('Family','family',True ),('Fantasy','fantasy',True ),('Game-Show','game_show',True ),('History','history',True ),('Horror','horror',True ),('Music ','music',True ),('Musical','musical',True ),('Mystery','mystery',True ),('News','news',True ),('Reality-TV','reality_tv',True ),('Romance','romance',True ),('Science Fiction','sci_fi',True ),('Sport','sport',True ),('Talk-Show','talk_show',True ),('Thriller','thriller',True ),('War','war',True ),('Western','western',True )]
        for O0OOO00O000000OOO in OO0OO00O0O00OO0OO :
            O000OOO0OOO00000O .list .append ({'name':cleangenre .lang (O0OOO00O000000OOO [0 ],O000OOO0OOO00000O .lang ),'url':O000OOO0OOO00000O .genre_link %O0OOO00O000000OOO [1 ]if O0OOO00O000000OOO [2 ]else O000OOO0OOO00000O .keyword_link %O0OOO00O000000OOO [1 ],'image':'genres.png','icon':'DefaultGenre.png','action':'tvshows'})
        O000OOO0OOO00000O .addDirectory (O000OOO0OOO00000O .list )
        return O000OOO0OOO00000O .list 
    def networks (O0OO0O0OOO000OO0O ):
        O000OOOOO000O0O00 =tmdb_indexer .TVshows ().get_networks ()
        for OO000O0O0O00OO0OO in O000OOOOO000O0O00 :
            O0OO0O0OOO000OO0O .list .append ({'name':OO000O0O0O00OO0OO [0 ],'url':O0OO0O0OOO000OO0O .tmdb_networks_link %('%s',OO000O0O0O00OO0OO [1 ]),'image':OO000O0O0O00OO0OO [2 ],'icon':'DefaultNetwork.png','action':'tmdbTvshows'})
        O0OO0O0OOO000OO0O .addDirectory (O0OO0O0OOO000OO0O .list )
        return O0OO0O0OOO000OO0O .list 
    def originals (OOO0OOOOO0OO00O0O ):
        O0OO00OOO00OOOOOO =tmdb_indexer .TVshows ().get_originals ()
        for O0OO0OO0O00O00000 in O0OO00OOO00OOOOOO :
            OOO0OOOOO0OO00O0O .list .append ({'name':O0OO0OO0O00O00000 [0 ],'url':OOO0OOOOO0OO00O0O .tmdb_networks_link %('%s',O0OO0OO0O00O00000 [1 ]),'image':O0OO0OO0O00O00000 [2 ],'icon':'DefaultNetwork.png','action':'tmdbTvshows'})
        OOO0OOOOO0OO00O0O .addDirectory (OOO0OOOOO0OO00O0O .list )
        return OOO0OOOOO0OO00O0O .list 
    def languages (O00OO0000OO0OO000 ):
        OO0O0O000OOO00OO0 =[('Arabic','ar'),('Bosnian','bs'),('Bulgarian','bg'),('Chinese','zh'),('Croatian','hr'),('Dutch','nl'),('English','en'),('Finnish','fi'),('French','fr'),('German','de'),('Greek','el'),('Hebrew','he'),('Hindi ','hi'),('Hungarian','hu'),('Icelandic','is'),('Italian','it'),('Japanese','ja'),('Korean','ko'),('Norwegian','no'),('Persian','fa'),('Polish','pl'),('Portuguese','pt'),('Punjabi','pa'),('Romanian','ro'),('Russian','ru'),('Serbian','sr'),('Spanish','es'),('Swedish','sv'),('Turkish','tr'),('Ukrainian','uk')]
        for OO000O00O0O0OOOO0 in OO0O0O000OOO00OO0 :
            O00OO0000OO0OO000 .list .append ({'name':str (OO000O00O0O0OOOO0 [0 ]),'url':O00OO0000OO0OO000 .language_link %OO000O00O0O0OOOO0 [1 ],'image':'languages.png','icon':'DefaultAddonLanguage.png','action':'tvshows'})
        O00OO0000OO0OO000 .addDirectory (O00OO0000OO0OO000 .list )
        return O00OO0000OO0OO000 .list 
    def certifications (OOO000000O0O0O0OO ):
        O0O000O00O0000O00 =[('Child Audience (TV-Y)','TV-Y'),('Young Audience (TV-Y7)','TV-Y7'),('General Audience (TV-G)','TV-G'),('Parental Guidance (TV-PG)','TV-PG'),('Youth Audience (TV-14)','TV-13','TV-14'),('Mature Audience (TV-MA)','TV-MA')]
        for O0O00OOO000O0OO00 in O0O000O00O0000O00 :
            OOO000000O0O0O0OO .list .append ({'name':str (O0O00OOO000O0OO00 [0 ]),'url':OOO000000O0O0O0OO .certification_link %OOO000000O0O0O0OO .certificatesFormat (O0O00OOO000O0OO00 [1 ]),'image':'certificates.png','icon':'DefaultTVShows.png','action':'tvshows'})
        OOO000000O0O0O0OO .addDirectory (OOO000000O0O0O0OO .list )
        return OOO000000O0O0O0OO .list 
    def certificatesFormat (O0O0OO00OOO0O0O0O ,O0000OOO0OOO00O0O ):
        OO0OO0O00OO0O0O00 ='US%3A'
        if not isinstance (O0000OOO0OOO00O0O ,(tuple ,list )):
            O0000OOO0OOO00O0O =[O0000OOO0OOO00O0O ]
        return ','.join ([OO0OO0O00OO0O0O00 +O00O0OO0O0O00OOO0 .upper ()for O00O0OO0O0O00OOO0 in O0000OOO0OOO00O0O ])
    def persons (O0O00OOO000OO0O00 ,O0OO00O000OO0OO00 ):
        if O0OO00O000OO0OO00 is None :O0O00OOO000OO0O00 .list =cache .get (O0O00OOO000OO0O00 .imdb_person_list ,24 ,O0O00OOO000OO0O00 .personlist_link )
        else :O0O00OOO000OO0O00 .list =cache .get (O0O00OOO000OO0O00 .imdb_person_list ,1 ,O0OO00O000OO0OO00 )
        if len (O0O00OOO000OO0O00 .list )==0 :
            control .hide ()
            control .notification (title =32010 ,message =33049 )
        for O00OO000OO00OO0O0 in range (0 ,len (O0O00OOO000OO0O00 .list )):
            O0O00OOO000OO0O00 .list [O00OO000OO00OO0O0 ].update ({'icon':'DefaultActor.png','action':'tvshows'})
        O0O00OOO000OO0O00 .addDirectory (O0O00OOO000OO0O00 .list )
        return O0O00OOO000OO0O00 .list 
    def tvshowsListToLibrary (O00000O0OO00O0O00 ,O0O0O0000OOOOOO00 ):
        O0O0O0000OOOOOO00 =getattr (O00000O0OO00O0O00 ,O0O0O0000OOOOOO00 +'_link')
        O00OO00O000OO0OO0 =urlparse (O0O0O0000OOOOOO00 ).netloc .lower ()
        try :
            control .hide ()
            if O00OO00O000OO0OO0 in O00000O0OO00O0O00 .tmdb_link :OO000O0OOOO00OO00 =tmdb_indexer .userlists (O0O0O0000OOOOOO00 )
            elif O00OO00O000OO0OO0 in O00000O0OO00O0O00 .trakt_link :OO000O0OOOO00OO00 =O00000O0OO00O0O00 .trakt_user_list (O0O0O0000OOOOOO00 ,O00000O0OO00O0O00 .trakt_user )
            OO000O0OOOO00OO00 =[(O000O0O0O000000OO ['name'],O000O0O0O000000OO ['url'])for O000O0O0O000000OO in OO000O0OOOO00OO00 ]
            O000OOOO0O0O00O0O =32663 
            if 'themoviedb'in O0O0O0000OOOOOO00 :O000OOOO0O0O00O0O =32681 
            O0O0OO00OO0O00OOO =control .selectDialog ([OOO0OOOO00OO00O00 [0 ]for OOO0OOOO00OO00O00 in OO000O0OOOO00OO00 ],control .lang (O000OOOO0O0O00O0O ))
            O0O000OO0O0OO0000 =OO000O0OOOO00OO00 [O0O0OO00OO0O00OOO ][0 ]
            if O0O0OO00OO0O00OOO ==-1 :return 
            OOOOOOO0OO000000O =OO000O0OOOO00OO00 [O0O0OO00OO0O00OOO ][1 ]
            OOOOOOO0OO000000O =OOOOOOO0OO000000O .split ('&sort_by')[0 ]
            from resources .lib .modules import library 
            library .libtvshows ().range (OOOOOOO0OO000000O ,O0O000OO0O0OO0000 )
        except :
            log_utils .error ()
            return 
    def userlists (OOOO0O000O0000000 ):
        OO0000OO00O0O0O00 =[]
        try :
            if not OOOO0O000O0000000 .traktCredentials :raise Exception ()
            OO0000O000000O00O =trakt .getActivity ()
            OOOO0O000O0000000 .list =[];OO0OOOOO0O00000OO =[]
            try :
                if OO0000O000000O00O >cache .timeout (OOOO0O000O0000000 .trakt_user_list ,OOOO0O000O0000000 .traktlists_link ,OOOO0O000O0000000 .trakt_user ):
                    raise Exception ()
                OO0OOOOO0O00000OO +=cache .get (OOOO0O000O0000000 .trakt_user_list ,720 ,OOOO0O000O0000000 .traktlists_link ,OOOO0O000O0000000 .trakt_user )
            except :
                OO0OOOOO0O00000OO +=cache .get (OOOO0O000O0000000 .trakt_user_list ,0 ,OOOO0O000O0000000 .traktlists_link ,OOOO0O000O0000000 .trakt_user )
            for O0000O00O00O00O0O in range (len (OO0OOOOO0O00000OO )):
                OO0OOOOO0O00000OO [O0000O00O00O00O0O ].update ({'image':'trakt.png','icon':'DefaultVideoPlaylists.png','action':'tvshows'})
            OO0000OO00O0O0O00 +=OO0OOOOO0O00000OO 
        except :pass 
        try :
            if not OOOO0O000O0000000 .traktCredentials :raise Exception ()
            OOOO0O000O0000000 .list =[];OO0OOOOO0O00000OO =[]
            try :
                if OO0000O000000O00O >cache .timeout (OOOO0O000O0000000 .trakt_user_list ,OOOO0O000O0000000 .traktlikedlists_link ,OOOO0O000O0000000 .trakt_user ):
                    raise Exception ()
                OO0OOOOO0O00000OO +=cache .get (OOOO0O000O0000000 .trakt_user_list ,3 ,OOOO0O000O0000000 .traktlikedlists_link ,OOOO0O000O0000000 .trakt_user )
            except :
                OO0OOOOO0O00000OO +=cache .get (OOOO0O000O0000000 .trakt_user_list ,0 ,OOOO0O000O0000000 .traktlikedlists_link ,OOOO0O000O0000000 .trakt_user )
            for O0000O00O00O00O0O in range (len (OO0OOOOO0O00000OO )):
                OO0OOOOO0O00000OO [O0000O00O00O00O0O ].update ({'image':'trakt.png','icon':'DefaultVideoPlaylists.png','action':'tvshows'})
            OO0000OO00O0O0O00 +=OO0OOOOO0O00000OO 
        except :pass 
        try :
            if not OOOO0O000O0000000 .imdb_user :raise Exception ()
            OOOO0O000O0000000 .list =[]
            OO0OOOOO0O00000OO =cache .get (OOOO0O000O0000000 .imdb_user_list ,0 ,OOOO0O000O0000000 .imdblists_link )
            for O0000O00O00O00O0O in range (len (OO0OOOOO0O00000OO )):
                OO0OOOOO0O00000OO [O0000O00O00O00O0O ].update ({'image':'imdb.png','icon':'DefaultVideoPlaylists.png','action':'tvshows'})
            OO0000OO00O0O0O00 +=OO0OOOOO0O00000OO 
        except :pass 
        try :
            if OOOO0O000O0000000 .tmdb_session_id =='':raise Exception ()
            OOOO0O000O0000000 .list =[]
            OO0OOOOO0O00000OO =cache .get (tmdb_indexer .userlists ,0 ,OOOO0O000O0000000 .tmdb_userlists_link )
            for O0000O00O00O00O0O in range (len (OO0OOOOO0O00000OO )):
                OO0OOOOO0O00000OO [O0000O00O00O00O0O ].update ({'image':'tmdb.png','icon':'DefaultVideoPlaylists.png','action':'tmdbTvshows'})
            OO0000OO00O0O0O00 +=OO0OOOOO0O00000OO 
        except :pass 
        OOOO0O000O0000000 .list =[]
        for O0000O00O00O00O0O in range (len (OO0000OO00O0O0O00 )):
            O0OO0OOO0000OOO0O =False 
            O0OOOO0OOOO0OOOOO =OO0000OO00O0O0O00 [O0000O00O00O00O0O ]['url'].replace ('/me/','/%s/'%OOOO0O000O0000000 .trakt_user )
            for OO0OOO0OO000O000O in range (len (OOOO0O000O0000000 .list )):
                if O0OOOO0OOOO0OOOOO ==OOOO0O000O0000000 .list [OO0OOO0OO000O000O ]['url'].replace ('/me/','/%s/'%OOOO0O000O0000000 .trakt_user ):
                    O0OO0OOO0000OOO0O =True 
                    break 
            if not O0OO0OOO0000OOO0O :
                OOOO0O000O0000000 .list .append (OO0000OO00O0O0O00 [O0000O00O00O00O0O ])
        if OOOO0O000O0000000 .tmdb_session_id !='':
            OOOO0O000O0000000 .list .insert (0 ,{'name':control .lang (32026 ),'url':OOOO0O000O0000000 .tmdb_favorites_link ,'image':'tmdb.png','icon':'DefaultVideoPlaylists.png','action':'tmdbTvshows'})
        if OOOO0O000O0000000 .tmdb_session_id !='':
            OOOO0O000O0000000 .list .insert (0 ,{'name':control .lang (32033 ),'url':OOOO0O000O0000000 .tmdb_watchlist_link ,'image':'tmdb.png','icon':'DefaultVideoPlaylists.png','action':'tmdbTvshows'})
        if OOOO0O000O0000000 .imdb_user !='':
            OOOO0O000O0000000 .list .insert (0 ,{'name':control .lang (32033 ),'url':OOOO0O000O0000000 .imdbwatchlist_link ,'image':'imdb.png','icon':'DefaultVideoPlaylists.png','action':'tvshows'})
        if OOOO0O000O0000000 .imdb_user !='':
            OOOO0O000O0000000 .list .insert (0 ,{'name':control .lang (32025 ),'url':OOOO0O000O0000000 .imdbratings_link ,'image':'imdb.png','icon':'DefaultVideoPlaylists.png','action':'tvshows'})
        if OOOO0O000O0000000 .traktCredentials :
            OOOO0O000O0000000 .list .insert (0 ,{'name':control .lang (32033 ),'url':OOOO0O000O0000000 .traktwatchlist_link ,'image':'trakt.png','icon':'DefaultVideoPlaylists.png','action':'tvshows'})
        OOOO0O000O0000000 .addDirectory (OOOO0O000O0000000 .list )
        return OOOO0O000O0000000 .list 
    def trakt_list (O0000O0OO0OOO0OOO ,OO0OOOOOOOOOOO000 ,O00O00O00O0O0OO00 ):
        OOOOO000O0O0O0OO0 =[]
        try :
            O0000OO0O0OO000O0 =[]
            O0OO0O0O0O0OOO00O =dict (parse_qsl (urlsplit (OO0OOOOOOOOOOO000 ).query ))
            O0OO0O0O0O0OOO00O .update ({'extended':'full'})
            O0OO0O0O0O0OOO00O =(urlencode (O0OO0O0O0O0OOO00O )).replace ('%2C',',')
            OO0O0OOOOO0O0OOO0 =OO0OOOOOOOOOOO000 .replace ('?'+urlparse (OO0OOOOOOOOOOO000 ).query ,'')+'?'+O0OO0O0O0O0OOO00O 
            if '/related'in OO0O0OOOOO0O0OOO0 :OO0O0OOOOO0O0OOO0 =OO0O0OOOOO0O0OOO0 +'&limit=20'
            OO000OO00OO0000OO =trakt .getTraktAsJson (OO0O0OOOOO0O0OOO0 )
            if not OO000OO00OO0000OO :return OOOOO000O0O0O0OO0 
            OOOO000000OO0O0OO =[]
            for O0000O00O000O0000 in OO000OO00OO0000OO :
                try :
                    OO000O000O0OOO000 =O0000O00O000O0000 ['show']
                    OO000O000O0OOO000 ['added']=O0000O00O000O0000 .get ('listed_at')
                    OO000O000O0OOO000 ['paused_at']=O0000O00O000O0000 .get ('paused_at','')
                    try :OO000O000O0OOO000 ['progress']=max (0 ,min (1 ,O0000O00O000O0000 ['progress']/100.0 ))
                    except :OO000O000O0OOO000 ['progress']=''
                    OO000O000O0OOO000 ['lastplayed']=O0000O00O000O0000 .get ('watched_at','')
                    OOOO000000OO0O0OO .append (OO000O000O0OOO000 )
                except :pass 
            if len (OOOO000000OO0O0OO )==0 :OOOO000000OO0O0OO =OO000OO00OO0000OO 
        except :
            log_utils .error ()
            return 
        try :
            O0OO0O0O0O0OOO00O =dict (parse_qsl (urlsplit (OO0OOOOOOOOOOO000 ).query ))
            if int (O0OO0O0O0O0OOO00O ['limit'])!=len (OOOO000000OO0O0OO ):raise Exception ()
            O0OO0O0O0O0OOO00O .update ({'page':str (int (O0OO0O0O0O0OOO00O ['page'])+1 )})
            O0OO0O0O0O0OOO00O =(urlencode (O0OO0O0O0O0OOO00O )).replace ('%2C',',')
            O0O00OO0OO0O0OO00 =OO0OOOOOOOOOOO000 .replace ('?'+urlparse (OO0OOOOOOOOOOO000 ).query ,'')+'?'+O0OO0O0O0O0OOO00O 
        except :O0O00OO0OO0O0OO00 =''
        def O0O000OOOO0O000OO (OOOO00O0OO00OO00O ):
            try :
                OOO0OO00O00O0OO00 =OOOO00O0OO00OO00O 
                OOO0OO00O00O0OO00 ['next']=O0O00OO0OO0O0OO00 
                OOO0OO00O00O0OO00 ['title']=py_tools .ensure_str (OOOO00O0OO00OO00O .get ('title'))
                OOO0OO00O00O0OO00 ['originaltitle']=OOO0OO00O00O0OO00 ['title']
                OOO0OO00O00O0OO00 ['tvshowtitle']=OOO0OO00O00O0OO00 ['title']
                try :OOO0OO00O00O0OO00 ['premiered']=OOOO00O0OO00OO00O .get ('first_aired','')[:10 ]
                except :OOO0OO00O00O0OO00 ['premiered']=''
                OOO0OO00O00O0OO00 ['year']=str (OOOO00O0OO00OO00O .get ('year'))if OOOO00O0OO00OO00O .get ('year')else ''
                if not OOO0OO00O00O0OO00 ['year']:
                    try :OOO0OO00O00O0OO00 ['year']=str (OOO0OO00O00O0OO00 ['premiered'][:4 ])
                    except :OOO0OO00O00O0OO00 ['year']=''
                O0O0O0O0O0O0000OO =OOOO00O0OO00OO00O .get ('ids',{})
                OOO0OO00O00O0OO00 ['imdb']=str (O0O0O0O0O0O0000OO .get ('imdb',''))if O0O0O0O0O0O0000OO .get ('imdb','')else ''
                OOO0OO00O00O0OO00 ['tmdb']=str (O0O0O0O0O0O0000OO .get ('tmdb'))if O0O0O0O0O0O0000OO .get ('tmdb','')else ''
                OOO0OO00O00O0OO00 ['tvdb']=str (O0O0O0O0O0O0000OO .get ('tvdb'))if O0O0O0O0O0O0000OO .get ('tvdb','')else ''
                if OOO0OO00O00O0OO00 ['tvdb']in O0000OO0O0OO000O0 :return 
                O0000OO0O0OO000O0 .append (OOO0OO00O00O0OO00 ['tvdb'])
                OOO0OO00O00O0OO00 ['studio']=OOOO00O0OO00OO00O .get ('network')
                OOO0OO00O00O0OO00 ['genre']=[]
                for OO0000OO0O00OOO0O in OOOO00O0OO00OO00O ['genres']:OOO0OO00O00O0OO00 ['genre'].append (OO0000OO0O00OOO0O .title ())
                if not OOO0OO00O00O0OO00 ['genre']:OOO0OO00O00O0OO00 ['genre']='NA'
                OOO0OO00O00O0OO00 ['duration']=int (OOOO00O0OO00OO00O .get ('runtime')*60 )if OOOO00O0OO00OO00O .get ('runtime')else ''
                OOO0OO00O00O0OO00 ['total_episodes']=OOOO00O0OO00OO00O .get ('aired_episodes','')
                OOO0OO00O00O0OO00 ['mpaa']=OOOO00O0OO00OO00O .get ('certification','')
                OOO0OO00O00O0OO00 ['plot']=py_tools .ensure_str (OOOO00O0OO00OO00O .get ('overview'))
                OOO0OO00O00O0OO00 ['poster']=''
                OOO0OO00O00O0OO00 ['fanart']=''
                try :OOO0OO00O00O0OO00 ['trailer']=control .trailer %OOOO00O0OO00OO00O ['trailer'].split ('v=')[1 ]
                except :OOO0OO00O00O0OO00 ['trailer']=''
                OO0OOO00OOOO0OO00 =OOOO00O0OO00OO00O .get ('airs',{})
                OOO0OO00O00O0OO00 ['airday']=OO0OOO00OOOO0OO00 ['day']
                OOO0OO00O00O0OO00 ['airtime']=OO0OOO00OOOO0OO00 ['time']
                OOO0OO00O00O0OO00 ['airzone']=OO0OOO00OOOO0OO00 ['timezone']
                for OO00O0OOOO00O00OO in ('first_aired','ids','genres','runtime','certification','overview','aired_episodes','comment_count','network','airs'):OOO0OO00O00O0OO00 .pop (OO00O0OOOO00O00OO ,None )
                OOOOO000O0O0O0OO0 .append (OOO0OO00O00O0OO00 )
            except :
                log_utils .error ()
        O0OOOOO0O0OOO0000 =[]
        for OOOOO0OO0O00O00O0 in OOOO000000OO0O0OO :O0OOOOO0O0OOO0000 .append (workers .Thread (O0O000OOOO0O000OO ,OOOOO0OO0O00O00O0 ))
        [OOOO0OO000000OO00 .start ()for OOOO0OO000000OO00 in O0OOOOO0O0OOO0000 ]
        [OOO0O0OOOO0O0O00O .join ()for OOO0O0OOOO0O0O00O in O0OOOOO0O0OOO0000 ]
        return OOOOO000O0O0O0OO0 
    def trakt_user_list (O0O0O0O00OOOO0OO0 ,O0O000O000O0OO000 ,O0OOOO000O00OO0O0 ):
        OO00OOOO00OOOOO0O =[]
        try :
            O00OO00O0000OOOO0 =trakt .getTrakt (O0O000O000O0OO000 )
            O0OO0OOOOOOO00000 =jsloads (O00OO00O0000OOOO0 )
        except :
            log_utils .error ()
        for O0OOOOOOO0O0O0OO0 in O0OO0OOOOOOO00000 :
            try :
                try :O0OO00O0O0OO0O0OO =O0OOOOOOO0O0O0OO0 ['list']['name']
                except :O0OO00O0O0OO0O0OO =O0OOOOOOO0O0O0OO0 ['name']
                O0OO00O0O0OO0O0OO =client .replaceHTMLCodes (O0OO00O0O0OO0O0OO )
                try :O0O000O000O0OO000 =(trakt .slug (O0OOOOOOO0O0O0OO0 ['list']['user']['username']),O0OOOOOOO0O0O0OO0 ['list']['ids']['slug'])
                except :O0O000O000O0OO000 =('me',O0OOOOOOO0O0O0OO0 ['ids']['slug'])
                O0O000O000O0OO000 =O0O0O0O00OOOO0OO0 .traktlist_link %O0O000O000O0OO000 
                OO00OOOO00OOOOO0O .append ({'name':O0OO00O0O0OO0O0OO ,'url':O0O000O000O0OO000 ,'context':O0O000O000O0OO000 })
            except :
                log_utils .error ()
        OO00OOOO00OOOOO0O =sorted (OO00OOOO00OOOOO0O ,key =lambda OOOOO0OOOOO0O0000 :re .sub (r'(^the |^a |^an )','',OOOOO0OOOOO0O0000 ['name'].lower ()))
        return OO00OOOO00OOOOO0O 
    def imdb_list (O00OO0000O0000OO0 ,O00OO0OO00OO0000O ,OOO0OOO0O000O0OO0 =False ):
        O0O000OO0OO0O000O =[];O0OO00O0O000OOOOO =[];OO0O00OOOOOO0OOO0 =[]
        try :
            for O0OO000O0000O0O00 in re .findall (r'date\[(\d+)\]',O00OO0OO00OO0000O ):
                O00OO0OO00OO0000O =O00OO0OO00OO0000O .replace ('date[%s]'%O0OO000O0000O0O00 ,(O00OO0000O0000OO0 .date_time -timedelta (days =int (O0OO000O0000O0O00 ))).strftime ('%Y-%m-%d'))
            def OOOOOO00O00OOOOO0 (O0OO0000OOO0O00OO ):
                return client .parseDOM (client .request (O0OO0000OOO0O00OO ),'meta',ret ='content',attrs ={'property':'pageId'})[0 ]
            if O00OO0OO00OO0000O ==O00OO0000O0000OO0 .imdbwatchlist_link :
                O00OO0OO00OO0000O =cache .get (OOOOOO00O00OOOOO0 ,8640 ,O00OO0OO00OO0000O )
                O00OO0OO00OO0000O =O00OO0000O0000OO0 .imdbwatchlist2_link %O00OO0OO00OO0000O 
            OOOO0O0OO000O00OO =client .request (O00OO0OO00OO0000O )
            OOOO0O0OO000O00OO =OOOO0O0OO000O00OO .replace ('\n',' ')
            O0OO00O0O000OOOOO =client .parseDOM (OOOO0O0OO000O00OO ,'div',attrs ={'class':'.+? lister-item'})+client .parseDOM (OOOO0O0OO000O00OO ,'div',attrs ={'class':'lister-item .+?'})
            O0OO00O0O000OOOOO +=client .parseDOM (OOOO0O0OO000O00OO ,'div',attrs ={'class':'list_item.+?'})
        except :
            log_utils .error ()
            return 
        try :
            OOOO0O0OO000O00OO =OOOO0O0OO000O00OO .replace ('"class="lister-page-next','" class="lister-page-next')
            O000OOO0OOOOO0OOO =client .parseDOM (OOOO0O0OO000O00OO ,'a',ret ='href',attrs ={'class':'lister-page-next.+?'})
            if len (O000OOO0OOOOO0OOO )==0 :
                O000OOO0OOOOO0OOO =client .parseDOM (OOOO0O0OO000O00OO ,'div',attrs ={'class':'pagination'})[0 ]
                O000OOO0OOOOO0OOO =zip (client .parseDOM (O000OOO0OOOOO0OOO ,'a',ret ='href'),client .parseDOM (O000OOO0OOOOO0OOO ,'a'))
                O000OOO0OOOOO0OOO =[OOOOO0OO0O0OO0000 [0 ]for OOOOO0OO0O0OO0000 in O000OOO0OOOOO0OOO if 'Next'in OOOOO0OO0O0OO0000 [1 ]]
            O000OOO0OOOOO0OOO =O00OO0OO00OO0000O .replace (urlparse (O00OO0OO00OO0000O ).query ,urlparse (O000OOO0OOOOO0OOO [0 ]).query )
            O000OOO0OOOOO0OOO =client .replaceHTMLCodes (O000OOO0OOOOO0OOO )
        except :
            O000OOO0OOOOO0OOO =''
        for OOO0O00OO00O0O0O0 in O0OO00O0O000OOOOO :
            try :
                O0O00O0000O00OOOO =client .replaceHTMLCodes (client .parseDOM (OOO0O00OO00O0O0O0 ,'a')[1 ])
                O0O00O0000O00OOOO =py_tools .ensure_str (O0O00O0000O00OOOO )
                O0OO000O000O0O0O0 =client .parseDOM (OOO0O00OO00O0O0O0 ,'span',attrs ={'class':'lister-item-year.+?'})
                O0OO000O000O0O0O0 +=client .parseDOM (OOO0O00OO00O0O0O0 ,'span',attrs ={'class':'year_type'})
                O0OO000O000O0O0O0 =re .findall (r'(\d{4})',O0OO000O000O0O0O0 [0 ])[0 ]
                if int (O0OO000O000O0O0O0 )>int ((O00OO0000O0000OO0 .date_time ).strftime ('%Y')):raise Exception ()
                OOO0O0O000000OOO0 =client .parseDOM (OOO0O00OO00O0O0O0 ,'a',ret ='href')[0 ]
                OOO0O0O000000OOO0 =re .findall (r'(tt\d*)',OOO0O0O000000OOO0 )[0 ]
                if OOO0O0O000000OOO0 in OO0O00OOOOOO0OOO0 :raise Exception ()
                OO0O00OOOOOO0OOO0 .append (OOO0O0O000000OOO0 )
                O0O000OO0OO0O000O .append ({'title':O0O00O0000O00OOOO ,'tvshowtitle':O0O00O0000O00OOOO ,'originaltitle':O0O00O0000O00OOOO ,'year':O0OO000O000O0O0O0 ,'imdb':OOO0O0O000000OOO0 ,'tmdb':'','tvdb':'','next':O000OOO0OOOOO0OOO })
            except :
                log_utils .error ()
        return O0O000OO0OO0O000O 
    def imdb_person_list (O00O000OOOOOO0O0O ,OO0OO000OO00O0OO0 ):
        O00OOO0000O0O00OO =[]
        try :
            OO00O0O0OO0OOOO0O =client .request (OO0OO000OO00O0OO0 )
            OO00O0OO0O00O0OOO =client .parseDOM (OO00O0O0OO0OOOO0O ,'div',attrs ={'class':'.+? mode-detail'})
        except :return 
        for OOOO000000OOO0OOO in OO00O0OO0O00O0OOO :
            try :
                O0OO0OO00O00OO000 =client .parseDOM (OOOO000000OOO0OOO ,'img',ret ='alt')[0 ]
                OO0OO000OO00O0OO0 =client .parseDOM (OOOO000000OOO0OOO ,'a',ret ='href')[0 ]
                OO0OO000OO00O0OO0 =re .findall (r'(nm\d*)',OO0OO000OO00O0OO0 ,re .I )[0 ]
                OO0OO000OO00O0OO0 =O00O000OOOOOO0O0O .person_link %OO0OO000OO00O0OO0 
                OO0OO000OO00O0OO0 =client .replaceHTMLCodes (OO0OO000OO00O0OO0 )
                O000OO0O00O0000OO =client .parseDOM (OOOO000000OOO0OOO ,'img',ret ='src')[0 ]
                O000OO0O00O0000OO =re .sub (r'(?:_SX|_SY|_UX|_UY|_CR|_AL)(?:\d+|_).+?\.','_SX500.',O000OO0O00O0000OO )
                O000OO0O00O0000OO =client .replaceHTMLCodes (O000OO0O00O0000OO )
                O00OOO0000O0O00OO .append ({'name':O0OO0OO00O00OO000 ,'url':OO0OO000OO00O0OO0 ,'image':O000OO0O00O0000OO })
            except :
                log_utils .error ()
        return O00OOO0000O0O00OO 
    def imdb_user_list (O0000O0O0O0O0O0OO ,O00OO0O000O00OOOO ):
        O0000000OO00O0O0O =[]
        try :
            OOOO00OO00OO0OOOO =client .request (O00OO0O000O00OOOO )
            O0OO0OOOO0O0O0OOO =client .parseDOM (OOOO00OO00OO0OOOO ,'li',attrs ={'class':'ipl-zebra-list__item user-list'})
        except :
            log_utils .error ()
        for O0O0000O0O0O0OOO0 in O0OO0OOOO0O0O0OOO :
            try :
                O0O0OO0O0O0OO000O =client .parseDOM (O0O0000O0O0O0OOO0 ,'a')[0 ]
                O0O0OO0O0O0OO000O =client .replaceHTMLCodes (O0O0OO0O0O0OO000O )
                O00OO0O000O00OOOO =client .parseDOM (O0O0000O0O0O0OOO0 ,'a',ret ='href')[0 ]
                O00OO0O000O00OOOO =O00OO0O000O00OOOO .split ('/list/',1 )[-1 ].strip ('/')
                O00OO0O000O00OOOO =O0000O0O0O0O0O0OO .imdblist_link %O00OO0O000O00OOOO 
                O00OO0O000O00OOOO =client .replaceHTMLCodes (O00OO0O000O00OOOO )
                O0000000OO00O0O0O .append ({'name':O0O0OO0O0O0OO000O ,'url':O00OO0O000O00OOOO ,'context':O00OO0O000O00OOOO })
            except :
                log_utils .error ()
        O0000000OO00O0O0O =sorted (O0000000OO00O0O0O ,key =lambda O0OOO000O0O0O0O00 :re .sub (r'(^the |^a |^an )','',O0OOO000O0O0O0O00 ['name'].lower ()))
        return O0000000OO00O0O0O 
    def worker (OO0O0000O0OO0OO00 ,OO0O000OO0O0O000O =1 ):
        try :
            if not OO0O0000O0OO0OO00 .list :return 
            OO0O0000O0OO0OO00 .meta =[]
            OOO00O0OOOOOOO0OO =len (OO0O0000O0OO0OO00 .list )
            for OO000O00000OO0000 in range (0 ,OOO00O0OOOOOOO0OO ):
                OO0O0000O0OO0OO00 .list [OO000O00000OO0000 ].update ({'metacache':False })
            OO0O0000O0OO0OO00 .list =metacache .fetch (OO0O0000O0OO0OO00 .list ,OO0O0000O0OO0OO00 .lang ,OO0O0000O0OO0OO00 .user )
            for O00000O0O0O0O0O0O in range (0 ,OOO00O0OOOOOOO0OO ,40 ):
                O0OOOO0OO0O0O0O0O =[]
                for OO000O00000OO0000 in range (O00000O0O0O0O0O0O ,O00000O0O0O0O0O0O +40 ):
                    if OO000O00000OO0000 <OOO00O0OOOOOOO0OO :O0OOOO0OO0O0O0O0O .append (workers .Thread (OO0O0000O0OO0OO00 .super_info ,OO000O00000OO0000 ))
                [OO0OO0000O0OOOO0O .start ()for OO0OO0000O0OOOO0O in O0OOOO0OO0O0O0O0O ]
                [O0O0O0000000OO000 .join ()for O0O0O0000000OO000 in O0OOOO0OO0O0O0O0O ]
            if OO0O0000O0OO0OO00 .meta :
                OO0O0000O0OO0OO00 .meta =[O0O0O0O0OOO0OO0OO for O0O0O0O0OOO0OO0OO in OO0O0000O0OO0OO00 .meta if O0O0O0O0OOO0OO0OO .get ('tmdb')]
                metacache .insert (OO0O0000O0OO0OO00 .meta )
            OO0O0000O0OO0OO00 .list =[OO000OOO00O0O000O for OO000OOO00O0O000O in OO0O0000O0OO0OO00 .list if OO000OOO00O0O000O .get ('tmdb')]
        except :
            log_utils .error ()
    def super_info (O00O00OO0OOOOOOOO ,O0OOOO0000OOOO000 ):
        try :
            if O00O00OO0OOOOOOOO .list [O0OOOO0000OOOO000 ]['metacache']:return 
            O000000OOOOO000O0 =O00O00OO0OOOOOOOO .list [O0OOOO0000OOOO000 ].get ('imdb','');OOO00OOO0O00O0O00 =O00O00OO0OOOOOOOO .list [O0OOOO0000OOOO000 ].get ('tmdb','');O0000O0OOO000O0OO =O00O00OO0OOOOOOOO .list [O0OOOO0000OOOO000 ].get ('tvdb','')
            OO00OOOO0O00OO00O =None 
            if (not OOO00OOO0O00O0O00 or not O0000O0OOO000O0OO )and O000000OOOOO000O0 :OO00OOOO0O00OO00O =trakt .IdLookup ('imdb',O000000OOOOO000O0 ,'show')
            if (not OOO00OOO0O00O0O00 or not O000000OOOOO000O0 )and O0000O0OOO000O0OO :OO00OOOO0O00OO00O =trakt .IdLookup ('tvdb',O0000O0OOO000O0OO ,'show')
            if OO00OOOO0O00OO00O :
                if not O000000OOOOO000O0 :O000000OOOOO000O0 =str (OO00OOOO0O00OO00O .get ('imdb',''))if OO00OOOO0O00OO00O .get ('imdb')else ''
                if not OOO00OOO0O00O0O00 :OOO00OOO0O00O0O00 =str (OO00OOOO0O00OO00O .get ('tmdb',''))if OO00OOOO0O00OO00O .get ('tmdb')else ''
                if not O0000O0OOO000O0OO :O0000O0OOO000O0OO =str (OO00OOOO0O00OO00O .get ('tvdb',''))if OO00OOOO0O00OO00O .get ('tvdb')else ''
            if not OOO00OOO0O00O0O00 and (O000000OOOOO000O0 or O0000O0OOO000O0OO ):
                try :
                    OO0OOOOO0OOO00000 =cache .get (tmdb_indexer .TVshows ().IdLookup ,96 ,O000000OOOOO000O0 ,O0000O0OOO000O0OO )
                    OOO00OOO0O00O0O00 =str (OO0OOOOO0OOO00000 .get ('id',''))if OO0OOOOO0OOO00000 .get ('id')else ''
                except :OOO00OOO0O00O0O00 =''
            if not O000000OOOOO000O0 or not OOO00OOO0O00O0O00 or not O0000O0OOO000O0OO :
                log_utils .log ('Third fallback attempt to fetch missing ids for tvshowtitle: (%s)'%O00O00OO0OOOOOOOO .list [O0OOOO0000OOOO000 ]['title'],__name__ ,log_utils .LOGDEBUG )
                try :
                    OOO0O000O00000OO0 =trakt .SearchTVShow (quote_plus (O00O00OO0OOOOOOOO .list [O0OOOO0000OOOO000 ]['title']),O00O00OO0OOOOOOOO .list [O0OOOO0000OOOO000 ]['year'],full =False )
                    if OOO0O000O00000OO0 [0 ]['show']['title'].lower ()!=O00O00OO0OOOOOOOO .list [O0OOOO0000OOOO000 ]['title'].lower ()or int (OOO0O000O00000OO0 [0 ]['show']['year'])!=int (O00O00OO0OOOOOOOO .list [O0OOOO0000OOOO000 ]['year']):return 
                    O0OO0OO00O0O00000 =OOO0O000O00000OO0 [0 ].get ('show',{}).get ('ids',{})
                    if not O000000OOOOO000O0 :O000000OOOOO000O0 =str (O0OO0OO00O0O00000 .get ('imdb',''))if O0OO0OO00O0O00000 .get ('imdb')else ''
                    if not OOO00OOO0O00O0O00 :OOO00OOO0O00O0O00 =str (O0OO0OO00O0O00000 .get ('tmdb',''))if O0OO0OO00O0O00000 .get ('tmdb')else ''
                    if not O0000O0OOO000O0OO :O0000O0OOO000O0OO =str (O0OO0OO00O0O00000 .get ('tvdb',''))if O0OO0OO00O0O00000 .get ('tvdb')else ''
                except :pass 
            if not OOO00OOO0O00O0O00 :
                log_utils .log ('tvshowtitle: (%s) missing tmdb_id'%O00O00OO0OOOOOOOO .list [O0OOOO0000OOOO000 ]['title'],__name__ ,log_utils .LOGDEBUG )
                return 
            O0OO00O0000O0OO00 =cache .get (tmdb_indexer .TVshows ().get_showSeasons_meta ,96 ,OOO00OOO0O00O0O00 )
            if not O0OO00O0000O0OO00 :return 
            O00O0O0000OOO00O0 ={}
            O00O0O0000OOO00O0 .update (O0OO00O0000O0OO00 )
            if not O0000O0OOO000O0OO :O0000O0OOO000O0OO =O00O0O0000OOO00O0 .get ('tvdb','')
            if not O00O0O0000OOO00O0 .get ('imdb'):O00O0O0000OOO00O0 ['imdb']=O000000OOOOO000O0 
            if not O00O0O0000OOO00O0 .get ('tmdb'):O00O0O0000OOO00O0 ['tmdb']=OOO00OOO0O00O0O00 
            if not O00O0O0000OOO00O0 .get ('tvdb'):O00O0O0000OOO00O0 ['tvdb']=O0000O0OOO000O0OO 
            if not O00O00OO0OOOOOOOO .disable_fanarttv :
                OOOOO0OOO0O0O0O00 =cache .get (fanarttv .get_tvshow_art ,168 ,O0000O0OOO000O0OO )
                if OOOOO0OOO0O0O0O00 :O00O0O0000OOO00O0 .update (OOOOO0OOO0O0O0O00 )
            O00O0O0000OOO00O0 =dict ((OO000000OO00O00O0 ,OOOO000O00O0000O0 )for OO000000OO00O00O0 ,OOOO000O00O0000O0 in control .iteritems (O00O0O0000OOO00O0 )if OOOO000O00O0000O0 is not None and OOOO000O00O0000O0 !='')
            O00O00OO0OOOOOOOO .list [O0OOOO0000OOOO000 ].update (O00O0O0000OOO00O0 )
            O0O000OOO0O0O0OOO ={'imdb':O000000OOOOO000O0 ,'tmdb':OOO00OOO0O00O0O00 ,'tvdb':O0000O0OOO000O0OO ,'lang':O00O00OO0OOOOOOOO .lang ,'user':O00O00OO0OOOOOOOO .user ,'item':O00O0O0000OOO00O0 }
            O00O00OO0OOOOOOOO .meta .append (O0O000OOO0O0O0OOO )
        except :
            log_utils .error ()
    def tvshowDirectory (O0OO0000O0O000O00 ,OOOO00O0O0O000000 ,OO0OOO0O00O00O0O0 =True ):
        control .playlist .clear ()
        if not OOOO00O0O0O000000 :
            control .hide ();control .notification (title =32002 ,message =33049 )
        OO000O0OOO000O000 ,O00OOO0O00OO00O00 =argv [0 ],int (argv [1 ])
        OO0OOOO000OO00000 ='plugin'not in control .infoLabel ('Container.PluginName')
        O0OO0OOOO0OO0O00O =control .setting ('fanart')=='true'
        OOO000OOO0OOOO00O ,OO000O00O0O000000 ,OO00O0OO000OO0000 =control .addonPoster (),control .addonFanart (),control .addonBanner ()
        OOO000OOOO00O0000 =playcount .getTVShowIndicators (refresh =True )
        OO0O000OOOO0O0OOO =control .setting ('tvshows.unwatched.enabled')=='true'
        O00OOOOO0O0000O00 =control .setting ('flatten.tvshows')=='true'
        if trakt .getTraktIndicatorsInfo ():
            O000000000O0OO0O0 ,O0OO0OOO00O000OO0 =control .lang (32068 ),control .lang (32069 )
        else :
            O000000000O0OO0O0 ,O0OO0OOO00O000OO0 =control .lang (32066 ),control .lang (32067 )
        O0O0O000000OO00O0 ,O0000O00O000O0O00 =control .lang (32070 ),control .lang (32065 )
        O0000OO0O0O0O000O ,O0O0O0O00OOOOO0O0 =control .lang (35517 ),control .lang (35516 )
        O0O0OO0000OOOO0OO ,OO0O00OOOO00OO000 =control .lang (32535 ),control .lang (32551 )
        O0O00OO0O0O0O000O =control .lang (32053 )
        for OO0OO0OO0OO0OO00O in OOOO00O0O0O000000 :
            try :
                OOOO000O0OOOO0O00 ,O0O00OO00OOO0OO0O ,OO0O000OO0OO000O0 ,OOO0O0OOO0000O0O0 ,OOO0O0OO00O000O0O =OO0OO0OO0OO0OO00O .get ('imdb',''),OO0OO0OO0OO0OO00O .get ('tmdb',''),OO0OO0OO0OO0OO00O .get ('tvdb',''),OO0OO0OO0OO0OO00O .get ('year',''),OO0OO0OO0OO0OO00O .get ('trailer','')
                OO000OO00O0OO00O0 =OO0OO0OO0OO0OO00O .get ('tvshowtitle')or OO0OO0OO0OO0OO00O .get ('title')
                O0OO0OO0O00000O00 =quote_plus (OO000OO00O0OO00O0 )
                O0O0O00O00OOO00OO =dict ((O00O0OOO0000O0OO0 ,OO0000O0000OO00O0 )for O00O0OOO0000O0OO0 ,OO0000O0000OO00O0 in control .iteritems (OO0OO0OO0OO0OO00O )if OO0000O0000OO00O0 is not None and OO0000O0000OO00O0 !='')
                O0O0O00O00OOO00OO .update ({'code':OOOO000O0OOOO0O00 ,'imdbnumber':OOOO000O0OOOO0O00 ,'mediatype':'tvshow','tag':[OOOO000O0OOOO0O00 ,O0O00OO00OOO0OO0O ]})
                if OO0O000OOOO0O0OOO :trakt .seasonCount (OOOO000O0OOOO0O00 )
                try :O0O0O00O00OOO00OO .update ({'genre':cleangenre .lang (O0O0O00O00OOO00OO ['genre'],O0OO0000O0O000O00 .lang )})
                except :pass 
                try :
                    if 'tvshowtitle'not in O0O0O00O00OOO00OO :O0O0O00O00OOO00OO .update ({'tvshowtitle':OO000OO00O0OO00O0 })
                except :pass 
                OO000O00OO0OOOO0O =O0O0O00O00OOO00OO .get ('poster3')or O0O0O00O00OOO00OO .get ('poster2')or O0O0O00O00OOO00OO .get ('poster')or OOO000OOO0OOOO00O 
                OOOO0O00000O00O00 =O0O0O00O00OOO00OO .get ('landscape')
                OOOO0O0O00O00O0OO =''
                if O0OO0OOOO0OO0O00O :OOOO0O0O00O00O0OO =O0O0O00O00OOO00OO .get ('fanart3')or O0O0O00O00OOO00OO .get ('fanart2')or O0O0O00O00OOO00OO .get ('fanart')or OOOO0O00000O00O00 or OO000O00O0O000000 
                OO0OOOO00O0OO00OO =O0O0O00O00OOO00OO .get ('thumb')or OO000O00OO0OOOO0O or OOOO0O00000O00O00 
                OOOOO00OO00O0O0OO =O0O0O00O00OOO00OO .get ('icon')or OO000O00OO0OOOO0O 
                OO0O0OOOO0OOOO0O0 =O0O0O00O00OOO00OO .get ('banner3')or O0O0O00O00OOO00OO .get ('banner2')or O0O0O00O00OOO00OO .get ('banner')or OO00O0OO000OO0000 
                O00O0OO0O00OO0OOO ={}
                O00O0OO0O00OO0OOO .update ({'poster':OO000O00OO0OOOO0O ,'tvshow.poster':OO000O00OO0OOOO0O ,'season.poster':OO000O00OO0OOOO0O ,'fanart':OOOO0O0O00O00O0OO ,'icon':OOOOO00OO00O0O0OO ,'thumb':OO0OOOO00O0OO00OO ,'banner':OO0O0OOOO0OOOO0O0 ,'clearlogo':O0O0O00O00OOO00OO .get ('clearlogo'),'clearart':O0O0O00O00OOO00OO .get ('clearart'),'landscape':OOOO0O00000O00O00 })
                for OOO0000O0O00O00OO in ('poster2','poster3','fanart2','fanart3','banner2','banner3','trailer'):O0O0O00O00OOO00OO .pop (OOO0000O0O00O00OO ,None )
                O0O0O00O00OOO00OO .update ({'poster':OO000O00OO0OOOO0O ,'fanart':OOOO0O0O00O00O0OO ,'banner':OO0O0OOOO0OOOO0O0 ,'thumb':OO0OOOO00O0OO00OO ,'icon':OOOOO00OO00O0O0OO })
                O00O00O0OOOO000OO =[]
                if O0OO0000O0O000O00 .traktCredentials :
                    O00O00O0OOOO000OO .append ((O0O0O000000OO00O0 ,'RunPlugin(%s?action=tools_traktManager&name=%s&imdb=%s&tvdb=%s)'%(OO000O0OOO000O000 ,O0OO0OO0O00000O00 ,OOOO000O0OOOO0O00 ,OO0O000OO0OO000O0 )))
                try :
                    O0O00O0O0OO00000O =int (playcount .getTVShowOverlay (OOO000OOOO00O0000 ,OOOO000O0OOOO0O00 ,OO0O000OO0OO000O0 ))
                    O0OO0000O00O00O00 =(O0O00O0O0OO00000O ==5 )
                    if O0OO0000O00O00O00 :
                        O0O0O00O00OOO00OO .update ({'playcount':1 ,'overlay':5 })
                        O00O00O0OOOO000OO .append ((O0OO0OOO00O000OO0 ,'RunPlugin(%s?action=playcount_TVShow&name=%s&imdb=%s&tvdb=%s&query=4)'%(OO000O0OOO000O000 ,O0OO0OO0O00000O00 ,OOOO000O0OOOO0O00 ,OO0O000OO0OO000O0 )))
                    else :
                        O0O0O00O00OOO00OO .update ({'playcount':0 ,'overlay':4 })
                        O00O00O0OOOO000OO .append ((O000000000O0OO0O0 ,'RunPlugin(%s?action=playcount_TVShow&name=%s&imdb=%s&tvdb=%s&query=5)'%(OO000O0OOO000O000 ,O0OO0OO0O00000O00 ,OOOO000O0OOOO0O00 ,OO0O000OO0OO000O0 )))
                except :pass 
                O0O0OOOO0O00O0O00 ,OOO0000O0O0O0OO00 =quote_plus (jsdumps (O0O0O00O00OOO00OO )),quote_plus (jsdumps (O00O0OO0O00OO0OOO ))
                O00O00O0OOOO000OO .append (('Find similar','ActivateWindow(10025,%s?action=tvshows&url=https://api.trakt.tv/shows/%s/related,return)'%(OO000O0OOO000O000 ,OOOO000O0OOOO0O00 )))
                O00O00O0OOOO000OO .append ((O0O0OO0000OOOO0OO ,'RunPlugin(%s?action=random&rtype=season&tvshowtitle=%s&year=%s&imdb=%s&tmdb=%s&tvdb=%s&art=%s)'%(OO000O0OOO000O000 ,O0OO0OO0O00000O00 ,OOO0O0OOO0000O0O0 ,OOOO000O0OOOO0O00 ,O0O00OO00OOO0OO0O ,OO0O000OO0OO000O0 ,OOO0000O0O0O0OO00 )))
                O00O00O0OOOO000OO .append ((O0000O00O000O0O00 ,'RunPlugin(%s?action=playlist_QueueItem&name=%s)'%(OO000O0OOO000O000 ,O0OO0OO0O00000O00 )))
                O00O00O0OOOO000OO .append ((O0000OO0O0O0O000O ,'RunPlugin(%s?action=playlist_Show)'%OO000O0OOO000O000 ))
                O00O00O0OOOO000OO .append ((O0O0O0O00OOOOO0O0 ,'RunPlugin(%s?action=playlist_Clear)'%OO000O0OOO000O000 ))
                O00O00O0OOOO000OO .append ((OO0O00OOOO00OO000 ,'RunPlugin(%s?action=library_tvshowToLibrary&tvshowtitle=%s&year=%s&imdb=%s&tmdb=%s&tvdb=%s)'%(OO000O0OOO000O000 ,O0OO0OO0O00000O00 ,OOO0O0OOO0000O0O0 ,OOOO000O0OOOO0O00 ,O0O00OO00OOO0OO0O ,OO0O000OO0OO000O0 )))
                O00O00O0OOOO000OO .append (('[COLOR deepskyblue]LE Settings[/COLOR]','RunPlugin(%s?action=tools_openSettings)'%OO000O0OOO000O000 ))
                if O00OOOOO0O0000O00 :O000O00000000OO00 ='%s?action=episodes&tvshowtitle=%s&year=%s&imdb=%s&tmdb=%s&tvdb=%s&meta=%s'%(OO000O0OOO000O000 ,O0OO0OO0O00000O00 ,OOO0O0OOO0000O0O0 ,OOOO000O0OOOO0O00 ,O0O00OO00OOO0OO0O ,OO0O000OO0OO000O0 ,O0O0OOOO0O00O0O00 )
                else :O000O00000000OO00 ='%s?action=seasons&tvshowtitle=%s&year=%s&imdb=%s&tmdb=%s&tvdb=%s&art=%s'%(OO000O0OOO000O000 ,O0OO0OO0O00000O00 ,OOO0O0OOO0000O0O0 ,OOOO000O0OOOO0O00 ,O0O00OO00OOO0OO0O ,OO0O000OO0OO000O0 ,OOO0000O0O0O0OO00 )
                if OOO0O0OO00O000O0O :O0O0O00O00OOO00OO .update ({'trailer':OOO0O0OO00O000O0O })
                else :O0O0O00O00OOO00OO .update ({'trailer':'%s?action=trailer&type=%s&name=%s&year=%s&imdb=%s'%(OO000O0OOO000O000 ,'show',O0OO0OO0O00000O00 ,OOO0O0OOO0000O0O0 ,OOOO000O0OOOO0O00 )})
                try :OOOO0O0000O000O0O =control .item (label =OO000OO00O0OO00O0 ,offscreen =True )
                except :OOOO0O0000O000O0O =control .item (label =OO000OO00O0OO00O0 )
                if 'castandart'in OO0OO0OO0OO0OO00O :OOOO0O0000O000O0O .setCast (OO0OO0OO0OO0OO00O ['castandart'])
                OOOO0O0000O000O0O .setArt (O00O0OO0O00OO0OOO )
                if OO0O000OOOO0O0OOO :
                    try :
                        O000OO0OO0OO0O0O0 =playcount .getShowCount (OOO000OOOO00O0000 ,OOOO000O0OOOO0O00 ,OO0O000OO0OO000O0 )
                        if O000OO0OO0OO0O0O0 :
                            OOOO0O0000O000O0O .setProperties ({'WatchedEpisodes':str (O000OO0OO0OO0O0O0 ['watched']),'UnWatchedEpisodes':str (O000OO0OO0OO0O0O0 ['unwatched'])})
                            OOOO0O0000O000O0O .setProperties ({'TotalSeasons':str (O0O0O00O00OOO00OO .get ('total_seasons','')),'TotalEpisodes':str (O000OO0OO0OO0O0O0 ['total'])})
                        else :
                            OOOO0O0000O000O0O .setProperties ({'WatchedEpisodes':'0','UnWatchedEpisodes':str (O0O0O00O00OOO00OO .get ('total_aired_episodes',''))})
                            OOOO0O0000O000O0O .setProperties ({'TotalSeasons':str (O0O0O00O00OOO00OO .get ('total_seasons','')),'TotalEpisodes':str (O0O0O00O00OOO00OO .get ('total_aired_episodes',''))})
                    except :pass 
                OOOO0O0000O000O0O .setProperty ('IsPlayable','false')
                OOOO0O0000O000O0O .setProperty ('tmdb_id',str (O0O00OO00OOO0OO0O ))
                if OO0OOOO000OO00000 :OOOO0O0000O000O0O .setProperty ('isLE_widget','true')
                OOOO0O0000O000O0O .setUniqueIDs ({'imdb':OOOO000O0OOOO0O00 ,'tmdb':O0O00OO00OOO0OO0O ,'tvdb':OO0O000OO0OO000O0 })
                OOOO0O0000O000O0O .setInfo (type ='video',infoLabels =control .metadataClean (O0O0O00O00OOO00OO ))
                OOOO0O0000O000O0O .addContextMenuItems (O00O00O0OOOO000OO )
                control .addItem (handle =O00OOO0O00OO00O00 ,url =O000O00000000OO00 ,listitem =OOOO0O0000O000O0O ,isFolder =True )
            except :
                log_utils .error ()
        if OO0OOO0O00O00O0O0 :
            try :
                if not OOOO00O0O0O000000 :raise Exception ()
                O000O00000000OO00 =OOOO00O0O0O000000 [0 ]['next']
                if not O000O00000000OO00 :raise Exception ()
                O00OOO00OOOOOOO0O =dict (parse_qsl (urlsplit (O000O00000000OO00 ).query ))
                if 'imdb.com'in O000O00000000OO00 and 'start'in O00OOO00OOOOOOO0O :
                    O00OOO00O0O0O0O0O ='  [I](%s)[/I]'%str (int (((int (O00OOO00OOOOOOO0O .get ('start'))-1 )/int (O0OO0000O0O000O00 .count ))+1 ))
                else :O00OOO00O0O0O0O0O ='  [I](%s)[/I]'%O00OOO00OOOOOOO0O .get ('page')
                O0O00OO0O0O0O000O ='[COLOR skyblue]'+O0O00OO0O0O0O000O +O00OOO00O0O0O0O0O +'[/COLOR]'
                O0OOOOOOO000O000O =urlparse (O000O00000000OO00 ).netloc .lower ()
                if O0OOOOOOO000O000O in O0OO0000O0O000O00 .imdb_link or O0OOOOOOO000O000O in O0OO0000O0O000O00 .trakt_link :
                    O000O00000000OO00 ='%s?action=tvshowPage&url=%s'%(OO000O0OOO000O000 ,quote_plus (O000O00000000OO00 ))
                elif O0OOOOOOO000O000O in O0OO0000O0O000O00 .tmdb_link :
                    O000O00000000OO00 ='%s?action=tmdbTvshowPage&url=%s'%(OO000O0OOO000O000 ,quote_plus (O000O00000000OO00 ))
                elif O0OOOOOOO000O000O in O0OO0000O0O000O00 .tvmaze_link :
                    O000O00000000OO00 ='%s?action=tvmazeTvshowPage&url=%s'%(OO000O0OOO000O000 ,quote_plus (O000O00000000OO00 ))
                try :OOOO0O0000O000O0O =control .item (label =O0O00OO0O0O0O000O ,offscreen =True )
                except :OOOO0O0000O000O0O =control .item (label =O0O00OO0O0O0O000O )
                OOOOO00OO00O0O0OO =control .addonNext ()
                OOOO0O0000O000O0O .setProperty ('IsPlayable','false')
                OOOO0O0000O000O0O .setArt ({'icon':OOOOO00OO00O0O0OO ,'thumb':OOOOO00OO00O0O0OO ,'poster':OOOOO00OO00O0O0OO ,'banner':OOOOO00OO00O0O0OO })
                OOOO0O0000O000O0O .setProperty ('SpecialSort','bottom')
                control .addItem (handle =O00OOO0O00OO00O00 ,url =O000O00000000OO00 ,listitem =OOOO0O0000O000O0O ,isFolder =True )
            except :
                log_utils .error ()
        control .content (O00OOO0O00OO00O00 ,'tvshows')
        control .directory (O00OOO0O00OO00O00 ,cacheToDisc =True )
        views .setView ('tvshows',{'skin.estuary':55 ,'skin.confluence':500 })
    def addDirectory (O00OO00OOOOOO00OO ,OO0O00OOO00O0O0OO ,O0O00O00000000OO0 =False ):
        control .playlist .clear ()
        if not OO0O00OOO00O0O0OO :
            control .hide ();control .notification (title =32002 ,message =33049 )
        O00O00OOO0O000OOO ,OO00OOOO0OOOOO000 =argv [0 ],int (argv [1 ])
        OOOOOO0000O00OO00 =control .addonThumb ()
        OOO0O0OO0OOOO00O0 =control .artPath ()
        OOOOO0OO0OO00OO00 ,O0OO0O0O0O000000O ,O0O000OO00000OO0O =control .lang (32065 ),control .lang (32535 ),control .lang (32551 )
        for O00OOO0O0000O00OO in OO0O00OOO00O0O0OO :
            try :
                OO0OO000OO00000O0 =O00OOO0O0000O00OO ['name']
                if O00OOO0O0000O00OO ['image'].startswith ('http'):OOOO0000OO000OO0O =O00OOO0O0000O00OO ['image']
                elif OOO0O0OO0OOOO00O0 :OOOO0000OO000OO0O =control .joinPath (OOO0O0OO0OOOO00O0 ,O00OOO0O0000O00OO ['image'])
                else :OOOO0000OO000OO0O =OOOOOO0000O00OO00 
                O000OOO00O0OO0OO0 =O00OOO0O0000O00OO .get ('icon',0 )
                if not O000OOO00O0OO0OO0 :O000OOO00O0OO0OO0 ='DefaultFolder.png'
                O0OOO000O0000000O ='%s?action=%s'%(O00O00OOO0O000OOO ,O00OOO0O0000O00OO ['action'])
                try :O0OOO000O0000000O +='&url=%s'%quote_plus (O00OOO0O0000O00OO ['url'])
                except :pass 
                OO0000000O00O0OOO =[]
                OO0000000O00O0OOO .append ((O0OO0O0O0O000000O ,'RunPlugin(%s?action=random&rtype=show&url=%s)'%(O00O00OOO0O000OOO ,quote_plus (O00OOO0O0000O00OO ['url']))))
                if O0O00O00000000OO0 :OO0000000O00O0OOO .append ((OOOOO0OO0OO00OO00 ,'RunPlugin(%s?action=playlist_QueueItem)'%O00O00OOO0O000OOO ))
                try :
                    if control .setting ('library.service.update')=='true':
                        OO0000000O00O0OOO .append ((O0O000OO00000OO0O ,'RunPlugin(%s?action=library_tvshowsToLibrary&url=%s&name=%s)'%(O00O00OOO0O000OOO ,quote_plus (O00OOO0O0000O00OO ['context']),OO0OO000OO00000O0 )))
                except :pass 
                OO0000000O00O0OOO .append (('[COLOR deepskyblue]LE Settings[/COLOR]','RunPlugin(%s?action=tools_openSettings)'%O00O00OOO0O000OOO ))
                try :O00O0OOO00O0OOO00 =control .item (label =OO0OO000OO00000O0 ,offscreen =True )
                except :O00O0OOO00O0OOO00 =control .item (label =OO0OO000OO00000O0 )
                O00O0OOO00O0OOO00 .setProperty ('IsPlayable','false')
                O00O0OOO00O0OOO00 .setArt ({'icon':O000OOO00O0OO0OO0 ,'poster':OOOO0000OO000OO0O ,'thumb':OOOO0000OO000OO0O ,'fanart':control .addonFanart (),'banner':OOOO0000OO000OO0O })
                O00O0OOO00O0OOO00 .addContextMenuItems (OO0000000O00O0OOO )
                control .addItem (handle =OO00OOOO0OOOOO000 ,url =O0OOO000O0000000O ,listitem =O00O0OOO00O0OOO00 ,isFolder =True )
            except :
                log_utils .error ()
        control .content (OO00OOOO0OOOOO000 ,'addons')
        control .directory (OO00OOOO0OOOOO000 ,cacheToDisc =True )