# -*- coding: utf-8 -*-
#      __    ____  ____  _   _____  _____________________
#     / /   / __ \/ __ \/ | / /   |/_  __/  _/ ____/ ___/
#    / /   / / / / / / /  |/ / /| | / /  / // /    \__ \
#   / /___/ /_/ / /_/ / /|  / ___ |/ / _/ // /___ ___/ /
#  /_____/\____/\____/_/ |_/_/  |_/_/ /___/\____//____/
#

from re import match as re_match


def cleanPlot(plot):
	if not plot: return
	try:
		index = plot.rfind('See full summary')
		if index == -1: index = plot.rfind("It's publicly available on")
		if index >= 0: plot = plot[:index]
		plot = plot.strip()
		if re_match(r'[a-zA-Z\d]$', plot): plot += ' ...'
		return plot
	except:
		from resources.lib.modules import log_utils
		log_utils.error()