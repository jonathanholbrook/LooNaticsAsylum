# -*- coding: utf-8 -*-

'''
    ThePromise Add-on
'''

from sys import argv
from resources.lib.modules import router
router.routing(argv[2])
