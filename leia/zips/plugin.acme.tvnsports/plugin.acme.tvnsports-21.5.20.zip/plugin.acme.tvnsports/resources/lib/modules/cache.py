# -*- coding: utf-8 -*-
# Credits to:
#                    _                                     
#                   ( )_  _                                
#   _ _  _ __       | ,_)(_)   ___       _ _  _ _      __  
# /'_` )( '__)(`\/')| |  | | /'___)    /'_` )( '_`\  /'__`\
#( (_| || |    >  < | |_ | |( (___  _ ( (_| || (_) )(  ___/
#`\__,_)(_)   (_/\_)`\__)(_)`\____)(_)`\__,_)| ,__/'`\____)
#                                            | |           
#                                            (_)           
#



import re,hashlib,time

try:
	from sqlite3 import dbapi2 as database
except:
	from pysqlite2 import dbapi2 as database

from resources.lib.modules import control
from resources.lib.modules.log_utils import log

def remove(function, *args):

	f = repr(function)
	f = re.sub('.+\smethod\s|.+function\s|\sat\s.+|\sof\s.+', '', f)

	a = hashlib.md5()
	for i in args:
		try: a.update(str(i))
		except: a.update(str(i).encode('utf-8'))
	a = str(a.hexdigest())

	table = 'rel_list'
	
	control.makeFile(control.dataPath)
	dbcon = database.connect(control.cacheFile)
	dbcur = dbcon.cursor()
	log("DELETE FROM %s WHERE func = '%s' AND args = '%s'" % (table, f, a))
	dbcur.execute("DELETE FROM %s WHERE func = '%s' AND args = '%s'" % (table, f, a))
	dbcon.commit()
	

def get(function, timeout, *args, **table):
	try:
		response = None

		f = repr(function)
		f = re.sub('.+\smethod\s|.+function\s|\sat\s.+|\sof\s.+', '', f)

		a = hashlib.md5()
		for i in args:
			try: a.update(str(i))
			except: a.update(str(i).encode('utf-8'))
		a = str(a.hexdigest())
	except:
		pass

	try:
		table = table['table']
	except:
		table = 'rel_list'

	try:
		control.makeFile(control.dataPath)
		dbcon = database.connect(control.cacheFile)
		dbcur = dbcon.cursor()
		dbcur.execute("SELECT * FROM %s WHERE func = '%s' AND args = '%s'" % (table, f, a))
		match = dbcur.fetchone()

		response = eval(match[2].encode('utf-8'))

		t1 = int(match[3])
		t2 = int(time.time())
		update = (abs(t2 - t1) / 60) >= int(timeout)
		if update == False:
			return response
	except Exception as e:
		pass

	try:
		r = function(*args)
		if (r == None or r == []) and not response == None:
			return response
		# elif (r == None or r == []):
		# 	return r
	except Exception as e:
		return

	try:
		r = repr(r)
		t = int(time.time())
		dbcur.execute("CREATE TABLE IF NOT EXISTS %s (""func TEXT, ""args TEXT, ""response TEXT, ""added TEXT, ""UNIQUE(func, args)"");" % table)
		dbcur.execute("DELETE FROM %s WHERE func = '%s' AND args = '%s'" % (table, f, a))
		dbcur.execute("INSERT INTO %s Values (?, ?, ?, ?)" % table, (f, a, r, t))
		dbcon.commit()
	except Exception as e:
		pass

	try:
		return eval(r.encode('utf-8'))
	except:
		pass


def clear(table=None):
	try:
		control.idle()

		if table == None: table = ['rel_list', 'rel_lib']
		elif not type(table) == list: table = [table]

		yes = control.yesnoDialog('Are you sure?', '', '')
		if not yes: return

		dbcon = database.connect(control.cacheFile)
		dbcur = dbcon.cursor()

		for t in table:
			try:
				dbcur.execute("DROP TABLE IF EXISTS %s" % t)
				dbcur.execute("VACUUM")
				dbcon.commit()
			except:
				pass

		control.infoDialog('Cache cleared')
	except:
		pass

